const key = process.env.NVIDIA_API_KEY;
if (!key) throw new Error('NVIDIA_API_KEY is missing');
const response = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
  method: 'POST',
  headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({
    model: 'meta/llama-3.1-8b-instruct',
    temperature: 0,
    max_tokens: 40,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: 'Return only JSON with one key: ok. The value must be true.' },
      { role: 'user', content: 'Health check.' },
    ],
  }),
});
const text = await response.text();
if (!response.ok) throw new Error(`NVIDIA chat failed ${response.status}: ${text.slice(0, 500)}`);
const payload = JSON.parse(text);
const content = payload.choices?.[0]?.message?.content;
if (!content) throw new Error('NVIDIA chat returned no content');
console.log('NVIDIA chat connection passed');
