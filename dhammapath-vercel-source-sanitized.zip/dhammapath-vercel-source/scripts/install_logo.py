from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/webdev-static-assets/dhamma-path-within-icon.png')
assets = Path('/home/ubuntu/dhamma-thought-adviser/assets/images')
image = Image.open(source).convert('RGB').resize((768, 768), Image.Resampling.LANCZOS).quantize(colors=128)
for filename in ('icon.png', 'splash-icon.png', 'favicon.png', 'android-icon-foreground.png', 'android-icon-monochrome.png'):
    image.save(assets / filename, format='PNG', optimize=True)
