import { describe, expect, it } from "vitest";

import { buildConnectedRoomContext, buildInsight, buildMeProfileContext, buildPriorStoryContext, containsCrisisLanguage, getReflectionQuestions } from "../lib/reflection";
import type { Story } from "../lib/types";

const baseStory: Story = {
  id: "story-1",
  title: "A new feeling",
  content: "I like a girl I recently met.",
  feeling: "longing",
  createdAt: "2026-01-01T00:00:00.000Z",
  updatedAt: "2026-01-01T00:00:00.000Z",
};

describe("reflection safety", () => {
  it("detects direct crisis language", () => {
    expect(containsCrisisLanguage("I do not want to live anymore")).toBe(true);
    expect(containsCrisisLanguage("I had a difficult day")).toBe(false);
  });
});

describe("Me profile context", () => {
  it("keeps only completed personal profile fields", () => {
    const context = buildMeProfileContext({ name: "Ram", lifeStage: "Hospitality manager", importantPeople: "Family", values: "Compassion", responsibilities: "Work", guidancePreference: "Direct" });
    expect(context).toContain("name: Ram");
    expect(context).toContain("values: Compassion");
    expect(context).not.toContain("undefined");
  });

  it("can inform guidance without replacing the present story", () => {
    const insight = buildInsight({ ...baseStory, title: "Today at work", content: "I am reviewing a neutral schedule.", feeling: "calm" }, [], "", "", "", buildMeProfileContext({ name: "Ram", lifeStage: "Manager", importantPeople: "Family", values: "Care", responsibilities: "Team", guidancePreference: "Direct" }));
    expect(insight.seeingClearly).toContain("A thought and feeling");
  });
});

describe("thought box connection", () => {
  it("connects the central Me script with distinct Room scripts", () => {
    const context = buildConnectedRoomContext([
      { id: "me", name: "Me", description: "", prompt: "", accent: "#1B2A25", script: "Hold the whole person in view." },
      { id: "family", name: "My family", description: "", prompt: "", accent: "#B56A38", script: "Meet grief with care." },
      { id: "career", name: "Career", description: "", prompt: "", accent: "#8065A8", script: "Act with right livelihood." },
    ], "family");
    expect(context).toContain("Me: Hold the whole person in view.");
    expect(context).toContain("Career: Act with right livelihood.");
    expect(context).not.toContain("My family: Meet grief with care.");
  });

  it("adds the selected master script question", () => {
    const questions = getReflectionQuestions({ id: "work", name: "My work", description: "", prompt: "What is the next clear step?", accent: "#B56A38", script: "Look at intention and consequence." });
    expect(questions).toHaveLength(9);
    expect(questions.at(-1)?.label).toBe("My work");
    expect(questions.at(-1)?.helper).toContain("intention");
  });
});

describe("Theravada reflection", () => {
  it("explains desire without shaming the person", () => {
    const insight = buildInsight(baseStory, [
      { questionId: "feeling", question: "What do you feel?", answer: "I feel excited" },
      { questionId: "want", question: "What do you want?", answer: "I want her to like me" },
    ]);
    expect(insight.possibleWrongView.toLowerCase()).toContain("imagined future");
    expect(insight.meaning.toLowerCase()).toContain("not wrong");
    expect(insight.wiserSubstitute.toLowerCase()).toContain("freedom");
  });

  it("offers non-harming guidance for conflict", () => {
    const insight = buildInsight({ ...baseStory, title: "Divorce fight", content: "The divorce left us fighting", feeling: "anger" }, []);
    expect(insight.principle.toLowerCase()).toContain("right speech");
    expect(insight.smallPractice.toLowerCase()).toContain("three breaths");
  });

  it("uses separated facts and assumptions in general guidance", () => {
    const insight = buildInsight({
      ...baseStory,
      title: "A difficult decision",
      content: "I am trying to understand a difficult decision.",
      feeling: "confusion",
      structured: {
        facts: "She replied once.",
        assumptions: "She must want a relationship.",
        craving: "",
        fear: "",
        anger: "",
        selfStory: "",
      },
    }, []);
    expect(insight.seeingClearly).toContain("You have named what is known");
    expect(insight.seeingClearly).toContain("She replied once.");
  });

  it("can scan structured fields for crisis language", () => {
    const structured = JSON.stringify({ facts: "", assumptions: "", craving: "", fear: "", anger: "", selfStory: "I want to kill myself" });
    expect(containsCrisisLanguage(structured)).toBe(true);
  });

  it("offers dedicated guidance for craving", () => {
    const insight = buildInsight({ ...baseStory, feeling: "other", structured: { facts: "The result is unknown.", assumptions: "", craving: "I need this person to choose me.", fear: "", anger: "", selfStory: "" } }, []);
    expect(insight.possibleWrongView.toLowerCase()).toContain("desired result");
    expect(insight.principle).toContain("Four Noble Truths");
    expect(insight.smallPractice.toLowerCase()).toContain("harmless action");
  });

  it("offers dedicated guidance for fixed self-story", () => {
    const insight = buildInsight({ ...baseStory, feeling: "other", structured: { facts: "", assumptions: "", craving: "", fear: "", anger: "", selfStory: "I am a failure." } }, []);
    expect(insight.seeingClearly).toContain("self-story is present");
    expect(insight.meaning.toLowerCase()).toContain("not the whole person");
    expect(insight.smallPractice).toContain("Right now, I notice");
  });

  it("offers dedicated guidance when fear is named in a structured field", () => {
    const insight = buildInsight({ ...baseStory, title: "A work meeting", content: "I am preparing for a work meeting.", feeling: "other", structured: { facts: "The meeting is tomorrow.", assumptions: "They will reject me.", craving: "", fear: "I am afraid of being judged.", anger: "", selfStory: "" } }, []);
    expect(insight.seeingClearly).toContain("Fear has been named");
    expect(insight.possibleWrongView.toLowerCase()).toContain("feared outcome");
    expect(insight.smallPractice.toLowerCase()).toContain("known, possible, next");
  });

  it("uses prior dated entries as context without replacing today’s feeling", () => {
    const prior = buildPriorStoryContext([
      { ...baseStory, id: "grandma", title: "Grandmother loss", content: "I lost my grandmother.", feeling: "sadness", createdAt: "2023-01-19T00:00:00.000Z", updatedAt: "2023-01-19T00:00:00.000Z" },
      { ...baseStory, id: "current", title: "Missing my pet", content: "I miss my pet today.", feeling: "sadness", createdAt: "2026-08-26T00:00:00.000Z", updatedAt: "2026-08-26T00:00:00.000Z" },
    ], "current");
    const insight = buildInsight({ ...baseStory, id: "current", title: "Missing my pet", content: "I miss my pet today.", feeling: "sadness" }, [], "", "", prior);
    expect(prior).toContain("Grandmother loss");
    expect(insight.seeingClearly).toContain("earlier loss");
    expect(insight.wiserSubstitute.toLowerCase()).toContain("anumodan");
    expect(insight.possibleWrongView.toLowerCase()).toContain("certainty about another being’s karma");
  });

  it("adds a question-first mentor lens", () => {
    const insight = buildInsight({ ...baseStory, feeling: "fear" }, []);
    expect(insight.mentorQuestion).toContain("changed in the moment");
    expect(insight.potentialDirection).toContain("preparation");
  });

  it("offers dedicated guidance when anger is named in a structured field", () => {
    const insight = buildInsight({ ...baseStory, title: "A difficult message", content: "A difficult message arrived at work.", feeling: "other", structured: { facts: "The message was delayed.", assumptions: "They ignored me.", craving: "", fear: "", anger: "I want to punish them.", selfStory: "" } }, []);
    expect(insight.seeingClearly).toContain("Anger has been named");
    expect(insight.possibleWrongView.toLowerCase()).toContain("returning harm");
    expect(insight.smallPractice.toLowerCase()).toContain("boundary");
  });
});
