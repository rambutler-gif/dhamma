import { describe, expect, it } from "vitest";
import { monthCompletion, type ChecklistItem, type Project } from "../lib/operational-context";
import { nextForwardDate } from "../lib/executive-task-utils";

describe("operational control center", () => {
  const checklist: ChecklistItem = { id: "c1", title: "FIFO check", note: "", active: true, createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z", completedDates: ["2026-08-01", "2026-08-14", "2026-09-01"] };
  it("counts only completion dates inside the selected month", () => {
    expect(monthCompletion(checklist, 2026, 7)).toBe(2);
    expect(monthCompletion(checklist, 2026, 8)).toBe(1);
  });
  it("forwards a task exactly one week across month boundaries", () => {
    expect(nextForwardDate("2026-08-31")).toBe("2026-09-07");
  });
  it("keeps project fields explicit for local reporting", () => {
    const project: Project = { id: "p1", product: "Beverage", name: "Menu refresh", teamMemberIds: ["m1", "m2"], ownerId: "m1", deadline: "2026-08-31", reviewDate: "2026-08-25", remark: "Cost before launch", status: "active", createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z" };
    expect(project.teamMemberIds).toHaveLength(2);
    expect(project.status).toBe("active");
    expect(project.reviewDate).toBe("2026-08-25");
  });
});
