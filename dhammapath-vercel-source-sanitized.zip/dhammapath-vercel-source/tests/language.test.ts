import { describe, expect, it } from "vitest";

import { LANGUAGES } from "../lib/language-context";

describe("language support", () => {
  it("exposes English, Hindi, Tamil, Sinhala, and Malayalam", () => {
    expect(LANGUAGES.map((language) => language.key)).toEqual(["en", "hi", "ta", "si", "ml"]);
    expect(LANGUAGES.map((language) => language.native)).toEqual(["English", "हिन्दी", "தமிழ்", "සිංහල", "മലയാളം"]);
  });
});
