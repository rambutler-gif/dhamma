import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const practiceSource = readFileSync(join(dirname(fileURLToPath(import.meta.url)), "../app/(tabs)/practice.tsx"), "utf8");

describe("advanced reflection exercises", () => {
  it("includes four mature situations", () => {
    expect(practiceSource).toContain('const exerciseIds: ExerciseId[] = ["decision", "boundary", "attachment", "repair"]');
    expect(practiceSource).toContain("A decision under pressure");
    expect(practiceSource).toContain("A boundary without hostility");
    expect(practiceSource).toContain("Attachment and uncertainty");
    expect(practiceSource).toContain("Repair after harm");
  });

  it("separates practical reflection from diagnosis and scoring", () => {
    expect(practiceSource).toContain("Separate what is known from what the mind predicts.");
    expect(practiceSource).toContain("Turn remorse into responsibility, not self-punishment.");
    expect(practiceSource).toContain("It is not a score or diagnosis.");
  });

  it("provides localized exercise catalogs", () => {
    expect(practiceSource).toContain('en: {');
    expect(practiceSource).toContain('hi: {');
    expect(practiceSource).toContain('ta: {');
    expect(practiceSource).toContain('si: {');
    expect(practiceSource).toContain('ml: {');
  });
});
