import { describe, expect, it } from "vitest";

const key = process.env.NVIDIA_API_KEY;

describe("NVIDIA NIM credentials", () => {
  it.skipIf(!key)(
    "authenticates against the models endpoint",
    async () => {
      const response = await fetch("https://integrate.api.nvidia.com/v1/models", {
        headers: { Authorization: `Bearer ${key}` },
      });

      expect(response.status, await response.text()).toBe(200);
    },
    20_000,
  );
});
