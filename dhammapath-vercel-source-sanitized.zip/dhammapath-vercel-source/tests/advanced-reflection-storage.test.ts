import { describe, expect, it } from "vitest";

import { parseAdvancedResponses, serializeAdvancedResponses } from "../lib/advanced-reflection-storage";

describe("advanced reflection response storage", () => {
  it("round trips private responses", () => {
    const responses = { decision: "  I will pause first.  ", repair: "I can acknowledge the impact." };
    expect(parseAdvancedResponses(serializeAdvancedResponses(responses))).toEqual(responses);
  });

  it("returns an empty store for malformed or unsafe data", () => {
    expect(parseAdvancedResponses(null)).toEqual({});
    expect(parseAdvancedResponses("not-json")).toEqual({});
    expect(parseAdvancedResponses("[]")).toEqual({});
    expect(parseAdvancedResponses('{"decision":42,"repair":"acknowledge"}')).toEqual({ repair: "acknowledge" });
  });
});
