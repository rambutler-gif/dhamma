import { describe, expect, it } from "vitest";

import { buildPlanningContext } from "../lib/reflection";
import { applyWeeklyRollover, parsePlanningArray, sortPlanningItems } from "../lib/planning-context";
import type { Habit, PlanningItem } from "../lib/types";

const item = (overrides: Partial<PlanningItem>): PlanningItem => ({
  id: overrides.id ?? "item-1",
  type: overrides.type ?? "goal",
  title: overrides.title ?? "A goal",
  note: overrides.note ?? "",
  date: overrides.date ?? "2026-09-01",
  completed: overrides.completed ?? false,
  createdAt: overrides.createdAt ?? "2026-08-27T10:00:00.000Z",
  priority: overrides.priority,
  rolloverCount: overrides.rolloverCount,
  escalated: overrides.escalated,
  archivedAt: overrides.archivedAt,
  sourceEventId: overrides.sourceEventId,
  sourceEventTitle: overrides.sourceEventTitle,
});

const habit = (title: string): Habit => ({
  id: title,
  title,
  note: "",
  createdAt: "2026-08-27T10:00:00.000Z",
  completedDates: [],
});

describe("planning context", () => {
  it("includes unfinished planning items and habits", () => {
    const context = buildPlanningContext(
      [item({ type: "upcoming", title: "Prepare meeting" }), item({ title: "Finished goal", completed: true })],
      [habit("Morning walk")],
    );
    expect(context).toContain("upcoming: Prepare meeting");
    expect(context).toContain("habit: Morning walk");
    expect(context).not.toContain("Finished goal");
  });

  it("sorts planning items by date", () => {
    const sorted = sortPlanningItems([item({ id: "later", date: "2026-09-04" }), item({ id: "soon", date: "2026-08-28" })]);
    expect(sorted.map((entry) => entry.id)).toEqual(["soon", "later"]);
  });

  it("rolls open work forward and archives completed work", () => {
    const now = new Date("2026-08-27T10:00:00.000Z");
    const result = applyWeeklyRollover([
      item({ id: "open", date: "2026-08-20", completed: false }),
      item({ id: "done", date: "2026-08-20", completed: true }),
    ], now);
    expect(result.summary.weeklyRolled).toBe(1);
    expect(result.summary.completedArchived).toBe(1);
    expect(result.items.find((entry) => entry.id === "open")?.rolloverCount).toBe(1);
    expect(result.items.find((entry) => entry.id === "done")?.archivedAt).toBeTruthy();
  });

  it("escalates work after two consecutive rollovers", () => {
    const result = applyWeeklyRollover([item({ date: "2026-08-01", rolloverCount: 1 })], new Date("2026-08-27T10:00:00.000Z"));
    expect(result.summary.escalated).toBe(1);
    expect(result.items[0].escalated).toBe(true);
    expect(result.items[0].rolloverCount).toBe(2);
  });

  it("rejects malformed local arrays safely", () => {
    expect(parsePlanningArray<PlanningItem>("not-json")).toEqual([]);
    expect(parsePlanningArray<PlanningItem>(JSON.stringify({ title: "not an array" }))).toEqual([]);
    expect(parsePlanningArray<PlanningItem>(null)).toEqual([]);
  });
});
