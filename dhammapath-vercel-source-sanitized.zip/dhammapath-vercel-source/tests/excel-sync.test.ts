import { describe, expect, it } from "vitest";
import { buildWorkbook, mergeRecords, parseWorkbookBuffer, workbookToArrayBuffer, type WorkbookData } from "../lib/excel-sync";
import type { OfficeTask, Project, TrainingRecord } from "../types/sync";

const sampleTask: OfficeTask = {
  id: "t1",
  task: "Vendor call",
  category: "purchase",
  project: "p1",
  severity: "medium",
  priority: "high",
  owner: "Ram",
  date: "2026-08-20",
  status: "pending",
  createdAt: "2026-08-20T09:00:00.000Z",
  updatedAt: "2026-08-20T09:00:00.000Z",
};

const sampleWorkbookData: WorkbookData = {
  tasks: [sampleTask],
  projects: [],
  checklistRows: [{ itemId: "c1", title: "FIFO check", note: "", date: "2026-08-20", done: true }],
  trainings: [],
};

describe("excel-sync workbook round trip", () => {
  it("parses back exactly what it built for tasks", () => {
    const wb = buildWorkbook(sampleWorkbookData);
    const buffer = workbookToArrayBuffer(wb);
    const parsed = parseWorkbookBuffer(buffer);
    expect(parsed.errors).toHaveLength(0);
    expect(parsed.tasks).toHaveLength(1);
    expect(parsed.tasks[0]).toMatchObject({ id: "t1", task: "Vendor call", status: "pending", owner: "Ram" });
  });

  it("round-trips checklist rows", () => {
    const wb = buildWorkbook(sampleWorkbookData);
    const parsed = parseWorkbookBuffer(workbookToArrayBuffer(wb));
    expect(parsed.checklistRows).toHaveLength(1);
    expect(parsed.checklistRows[0]).toMatchObject({ itemId: "c1", date: "2026-08-20", done: true });
  });

  it("flags a row missing a required field instead of silently dropping it", () => {
    const wb = buildWorkbook(sampleWorkbookData);
    const sheet = wb.Sheets["Tasks"];
    // Corrupt the task cell of the data row (row 2) to simulate a bad manual edit.
    delete sheet["B2"];
    const parsed = parseWorkbookBuffer(workbookToArrayBuffer(wb));
    expect(parsed.tasks).toHaveLength(0);
    expect(parsed.errors.some((e) => e.includes("Tasks row 2"))).toBe(true);
  });
});

describe("excel-sync merge logic", () => {
  it("adds a record that only exists in the incoming set", () => {
    const result = mergeRecords<OfficeTask>([], [sampleTask], "task", null);
    expect(result.toAdd).toHaveLength(1);
    expect(result.toUpdate).toHaveLength(0);
    expect(result.conflicts).toHaveLength(0);
  });

  it("skips a record that is identical on both sides", () => {
    const result = mergeRecords<OfficeTask>([sampleTask], [sampleTask], "task", "2026-08-19T00:00:00.000Z");
    expect(result.skipped).toBe(1);
    expect(result.toAdd).toHaveLength(0);
    expect(result.toUpdate).toHaveLength(0);
  });

  it("takes the incoming version when only Excel changed since last sync", () => {
    const lastSyncedAt = "2026-08-20T10:00:00.000Z";
    const local = { ...sampleTask };
    const incoming = { ...sampleTask, task: "Vendor call, confirmed", updatedAt: "2026-08-21T00:00:00.000Z" };
    const result = mergeRecords<OfficeTask>([local], [incoming], "task", lastSyncedAt);
    expect(result.toUpdate).toHaveLength(1);
    expect(result.toUpdate[0].task).toBe("Vendor call, confirmed");
    expect(result.conflicts).toHaveLength(0);
  });

  it("flags a conflict when both sides changed since last sync", () => {
    const lastSyncedAt = "2026-08-19T00:00:00.000Z";
    const local = { ...sampleTask, task: "Vendor call, app edit", updatedAt: "2026-08-20T12:00:00.000Z" };
    const incoming = { ...sampleTask, task: "Vendor call, excel edit", updatedAt: "2026-08-21T00:00:00.000Z" };
    const result = mergeRecords<OfficeTask>([local], [incoming], "task", lastSyncedAt);
    expect(result.conflicts).toHaveLength(1);
    expect(result.conflicts[0].appVersion.task).toBe("Vendor call, app edit");
    expect(result.conflicts[0].excelVersion.task).toBe("Vendor call, excel edit");
  });

  it("treats a mismatch as a conflict on a first-ever import with no sync baseline", () => {
    const local = { ...sampleTask, task: "Vendor call, app edit" };
    const incoming = { ...sampleTask, task: "Vendor call, excel edit" };
    const result = mergeRecords<OfficeTask>([local], [incoming], "task", null);
    expect(result.conflicts).toHaveLength(1);
  });

  it("merges project and training records the same way", () => {
    const project: Project = { id: "p1", product: "Beverage", name: "Menu refresh", status: "active", createdAt: "2026-08-01T00:00:00.000Z", updatedAt: "2026-08-01T00:00:00.000Z" };
    const training: TrainingRecord = { id: "tr1", date: "2026-08-15", topic: "FSIS refresher", createdAt: "2026-08-15T00:00:00.000Z", updatedAt: "2026-08-15T00:00:00.000Z" };
    expect(mergeRecords<Project>([], [project], "project", null).toAdd).toHaveLength(1);
    expect(mergeRecords<TrainingRecord>([], [training], "training", null).toAdd).toHaveLength(1);
  });
});
