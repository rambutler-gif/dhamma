import { describe, expect, it } from "vitest";

import { crmWeeklyReport, dueSoonPeople, overduePeople } from "../lib/crm-utils";
import type { Person } from "../lib/people-context";

const person = (id: string, nextContact?: string, lastContacted?: string): Person => ({ id, name: id, relationship: "supplier", nextContact, lastContacted, notes: "", interactions: [], createdAt: "2026-08-01T00:00:00.000Z" });

describe("CRM reporting", () => {
  it("finds overdue and due-soon follow-ups", () => {
    const people = [person("late", "2026-08-27"), person("soon", "2026-09-02"), person("later", "2026-09-20")];
    expect(overduePeople(people, "2026-08-28").map((item) => item.id)).toEqual(["late"]);
    expect(dueSoonPeople(people, "2026-08-28").map((item) => item.id)).toEqual(["soon"]);
  });

  it("summarizes contact coverage and current-week interactions", () => {
    const people = [person("one", "2026-09-02", "2026-08-27"), person("two")];
    people[0].interactions = [{ id: "i", date: "2026-08-27", summary: "Review", channel: "Manual" }];
    expect(crmWeeklyReport(people, "2026-08-28")).toMatchObject({ totalPeople: 2, interactions: 1, coverage: 50, dueSoon: 1 });
  });
});
