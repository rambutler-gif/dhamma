import { describe, expect, it } from "vitest";

import { contactDateFromEvent, matchPeopleInText } from "../lib/people-context";
import type { Person } from "../lib/people-context";

const people: Person[] = [
  { id: "1", name: "Anil", relationship: "supplier", notes: "", interactions: [], createdAt: "2026-08-01T00:00:00.000Z" },
  { id: "2", name: "Meera", relationship: "family", notes: "", interactions: [], createdAt: "2026-08-01T00:00:00.000Z" },
];

describe("private people matching", () => {
  it("matches saved names in calendar event text", () => {
    expect(matchPeopleInText("Supplier review with Anil", people)).toEqual(["1"]);
    expect(matchPeopleInText("No saved contact here", people)).toEqual([]);
  });

  it("normalizes event timestamps to a local date key", () => {
    expect(contactDateFromEvent("2026-08-28T10:30:00+05:30")).toBe("2026-08-28");
  });
});
