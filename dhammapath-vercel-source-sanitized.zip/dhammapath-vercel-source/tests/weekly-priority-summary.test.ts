import { describe, expect, it } from "vitest";

import { weeklyPrioritySummary, type PrioritySummaryTask } from "../lib/crm-utils";

const task = (overrides: Partial<PrioritySummaryTask>): PrioritySummaryTask => ({ id: "1", task: "Task", date: "2026-08-27", priority: "high", status: "open", rolloverCount: 0, ...overrides });

describe("weekly priority summary", () => {
  it("separates completed and pending high-priority work", () => {
    const result = weeklyPrioritySummary([task({ id: "done", status: "done" }), task({ id: "open", task: "Owner report", date: "2026-08-28" })], "2026-08-28");
    expect(result.completedCount).toBe(1);
    expect(result.pendingCount).toBe(1);
    expect(result.alertCount).toBe(0);
  });

  it("alerts for overdue and twice-rolled high-priority work", () => {
    const result = weeklyPrioritySummary([task({ id: "overdue", date: "2026-08-24" }), task({ id: "escalated", rolloverCount: 2 })], "2026-08-28");
    expect(result.alertCount).toBe(2);
  });

  it("filters by priority and contact association", () => {
    const tasks = [task({ id: "owner", task: "Owner briefing", contactName: "Anita", priority: "high" }), task({ id: "supplier", task: "Supplier report", contactName: "Ravi", priority: "medium" })];
    expect(weeklyPrioritySummary(tasks, "2026-08-28", "high").pendingCount).toBe(1);
    expect(weeklyPrioritySummary(tasks, "2026-08-28", "all", "Ravi").pendingCount).toBe(1);
    expect(weeklyPrioritySummary(tasks, "2026-08-28", "all", "Anita").pendingCount).toBe(1);
  });

  it("does not include medium or low priority tasks by default", () => {
    const result = weeklyPrioritySummary([task({ id: "medium", priority: "medium" }), task({ id: "low", priority: "low" })], "2026-08-28");
    expect(result.completedCount).toBe(0);
    expect(result.pendingCount).toBe(0);
  });
});
