import { describe, expect, it } from "vitest";

import { DHAMMA_KEYS, getDhammaKeys, inferDhammaKeyIds } from "../lib/dhamma-keys";

describe("wider Dhamma keys", () => {
  it("maps longing and conflict to distinct teachings", () => {
    const ids = inferDhammaKeyIds("I want this person to choose me, but our argument became bitter", "longing");
    expect(ids).toContain("craving");
    expect(ids).toContain("rightSpeech");
  });

  it("returns canonical source links for inferred keys", () => {
    const references = getDhammaKeys(["fourTruths", "mindfulness"]);
    expect(references).toHaveLength(2);
    expect(references.every((item) => item.referenceUrl.startsWith("https://"))).toBe(true);
    expect(references.map((item) => item.pali)).toEqual(["cattāri ariyasaccāni", "sati"]);
  });

  it("keeps the catalog broad and traceable", () => {
    expect(Object.keys(DHAMMA_KEYS).length).toBeGreaterThanOrEqual(10);
    expect(Object.values(DHAMMA_KEYS).every((item) => item.description && item.reference)).toBe(true);
  });
});
