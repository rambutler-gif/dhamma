import { describe, expect, it } from "vitest";

import { compliancePercent, monthDays, taskNeedsEscalation, taskRolloverLabel } from "../lib/executive-dashboard-utils";
import type { OfficeTask } from "../lib/executive-dashboard-context";

describe("executive dashboard registries", () => {
  it("creates the correct number of calendar days", () => {
    expect(monthDays(2026, 1)).toHaveLength(28);
    expect(monthDays(2028, 1)).toHaveLength(29);
  });

  it("calculates cert compliance only inside the defined period", () => {
    expect(compliancePercent(["2026-08-01", "2026-08-05", "2026-09-01"], "2026-08-01", "2026-08-05")).toBe(40);
  });

  it("identifies the two-cycle escalation threshold", () => {
    const high: OfficeTask = { id: "1", task: "Review P&L", category: "Finance", severity: "High", priority: "high", status: "open", date: "2026-08-27", rolloverCount: 2 };
    const medium: OfficeTask = { ...high, id: "2", severity: "Medium", rolloverCount: 1 };
    expect(taskNeedsEscalation(high)).toBe(true);
    expect(taskNeedsEscalation(medium)).toBe(false);
    expect(taskRolloverLabel(high)).toBe("MOVE TO TOMORROW");
  });
});
