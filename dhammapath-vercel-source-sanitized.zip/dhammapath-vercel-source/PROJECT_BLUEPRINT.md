# Dhamma: The Path Within

## Project overview

Dhamma: The Path Within is a portrait mobile app for private self reflection. It stores personal life stories locally. It guides the user through circumstance based questions. It offers Theravada inspired reflection without claiming to replace qualified mental health care, teachers, or emergency support.

The current project uses Expo SDK 54, React Native, TypeScript, Expo Router, NativeWind, tRPC, a Node server, and Vitest.

## Product principles

The experience is designed as a Theravada life companion. It is not a generic Zen lifestyle guide. It does not prescribe shore walks, sunset watching, or devotional dependence. It helps the user examine conditions, intentions, feelings, attachment, speech, conduct, and consequences.

The app distinguishes possible **micchā-diṭṭhi**, or wrong view, from **sammā-diṭṭhi**, or right view. Guidance is presented as reflection, not a verdict. The user remains free to practise, postpone, or reject a suggestion.

## Current features

| Area | Implemented behavior |
|---|---|
| Home | Daily reflection prompt, recent stories, local privacy notice |
| Stories | Local story creation, list, search, detail view, saved reflection transcript |
| Circumstances | Who, what, when, where, why, how, feeling, and intended outcome questions |
| Thought boxes | Work, personal, projects, career, travel, and business idea spaces |
| Master script | Each thought box can hold a private script used during reflection |
| Locking | One master password gate protects the private space |
| Script controls | Password required for script edits and box deletion |
| Q&A records | Individual saved reflection answers can be deleted |
| Guidance | Possible wrong view, meaning, wiser substitute, principle, and one small practice |
| Safety | Crisis language routes toward immediate human support |
| Languages | English, Hindi, Tamil, Sinhala, and Malayalam selector with local persistence |
| AI | Optional server side NVIDIA NIM reflection route with local fallback |
| Branding | Dhamma: The Path Within name and blue watercolor Buddhist icon assets |
| Practice | Small practice library for mindfulness, speech, patience, and letting go |
| Settings | Privacy language, language selection, password controls, lock controls, and safety notes |

## Main user flow

The user opens the private space and unlocks it with the master password. The user selects a thought box, such as Work or Project 1. The user records an honest story and the location where it happened. The app asks the circumstance questions one at a time. The selected box master script contributes an additional question and context. The user completes the conversation and taps See insight. The app tries the protected NVIDIA NIM route. If the request fails or the service is unavailable, the local Theravada reflection engine provides the insight. The completed Q&A and insight are saved with the story.

## Privacy and security model

Stories are stored locally with AsyncStorage. The master password is represented by a one way digest and is not stored as plain text. The NVIDIA API key is server side and must never be placed in the mobile bundle. The mobile client sends reflection input to the protected backend route. The app keeps local guidance available when the user is offline or when AI is unavailable.

The current model is suitable for a personal trial. Before public distribution, add explicit consent before sending a story to an external AI service, add request limits, add deletion confirmation, and consider device biometric protection.

## AI integration

The server route is defined in `server/routers.ts` under `ai.reflect`. It uses the `NVIDIA_API_KEY` secret and the verified model `meta/llama-3.1-8b-instruct`. The response is parsed through a Zod schema. The system prompt requires plain English, Theravada framing, circumstance awareness, user autonomy, and safety escalation.

The mobile route is `app/reflection/[id].tsx`. It tries NVIDIA NIM after the final answer. It falls back to `buildInsight` from `lib/reflection.ts` when the request fails.

## Important directories

| Path | Purpose |
|---|---|
| `app/` | Expo Router screens and navigation |
| `app/(tabs)/index.tsx` | Home screen |
| `app/(tabs)/stories.tsx` | Stories screen |
| `app/(tabs)/boxes.tsx` | Thought box and master script screen |
| `app/(tabs)/practice.tsx` | Practice library |
| `app/(tabs)/settings.tsx` | Settings, lock, language, and privacy controls |
| `app/story/new.tsx` | New story form |
| `app/story/[id].tsx` | Story detail and saved Q&A |
| `app/reflection/[id].tsx` | Guided reflection and insight |
| `lib/private-space.tsx` | Private space state and local persistence |
| `lib/stories-context.tsx` | Story state and local persistence |
| `lib/reflection.ts` | Local question and insight engine |
| `lib/language-context.tsx` | Five language selection and persistence |
| `lib/types.ts` | Shared story, box, question, answer, and insight types |
| `server/routers.ts` | Server tRPC routes and NVIDIA NIM adapter |
| `tests/` | Deterministic unit tests and NVIDIA checks |
| `assets/images/` | Launcher, splash, favicon, and Android icon assets |
| `app.config.ts` | Expo name, slug, branding, package IDs, and plugins |
| `theme.config.js` | Shared color palette |
| `design.md` | Mobile interface and symbolism decisions |
| `theravada-framework.md` | Reflection principles used by the product |
| `competitor-research.md` | Comparable product research |
| `personal-ai-options.md` | Personal AI provider comparison |
| `todo.md` | Feature and delivery checklist |

## Runtime and configuration

The project has a local Expo web preview and a Node backend. The app uses the managed project environment for runtime configuration. Secrets must be added through the project Secrets panel.

Required secret for NVIDIA NIM:

```text
NVIDIA_API_KEY=<your private NVIDIA NIM key>
```

Never commit this value. Never place it in `app.config.ts`. Never include it in a mobile build. The exported ZIP intentionally excludes private environment files, project metadata containing credentials, build output, and local logs.

## Validation commands

```bash
pnpm exec tsc --noEmit
pnpm test -- --run
pnpm lint
pnpm build
```

The NVIDIA smoke tests are:

```bash
pnpm vitest run tests/nvidia-key.test.ts --reporter=verbose
node scripts/test_nvidia_chat.mjs
```

These tests require `NVIDIA_API_KEY` in the server environment. The key validation test checks the NVIDIA models endpoint. The chat smoke test checks the structured chat endpoint.

## Current validation status

The restored app passed TypeScript checks, six active Vitest tests, lint, server production build, NVIDIA key validation, and NVIDIA live chat smoke testing. Expo may print a module type warning and package compatibility notices. These are non blocking warnings in the current scaffold.

## Remaining planned work

The learning library is not yet complete. Planned work includes Pali search, Pali meanings in English, Hindi, Tamil, Sinhala, and Malayalam, daily Pali verses, easy Jātaka stories, Sutta Piṭaka and Vinaya Piṭaka mind map viewers, and full interface localization.

Before public launch, add consent before external AI requests, per user usage limits, stronger local encryption, biometric unlock, reviewed native language translations, source references for each scripture item, and an independent Theravada teacher review.

## Safe export note

This archive contains source code and assets. It does not contain API keys, database URLs, Expo tokens, project secrets, `.env` files, `.project-config.json`, `.git` history, `node_modules`, or build output. Add secrets again through the destination project’s secure settings before running the NVIDIA integration.
