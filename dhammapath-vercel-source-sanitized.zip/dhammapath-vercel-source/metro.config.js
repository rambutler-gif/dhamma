const { getDefaultConfig } = require("expo/metro-config");
const { withNativeWind } = require("nativewind/metro");

const config = getDefaultConfig(__dirname);

module.exports = withNativeWind(config, {
  input: "./global.css",
  // Keep filesystem CSS only during development. Production exports should
  // avoid transient react-native-css-interop cache files in node_modules.
  forceWriteFileSystem: process.env.NODE_ENV === "development",
});
