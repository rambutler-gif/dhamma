import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import type { Habit, PlanningItem, PlanningItemType } from "@/lib/types";

const ITEMS_KEY = "dhammapath-planning-items-v1";
const HABITS_KEY = "dhammapath-habits-v1";
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

type PlanningContextValue = {
  items: PlanningItem[];
  habits: Habit[];
  isLoaded: boolean;
  rolloverSummary: RolloverSummary | null;
  runWeeklyRollover: () => Promise<RolloverSummary>;
  captureCalendarEvent: (input: { title: string; date: string; eventId?: string }) => Promise<PlanningItem | null>;
  addItem: (input: { type: PlanningItemType; title: string; note: string; date: string }) => Promise<PlanningItem>;
  updateItem: (id: string, input: Partial<Pick<PlanningItem, "title" | "note" | "date" | "completed">>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  addHabit: (input: { title: string; note: string }) => Promise<Habit>;
  toggleHabit: (id: string, date: string) => Promise<void>;
  deleteHabit: (id: string) => Promise<void>;
};

const PlanningContext = createContext<PlanningContextValue | null>(null);

export type RolloverSummary = { ranAt: string; completedArchived: number; weeklyRolled: number; escalated: number };

function localDateKey(value: Date) {
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
}

export function weekStartKey(value = new Date()) {
  const date = new Date(value.getFullYear(), value.getMonth(), value.getDate());
  const day = date.getDay();
  date.setDate(date.getDate() - (day === 0 ? 6 : day - 1));
  return localDateKey(date);
}

export function applyWeeklyRollover(items: PlanningItem[], now = new Date()): { items: PlanningItem[]; summary: RolloverSummary } {
  const weekStart = weekStartKey(now);
  const nowIso = now.toISOString();
  let completedArchived = 0;
  let weeklyRolled = 0;
  let escalated = 0;
  const next = items.map((item) => {
    if (item.archivedAt || item.type === "diary" || item.date >= weekStart) return item;
    if (item.completed) {
      completedArchived += 1;
      return { ...item, archivedAt: nowIso };
    }
    const rolloverCount = (item.rolloverCount ?? 0) + 1;
    if (rolloverCount >= 2) {
      escalated += 1;
      return { ...item, date: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`, rolloverCount, escalated: true };
    }
    weeklyRolled += 1;
    return { ...item, date: weekStart, rolloverCount };
  });
  return { items: sortPlanningItems(next), summary: { ranAt: nowIso, completedArchived, weeklyRolled, escalated } };
}

export function sortPlanningItems(items: PlanningItem[]) {
  return [...items].sort((left, right) => left.date.localeCompare(right.date) || right.createdAt.localeCompare(left.createdAt));
}

export function parsePlanningArray<T>(value: string | null): T[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function PlanningProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<PlanningItem[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [rolloverSummary, setRolloverSummary] = useState<RolloverSummary | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(ITEMS_KEY), AsyncStorage.getItem(HABITS_KEY)]).then(async ([storedItems, storedHabits]) => {
      const loadedItems = sortPlanningItems(parsePlanningArray<PlanningItem>(storedItems));
      const processed = applyWeeklyRollover(loadedItems);
      setItems(processed.items);
      setHabits(parsePlanningArray<Habit>(storedHabits));
      setRolloverSummary(processed.summary);
      if (JSON.stringify(loadedItems) !== JSON.stringify(processed.items)) await AsyncStorage.setItem(ITEMS_KEY, JSON.stringify(processed.items));
      setIsLoaded(true);
    }).catch(() => setIsLoaded(true));
  }, []);

  const persistItems = useCallback(async (next: PlanningItem[]) => {
    const sorted = sortPlanningItems(next);
    setItems(sorted);
    await AsyncStorage.setItem(ITEMS_KEY, JSON.stringify(sorted));
  }, []);

  const runWeeklyRollover = useCallback(async () => {
    const processed = applyWeeklyRollover(items);
    setItems(processed.items);
    setRolloverSummary(processed.summary);
    if (JSON.stringify(items) !== JSON.stringify(processed.items)) await AsyncStorage.setItem(ITEMS_KEY, JSON.stringify(processed.items));
    return processed.summary;
  }, [items]);

  const persistHabits = useCallback(async (next: Habit[]) => {
    setHabits(next);
    await AsyncStorage.setItem(HABITS_KEY, JSON.stringify(next));
  }, []);

  const captureCalendarEvent = useCallback(async (input: { title: string; date: string; eventId?: string }) => {
    const title = input.title.trim();
    const date = input.date.trim().slice(0, 10);
    if (!title || !date) return null;
    const sourceEventId = input.eventId ?? `calendar:${date}:${title.toLocaleLowerCase()}`;
    const existing = items.find((item) => item.sourceEventId === sourceEventId);
    if (existing) return existing;
    const now = new Date().toISOString();
    const item: PlanningItem = { id: uid(), type: "diary", title, note: `Captured from calendar: ${title}`, date, completed: false, createdAt: now, sourceEventId, sourceEventTitle: title };
    await persistItems([item, ...items]);
    return item;
  }, [items, persistItems]);

  const addItem = useCallback(async (input: { type: PlanningItemType; title: string; note: string; date: string }) => {
    const now = new Date().toISOString();
    const item: PlanningItem = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type: input.type, title: input.title.trim(), note: input.note.trim(), date: input.date.trim(), completed: false, createdAt: now };
    await persistItems([item, ...items]);
    return item;
  }, [items, persistItems]);

  const updateItem = useCallback(async (id: string, input: Partial<Pick<PlanningItem, "title" | "note" | "date" | "completed">>) => {
    await persistItems(items.map((item) => item.id === id ? { ...item, ...input } : item));
  }, [items, persistItems]);

  const deleteItem = useCallback(async (id: string) => {
    await persistItems(items.filter((item) => item.id !== id));
  }, [items, persistItems]);

  const addHabit = useCallback(async (input: { title: string; note: string }) => {
    const habit: Habit = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title: input.title.trim(), note: input.note.trim(), createdAt: new Date().toISOString(), completedDates: [] };
    await persistHabits([...habits, habit]);
    return habit;
  }, [habits, persistHabits]);

  const toggleHabit = useCallback(async (id: string, date: string) => {
    await persistHabits(habits.map((habit) => habit.id !== id ? habit : { ...habit, completedDates: habit.completedDates.includes(date) ? habit.completedDates.filter((entry) => entry !== date) : [...habit.completedDates, date] }));
  }, [habits, persistHabits]);

  const deleteHabit = useCallback(async (id: string) => {
    await persistHabits(habits.filter((habit) => habit.id !== id));
  }, [habits, persistHabits]);

  const value = useMemo(() => ({ items, habits, isLoaded, rolloverSummary, runWeeklyRollover, captureCalendarEvent, addItem, updateItem, deleteItem, addHabit, toggleHabit, deleteHabit }), [items, habits, isLoaded, rolloverSummary, runWeeklyRollover, captureCalendarEvent, addItem, updateItem, deleteItem, addHabit, toggleHabit, deleteHabit]);
  return <PlanningContext.Provider value={value}>{children}</PlanningContext.Provider>;
}

export function usePlanning() {
  const context = useContext(PlanningContext);
  if (!context) throw new Error("usePlanning must be used within PlanningProvider");
  return context;
}

export function planningTypeLabel(type: PlanningItemType) {
  return type === "diary" ? "Diary" : type === "upcoming" ? "Upcoming work" : type === "move" ? "Important move" : "Goal";
}
