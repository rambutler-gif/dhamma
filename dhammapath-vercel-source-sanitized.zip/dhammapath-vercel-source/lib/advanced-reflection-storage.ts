import AsyncStorage from "@react-native-async-storage/async-storage";

export const ADVANCED_RESPONSES_KEY = "dhammapath-advanced-reflection-responses-v1";

export type AdvancedResponses = Record<string, string>;

export function parseAdvancedResponses(value: string | null): AdvancedResponses {
  if (!value) return {};
  try {
    const parsed: unknown = JSON.parse(value);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return Object.fromEntries(
      Object.entries(parsed).filter(([key, response]) => typeof key === "string" && typeof response === "string"),
    );
  } catch {
    return {};
  }
}

export function serializeAdvancedResponses(responses: AdvancedResponses): string {
  return JSON.stringify(responses);
}

export async function loadAdvancedResponses(): Promise<AdvancedResponses> {
  return parseAdvancedResponses(await AsyncStorage.getItem(ADVANCED_RESPONSES_KEY));
}

export async function saveAdvancedResponse(id: string, response: string): Promise<void> {
  const current = await loadAdvancedResponses();
  const next = { ...current, [id]: response.trim() };
  await AsyncStorage.setItem(ADVANCED_RESPONSES_KEY, serializeAdvancedResponses(next));
}

export async function clearAdvancedResponse(id: string): Promise<void> {
  const current = await loadAdvancedResponses();
  const next = { ...current };
  delete next[id];
  await AsyncStorage.setItem(ADVANCED_RESPONSES_KEY, serializeAdvancedResponses(next));
}
