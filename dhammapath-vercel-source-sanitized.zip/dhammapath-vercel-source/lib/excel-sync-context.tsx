import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useMemo, useState } from "react";
import { Platform } from "react-native";

import {
  appProjectToSync,
  appTaskToSync,
  appTrainingToSync,
  buildWorkbook,
  checklistToRows,
  mergeRecords,
  parseWorkbookBuffer,
  summarize,
  syncProjectToAppPatch,
  workbookToArrayBuffer,
} from "./excel-sync";
import { useExecutiveDashboard, type TaskPriority, type TaskSeverity } from "./executive-dashboard-context";
import { useOperational } from "./operational-context";
import type { ConflictResolution, OfficeTask as SyncOfficeTask, Project as SyncProject, SyncConflict, SyncSummary, TrainingRecord as SyncTrainingRecord } from "@/types/sync";

const LAST_SYNCED_KEY = "dhammapath-excel-last-synced-v1";
const VALID_SEVERITIES: TaskSeverity[] = ["High", "Medium", "Low"];
const VALID_PRIORITIES: TaskPriority[] = ["high", "medium", "low"];
const normalizeSeverity = (value?: string): TaskSeverity => (VALID_SEVERITIES as string[]).includes(value ?? "") ? (value as TaskSeverity) : "Medium";
const normalizePriority = (value?: string): TaskPriority => (VALID_PRIORITIES as string[]).includes(value ?? "") ? (value as TaskPriority) : "medium";

type AnyConflict = SyncConflict<SyncOfficeTask> | SyncConflict<SyncProject> | SyncConflict<SyncTrainingRecord>;

type ExcelSyncValue = {
  lastSyncedAt: string | null;
  lastSummary: SyncSummary | null;
  conflicts: AnyConflict[];
  isBusy: boolean;
  error: string | null;
  exportNow: () => Promise<void>;
  importFile: (file: File) => Promise<void>;
  resolveConflict: (conflict: AnyConflict, resolution: ConflictResolution) => Promise<void>;
};

const ExcelSyncContext = createContext<ExcelSyncValue | null>(null);
const today = () => new Date().toISOString().slice(0, 10);

export function ExcelSyncProvider({ children }: { children: React.ReactNode }) {
  const { tasks, updateTask, addTask } = useExecutiveDashboard();
  const { projects, trainings, checklists, addProject, updateProject, addTraining } = useOperational();
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const [lastSummary, setLastSummary] = useState<SyncSummary | null>(null);
  const [conflicts, setConflicts] = useState<AnyConflict[]>([]);
  const [isBusy, setIsBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const persistLastSyncedAt = useCallback(async (value: string) => {
    setLastSyncedAt(value);
    await AsyncStorage.setItem(LAST_SYNCED_KEY, value);
  }, []);

  const exportNow = useCallback(async () => {
    if (Platform.OS !== "web" || typeof document === "undefined") {
      setError("Excel export is available in the web version.");
      return;
    }
    setError(null);
    const wb = buildWorkbook({
      tasks: tasks.map(appTaskToSync),
      projects: projects.map(appProjectToSync),
      checklistRows: checklistToRows(checklists),
      trainings: trainings.map(appTrainingToSync),
    });
    const buffer = workbookToArrayBuffer(wb);
    const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `dhammapath-excel-connect-${today()}.xlsx`;
    anchor.click();
    URL.revokeObjectURL(url);
    await persistLastSyncedAt(new Date().toISOString());
  }, [tasks, projects, checklists, trainings, persistLastSyncedAt]);

  const importFile = useCallback(async (file: File) => {
    setIsBusy(true);
    setError(null);
    try {
      const buffer = await file.arrayBuffer();
      const parsed = parseWorkbookBuffer(buffer);

      const taskResult = mergeRecords(tasks.map(appTaskToSync), parsed.tasks, "task", lastSyncedAt);
      const projectResult = mergeRecords(projects.map(appProjectToSync), parsed.projects, "project", lastSyncedAt);
      const trainingResult = mergeRecords(trainings.map(appTrainingToSync), parsed.trainings, "training", lastSyncedAt);

      // Apply additions and non-conflicting updates immediately. Conflicts wait for the user.
      for (const t of taskResult.toAdd) {
        await addTask({ task: t.task, category: t.category, severity: normalizeSeverity(t.severity), priority: normalizePriority(t.priority), ownerName: t.owner, projectId: t.project, date: t.date, createdAt: t.createdAt, updatedAt: t.updatedAt });
      }
      for (const t of taskResult.toUpdate) {
        await updateTask(t.id, { task: t.task, category: t.category, priority: normalizePriority(t.priority), ownerName: t.owner, projectId: t.project, date: t.date });
      }

      for (const p of projectResult.toAdd) {
        await addProject({ product: p.product, name: p.name, teamMemberIds: [], remark: p.remark ?? "", status: (["planned", "active", "blocked", "waiting-to-deploy", "completed", "paused"].includes(p.status) ? p.status : "planned") as Parameters<typeof addProject>[0]["status"], deadline: p.deadline, reviewDate: p.reviewDate });
      }
      for (const p of projectResult.toUpdate) {
        await updateProject(p.id, syncProjectToAppPatch(p));
      }

      for (const tr of trainingResult.toAdd) await addTraining({ date: tr.date, topic: tr.topic });
      // Training has no update action in the app today (only add/delete), so training
      // updates and conflicts surface in the conflict queue for manual review instead
      // of a silent overwrite.

      const allConflicts: AnyConflict[] = [...taskResult.conflicts, ...projectResult.conflicts, ...trainingResult.conflicts];
      setConflicts(allConflicts);
      setLastSummary(summarize([taskResult, projectResult, trainingResult]));
      if (parsed.errors.length) setError(`${parsed.errors.length} row(s) skipped, see details.`);
      await persistLastSyncedAt(new Date().toISOString());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not read that file. Make sure it is a .xlsx exported by this app or matching its column headers.");
    } finally {
      setIsBusy(false);
    }
  }, [tasks, projects, trainings, checklists, lastSyncedAt, addTask, updateTask, addProject, updateProject, addTraining, persistLastSyncedAt]);

  const resolveConflict = useCallback(async (conflict: AnyConflict, resolution: ConflictResolution) => {
    if (resolution === "keep-app") {
      setConflicts((current) => current.filter((c) => c !== conflict));
      return;
    }
    if (conflict.entityType === "task") {
      const t = conflict.excelVersion as SyncOfficeTask;
      await updateTask(conflict.id, { task: t.task, category: t.category, priority: normalizePriority(t.priority), ownerName: t.owner, projectId: t.project, date: t.date });
    } else if (conflict.entityType === "project") {
      await updateProject(conflict.id, syncProjectToAppPatch(conflict.excelVersion as SyncProject));
    }
    // Training conflicts: no update action exists yet, "keep excel" is a no-op until that's added.
    setConflicts((current) => current.filter((c) => c !== conflict));
  }, [updateTask, updateProject]);

  const value = useMemo(() => ({ lastSyncedAt, lastSummary, conflicts, isBusy, error, exportNow, importFile, resolveConflict }), [lastSyncedAt, lastSummary, conflicts, isBusy, error, exportNow, importFile, resolveConflict]);
  return <ExcelSyncContext.Provider value={value}>{children}</ExcelSyncContext.Provider>;
}

export function useExcelSync() {
  const value = useContext(ExcelSyncContext);
  if (!value) throw new Error("useExcelSync must be used within ExcelSyncProvider");
  return value;
}
