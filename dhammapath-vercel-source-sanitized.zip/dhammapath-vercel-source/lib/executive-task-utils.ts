export function nextForwardDate(value: string) {
  const date = new Date(`${value}T12:00:00`);
  date.setDate(date.getDate() + 7);
  return date.toISOString().slice(0, 10);
}
