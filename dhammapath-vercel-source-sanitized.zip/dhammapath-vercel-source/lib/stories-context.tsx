import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import type { DhammaInsight, EmotionCheckIn, Feeling, Story, StructuredReflection } from "@/lib/types";

const STORAGE_KEY = "dhamma-thought-adviser-stories-v1";

type StoriesContextValue = {
  stories: Story[];
  isLoaded: boolean;
  addStory: (input: { title: string; content: string; feeling: Feeling; where?: string; boxId?: string; structured?: StructuredReflection }) => Promise<Story>;
  updateStory: (id: string, input: Partial<Pick<Story, "structured" | "followUp" | "insight" | "reflectionAnswers" | "emotionCheckIns">>) => Promise<void>;
  addEmotionCheckIn: (id: string, input: Omit<EmotionCheckIn, "id" | "createdAt">) => Promise<void>;
  deleteStory: (id: string) => Promise<void>;
  clearStories: () => Promise<void>;
};

const StoriesContext = createContext<StoriesContextValue | null>(null);

function sortStories(stories: Story[]) {
  return [...stories].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function StoriesProvider({ children }: { children: React.ReactNode }) {
  const [stories, setStories] = useState<Story[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((value) => {
        if (!active) return;
        if (value) {
          try {
            const parsed = JSON.parse(value) as Story[];
            setStories(sortStories(Array.isArray(parsed) ? parsed : []));
          } catch {
            setStories([]);
          }
        }
        setIsLoaded(true);
      })
      .catch(() => setIsLoaded(true));
    return () => {
      active = false;
    };
  }, []);

  const persist = useCallback(async (nextStories: Story[]) => {
    const sorted = sortStories(nextStories);
    setStories(sorted);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sorted));
  }, []);

  const addStory = useCallback(
    async (input: { title: string; content: string; feeling: Feeling; where?: string; boxId?: string; structured?: StructuredReflection }) => {
      const now = new Date().toISOString();
      const story: Story = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        title: input.title.trim(),
        content: input.content.trim(),
        structured: input.structured,
        feeling: input.feeling,
        where: input.where,
        boxId: input.boxId,
        createdAt: now,
        updatedAt: now,
      };
      await persist([story, ...stories]);
      return story;
    },
    [persist, stories],
  );

  const updateStory = useCallback(
    async (id: string, input: Partial<Pick<Story, "structured" | "followUp" | "insight" | "reflectionAnswers" | "emotionCheckIns">>) => {
      const next = stories.map((story) =>
        story.id === id ? { ...story, ...input, updatedAt: new Date().toISOString() } : story,
      );
      await persist(next);
    },
    [persist, stories],
  );

  const addEmotionCheckIn = useCallback(
    async (id: string, input: Omit<EmotionCheckIn, "id" | "createdAt">) => {
      const checkIn: EmotionCheckIn = {
        ...input,
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        createdAt: new Date().toISOString(),
      };
      const next = stories.map((story) =>
        story.id === id
          ? { ...story, emotionCheckIns: [...(story.emotionCheckIns ?? []), checkIn], updatedAt: new Date().toISOString() }
          : story,
      );
      await persist(next);
    },
    [persist, stories],
  );

  const deleteStory = useCallback(
    async (id: string) => {
      await persist(stories.filter((story) => story.id !== id));
    },
    [persist, stories],
  );

  const clearStories = useCallback(async () => {
    await persist([]);
  }, [persist]);

  const value = useMemo(
    () => ({ stories, isLoaded, addStory, updateStory, addEmotionCheckIn, deleteStory, clearStories }),
    [stories, isLoaded, addStory, updateStory, addEmotionCheckIn, deleteStory, clearStories],
  );

  return <StoriesContext.Provider value={value}>{children}</StoriesContext.Provider>;
}

export function useStories() {
  const context = useContext(StoriesContext);
  if (!context) throw new Error("useStories must be used within StoriesProvider");
  return context;
}

export function getStoryById(stories: Story[], id: string | undefined) {
  return stories.find((story) => story.id === id);
}

export type { DhammaInsight };
