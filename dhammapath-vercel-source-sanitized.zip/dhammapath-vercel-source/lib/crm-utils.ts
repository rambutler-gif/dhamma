import type { Person } from "@/lib/people-context";

export function overduePeople(people: Person[], today = new Date().toISOString().slice(0, 10)) {
  return people.filter((person) => Boolean(person.nextContact && person.nextContact < today));
}

export function dueSoonPeople(people: Person[], today = new Date().toISOString().slice(0, 10), horizonDays = 7) {
  const start = new Date(`${today}T12:00:00`);
  const end = new Date(start);
  end.setDate(end.getDate() + horizonDays);
  return people.filter((person) => {
    if (!person.nextContact) return false;
    const date = new Date(`${person.nextContact}T12:00:00`);
    return date >= start && date <= end;
  });
}

export function crmWeeklyReport(people: Person[], today = new Date().toISOString().slice(0, 10)) {
  const overdue = overduePeople(people, today);
  const dueSoon = dueSoonPeople(people, today);
  const interactions = people.reduce((sum, person) => sum + person.interactions.filter((item) => item.date >= weekStart(today)).length, 0);
  return { totalPeople: people.length, overdue: overdue.length, dueSoon: dueSoon.length, interactions, coverage: people.length ? Math.round((people.filter((person) => person.lastContacted).length / people.length) * 100) : 0 };
}

export type PrioritySummaryTask = { id: string; task: string; date: string; priority?: "high" | "medium" | "low"; contactName?: string; status: string; rolloverCount: number };

export function weeklyPrioritySummary(tasks: PrioritySummaryTask[], today = new Date().toISOString().slice(0, 10), priority: "all" | "high" | "medium" | "low" = "high", contactName?: string) {
  const start = weekStart(today);
  const endDate = new Date(`${start}T12:00:00`);
  endDate.setDate(endDate.getDate() + 6);
  const end = endDate.toISOString().slice(0, 10);
  const selected = tasks.filter((task) => (priority === "all" || task.priority === priority) && (!contactName || task.contactName === contactName || task.task.toLocaleLowerCase().includes(contactName.toLocaleLowerCase())) && task.date >= start && task.date <= end);
  const completed = selected.filter((task) => task.status === "done");
  const pending = selected.filter((task) => task.status !== "done");
  const alerts = pending.filter((task) => task.date < today || task.rolloverCount >= 2);
  return { start, end, completed, pending, alerts, completedCount: completed.length, pendingCount: pending.length, alertCount: alerts.length, priority, contactName };
}

function weekStart(today: string) {
  const date = new Date(`${today}T12:00:00`);
  const day = date.getDay();
  date.setDate(date.getDate() - (day === 0 ? 6 : day - 1));
  return date.toISOString().slice(0, 10);
}
