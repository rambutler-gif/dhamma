import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type ChecklistItem = { id: string; title: string; note: string; active: boolean; completedDates: string[]; createdAt: string; updatedAt: string };
export type TeamMember = { id: string; name: string; role: string; createdAt: string };
export type ProjectStatus = "planned" | "active" | "blocked" | "waiting-to-deploy" | "completed" | "paused";
export type Project = { id: string; product: string; name: string; teamMemberIds: string[]; ownerId?: string; deadline?: string; reviewDate?: string; remark: string; status: ProjectStatus; createdAt: string; updatedAt: string };
export type TrainingRecord = { id: string; date: string; topic: string; createdAt: string; updatedAt: string };

type OperationalValue = {
  checklists: ChecklistItem[];
  teamMembers: TeamMember[];
  projects: Project[];
  trainings: TrainingRecord[];
  isLoaded: boolean;
  addChecklist: (input: { title: string; note: string }) => Promise<void>;
  deleteChecklist: (id: string) => Promise<void>;
  toggleChecklistDate: (id: string, date: string) => Promise<void>;
  addTeamMember: (input: { name: string; role: string }) => Promise<void>;
  deleteTeamMember: (id: string) => Promise<void>;
  addProject: (input: Omit<Project, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateProject: (id: string, input: Partial<Omit<Project, "id" | "createdAt" | "updatedAt">>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  addTraining: (input: { date: string; topic: string }) => Promise<void>;
  deleteTraining: (id: string) => Promise<void>;
};

const KEYS = { checklists: "dhammapath-operational-checklists-v1", team: "dhammapath-operational-team-v1", projects: "dhammapath-operational-projects-v1", trainings: "dhammapath-operational-trainings-v1" };
const OperationalContext = createContext<OperationalValue | null>(null);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const parse = <T,>(value: string | null): T[] => { if (!value) return []; try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch { return []; } };

export function OperationalProvider({ children }: { children: React.ReactNode }) {
  const [checklists, setChecklists] = useState<ChecklistItem[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [trainings, setTrainings] = useState<TrainingRecord[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => { Promise.all(Object.values(KEYS).map((key) => AsyncStorage.getItem(key))).then(([c, t, p, tr]) => { setChecklists(parse<ChecklistItem>(c)); setTeamMembers(parse<TeamMember>(t)); setProjects(parse<Project>(p)); setTrainings(parse<TrainingRecord>(tr)); setIsLoaded(true); }).catch(() => setIsLoaded(true)); }, []);
  const persist = useCallback(async <T,>(key: string, next: T[], setter: (value: T[]) => void) => { setter(next); await AsyncStorage.setItem(key, JSON.stringify(next)); }, []);
  const addChecklist = useCallback(async ({ title, note }: { title: string; note: string }) => { const now = new Date().toISOString(); const value = { id: uid(), title: title.trim(), note: note.trim(), active: true, completedDates: [], createdAt: now, updatedAt: now }; await persist(KEYS.checklists, [...checklists, value], setChecklists); }, [checklists, persist]);
  const deleteChecklist = useCallback(async (id: string) => persist(KEYS.checklists, checklists.filter((item) => item.id !== id), setChecklists), [checklists, persist]);
  const toggleChecklistDate = useCallback(async (id: string, date: string) => persist(KEYS.checklists, checklists.map((item) => item.id === id ? { ...item, completedDates: item.completedDates.includes(date) ? item.completedDates.filter((entry) => entry !== date) : [...item.completedDates, date], updatedAt: new Date().toISOString() } : item), setChecklists), [checklists, persist]);
  const addTeamMember = useCallback(async ({ name, role }: { name: string; role: string }) => { if (!name.trim()) return; const value = { id: uid(), name: name.trim(), role: role.trim(), createdAt: new Date().toISOString() }; await persist(KEYS.team, [...teamMembers, value], setTeamMembers); }, [teamMembers, persist]);
  const deleteTeamMember = useCallback(async (id: string) => persist(KEYS.team, teamMembers.filter((item) => item.id !== id), setTeamMembers), [teamMembers, persist]);
  const addProject = useCallback(async (input: Omit<Project, "id" | "createdAt" | "updatedAt">) => { const now = new Date().toISOString(); const value = { ...input, id: uid(), createdAt: now, updatedAt: now }; await persist(KEYS.projects, [...projects, value], setProjects); }, [projects, persist]);
  const updateProject = useCallback(async (id: string, input: Partial<Omit<Project, "id" | "createdAt" | "updatedAt">>) => persist(KEYS.projects, projects.map((project) => project.id === id ? { ...project, ...input, updatedAt: new Date().toISOString() } : project), setProjects), [projects, persist]);
  const deleteProject = useCallback(async (id: string) => persist(KEYS.projects, projects.filter((project) => project.id !== id), setProjects), [projects, persist]);
  const addTraining = useCallback(async ({ date, topic }: { date: string; topic: string }) => { if (!date.trim() || !topic.trim()) return; const now = new Date().toISOString(); const value = { id: uid(), date: date.trim().slice(0, 10), topic: topic.trim(), createdAt: now, updatedAt: now }; await persist(KEYS.trainings, [...trainings, value].sort((a, b) => a.date.localeCompare(b.date)), setTrainings); }, [trainings, persist]);
  const deleteTraining = useCallback(async (id: string) => persist(KEYS.trainings, trainings.filter((training) => training.id !== id), setTrainings), [trainings, persist]);
  const value = useMemo(() => ({ checklists, teamMembers, projects, trainings, isLoaded, addChecklist, deleteChecklist, toggleChecklistDate, addTeamMember, deleteTeamMember, addProject, updateProject, deleteProject, addTraining, deleteTraining }), [checklists, teamMembers, projects, trainings, isLoaded, addChecklist, deleteChecklist, toggleChecklistDate, addTeamMember, deleteTeamMember, addProject, updateProject, deleteProject, addTraining, deleteTraining]);
  return <OperationalContext.Provider value={value}>{children}</OperationalContext.Provider>;
}
export function useOperational() { const value = useContext(OperationalContext); if (!value) throw new Error("useOperational must be used within OperationalProvider"); return value; }
export function monthCompletion(item: ChecklistItem, year: number, month: number) { const prefix = `${year}-${String(month + 1).padStart(2, "0")}-`; return item.completedDates.filter((date) => date.startsWith(prefix)).length; }
