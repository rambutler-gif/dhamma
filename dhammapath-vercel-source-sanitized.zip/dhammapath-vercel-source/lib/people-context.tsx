import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type PersonRelationship = "owner" | "supplier" | "guest" | "excom" | "family" | "friend" | "other";
export type PersonInteraction = { id: string; date: string; summary: string; channel?: string };
export type Person = { id: string; name: string; relationship: PersonRelationship; lastContacted?: string; nextContact?: string; notes: string; room?: string; createdAt: string; interactions: PersonInteraction[] };

export function matchPeopleInText(text: string, people: Person[]) {
  const source = text.toLocaleLowerCase();
  return people.filter((person) => person.name.trim().length > 1 && source.includes(person.name.toLocaleLowerCase())).map((person) => person.id);
}

export function contactDateFromEvent(eventDate: string) { return eventDate.slice(0, 10); }

const PEOPLE_KEY = "dhammapath-people-v1";
const PeopleContext = createContext<{
  people: Person[];
  isLoaded: boolean;
  addPerson: (input: Omit<Person, "id" | "createdAt">) => Promise<Person>;
  updatePerson: (id: string, input: Partial<Omit<Person, "id" | "createdAt">>) => Promise<void>;
  deletePerson: (id: string) => Promise<void>;
  markContactedFromEvent: (eventTitle: string, eventDate: string) => Promise<string[]>;
  recordInteraction: (id: string, input: { date: string; summary: string; channel?: string }) => Promise<void>;
} | null>(null);

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

function normalizePerson(value: Partial<Person>): Person {
  return { id: value.id ?? uid(), name: value.name ?? "", relationship: value.relationship ?? "other", lastContacted: value.lastContacted, nextContact: value.nextContact, notes: value.notes ?? "", room: value.room, createdAt: value.createdAt ?? new Date().toISOString(), interactions: Array.isArray(value.interactions) ? value.interactions : [] };
}

export function PeopleProvider({ children }: { children: React.ReactNode }) {
  const [people, setPeople] = useState<Person[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  useEffect(() => { AsyncStorage.getItem(PEOPLE_KEY).then((value) => { try { const parsed = value ? JSON.parse(value) : []; setPeople(Array.isArray(parsed) ? parsed.map(normalizePerson) : []); } catch { setPeople([]); } setIsLoaded(true); }).catch(() => setIsLoaded(true)); }, []);
  const persist = useCallback(async (next: Person[]) => { setPeople(next); await AsyncStorage.setItem(PEOPLE_KEY, JSON.stringify(next)); }, []);
  const addPerson = useCallback(async (input: Omit<Person, "id" | "createdAt">) => { const person: Person = { ...input, id: uid(), createdAt: new Date().toISOString() }; await persist([...people, person]); return person; }, [people, persist]);
  const updatePerson = useCallback(async (id: string, input: Partial<Omit<Person, "id" | "createdAt">>) => { await persist(people.map((person) => person.id === id ? { ...person, ...input } : person)); }, [people, persist]);
  const deletePerson = useCallback(async (id: string) => { await persist(people.filter((person) => person.id !== id)); }, [people, persist]);
  const markContactedFromEvent = useCallback(async (eventTitle: string, eventDate: string) => { const matched = matchPeopleInText(eventTitle, people); if (matched.length === 0) return matched; await persist(people.map((person) => matched.includes(person.id) ? { ...person, lastContacted: contactDateFromEvent(eventDate), interactions: [...person.interactions, { id: uid(), date: contactDateFromEvent(eventDate), summary: eventTitle, channel: "Calendar" }] } : person)); return matched; }, [people, persist]);
  const recordInteraction = useCallback(async (id: string, input: { date: string; summary: string; channel?: string }) => { await persist(people.map((person) => person.id === id ? { ...person, lastContacted: input.date.slice(0, 10), interactions: [...person.interactions, { id: uid(), date: input.date.slice(0, 10), summary: input.summary.trim(), channel: input.channel?.trim() || undefined }] } : person)); }, [people, persist]);
  return <PeopleContext.Provider value={useMemo(() => ({ people, isLoaded, addPerson, updatePerson, deletePerson, markContactedFromEvent, recordInteraction }), [people, isLoaded, addPerson, updatePerson, deletePerson, markContactedFromEvent, recordInteraction])}>{children}</PeopleContext.Provider>;
}

export function usePeople() { const value = useContext(PeopleContext); if (!value) throw new Error("usePeople must be used within PeopleProvider"); return value; }
