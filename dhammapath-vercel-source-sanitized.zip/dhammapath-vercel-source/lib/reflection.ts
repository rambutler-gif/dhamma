import { REFLECTION_QUESTIONS, type DhammaInsight, type Feeling, type Habit, type MeProfile, type PlanningItem, type ReflectionAnswer, type ReflectionQuestion, type Story, type ThoughtBox } from "./types";
import { getDhammaKeys, inferDhammaKeyIds } from "./dhamma-keys";

const crisisTerms = [
  "kill myself",
  "end my life",
  "suicide",
  "self harm",
  "hurt myself",
  "do not want to live",
  "don't want to live",
  "no reason to live",
];

export function getReflectionQuestions(box?: ThoughtBox): ReflectionQuestion[] {
  if (!box) return REFLECTION_QUESTIONS;
  return [...REFLECTION_QUESTIONS, { id: "master-script", label: box.name, prompt: box.prompt, helper: box.script }];
}

export function containsCrisisLanguage(value: string) {
  const normalized = value.toLowerCase();
  return crisisTerms.some((term) => normalized.includes(term));
}

export function buildMeProfileContext(profile?: MeProfile) {
  if (!profile) return "";
  return Object.entries(profile)
    .filter(([, value]) => value.trim())
    .map(([key, value]) => `${key}: ${value.trim()}`)
    .join(" | ");
}

export function buildConnectedRoomContext(boxes: ThoughtBox[], activeBoxId?: string) {
  return boxes
    .filter((box) => box.id !== activeBoxId)
    .map((box) => `${box.name}: ${box.script}`)
    .join(" | ");
}

export function buildPlanningContext(items: PlanningItem[], habits: Habit[]) {
  const itemText = items.filter((item) => !item.completed).slice(0, 8).map((item) => `${item.type}: ${item.title} (${item.date})`).join(" | ");
  const habitText = habits.slice(0, 8).map((habit) => `habit: ${habit.title}`).join(" | ");
  return [itemText, habitText].filter(Boolean).join(" | ");
}

export function buildPriorStoryContext(stories: Story[], currentStoryId: string) {
  return stories
    .filter((story) => story.id !== currentStoryId)
    .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))
    .slice(0, 9)
    .map((story) => `${story.title} (${story.createdAt.slice(0, 10)}): ${story.feeling}. ${story.content}`)
    .join(" | ");
}

function answerFor(answers: ReflectionAnswer[], id: string) {
  return answers.find((answer) => answer.questionId === id)?.answer.trim() ?? "";
}

function hasAny(value: string, terms: string[]) {
  const normalized = value.toLowerCase();
  return terms.some((term) => normalized.includes(term));
}

function buildLocalInsight(story: Story, answers: ReflectionAnswer[], masterScript = "", connectedRoomContext = "", priorStoryContext = "", meProfileContext = "", planningContext = ""): DhammaInsight {
  const allText = [
    story.title,
    story.content,
    story.feeling,
    story.where ?? "",
    masterScript,
    connectedRoomContext,
    priorStoryContext,
    meProfileContext,
    planningContext,
    ...Object.values(story.structured ?? {}),
    ...answers.map((answer) => answer.answer),
  ].join(" ");
  const feeling = story.feeling;
  const desired = answerFor(answers, "want");
  const facts = story.structured?.facts?.trim();
  const assumptions = story.structured?.assumptions?.trim();
  const cravingText = story.structured?.craving?.trim();
  const fearText = story.structured?.fear?.trim();
  const angerText = story.structured?.anger?.trim();
  const selfStoryText = story.structured?.selfStory?.trim();

  if (selfStoryText) {
    return {
      seeingClearly: `A self-story is present: “${selfStoryText}” The sentence can be noticed without treating it as a permanent identity.`,
      possibleWrongView: "Possible wrong view: turning a changing experience into a final verdict about who you are.",
      meaning: "A self-story is a thought shaped by memory, feeling, and conditions. It may describe pain, but it is not the whole person.",
      wiserSubstitute: "A wiser view is to speak precisely: this feeling is present, this event happened, and this condition may change. Keep dignity without building a fixed self.",
      smallPractice: "Rewrite the self-story as a present condition. Begin with: ‘Right now, I notice…’",
      principle: "Impermanence, wise attention, and compassion",
    };
  }

  if (cravingText) {
    return {
      seeingClearly: `Strong wanting is present: “${cravingText}” Wanting can be known clearly without being obeyed immediately.`,
      possibleWrongView: "Possible wrong view: treating a desired result as necessary for peace, worth, or safety.",
      meaning: "Craving is not a moral failure. Suffering grows when the mind clings to a result and resists the changing conditions around it.",
      wiserSubstitute: "A wiser view is to name the wish, examine its conditions, and act without grasping. Let other people and outcomes retain their freedom.",
      smallPractice: "Name the wish in one sentence. Then name one harmless action that does not depend on getting the result.",
      principle: "Four Noble Truths, non-clinging, and right intention",
    };
  }

  if (hasAny(allText, ["divorce", "separation", "breakup", "fight", "argument"])) {
    return {
      seeingClearly:
        "There was pain, conflict, and a story about what should have happened. The pain is real. The future outcome is not fully in your hands.",
      possibleWrongView:
        "Possible wrong view: believing that another person's change, apology, or agreement is required before you can begin to heal.",
      meaning:
        "Wrong view, samma ditthi's opposite, means seeing conditions as more fixed or controllable than they are. It does not mean you are a bad person. It means the mind is adding a demand to an already painful fact.",
      wiserSubstitute:
        "A wiser view is this: the past cannot be made different. Your present intention can still become careful, truthful, and non-harming. You may grieve without feeding revenge. You may set a boundary without hatred.",
      smallPractice:
        "Before the next difficult message, pause for three breaths. Ask: will these words reduce harm, or continue the fight? Send nothing until the answer is clear.",
      principle: "Impermanence, non-harming, and right speech",
    };
  }

  if (feeling === "longing" || hasAny(allText, ["like a girl", "like him", "love", "crush", "attracted"])) {
    return {
      seeingClearly:
        "A feeling of attraction has arisen. Feeling is present. The other person remains a separate person with their own freedom and conditions.",
      possibleWrongView:
        "Possible wrong view: treating an imagined future as known, or treating desire as proof that this person must become yours.",
      meaning:
        "This is wrong view when the mind confuses a pleasant image with reality. Wanting closeness is not wrong. Clinging, possession, and certainty can create suffering for both people.",
      wiserSubstitute:
        `A wiser view is to know desire as desire. Learn who the person is. Speak honestly without pressure. Allow a free answer. Respect the other person's freedom. ${desired ? "Let your wish be known, without making the result your identity." : "Do not build a full story from a few moments."}`,
      smallPractice:
        "Write two columns: what you know, and what you are imagining. Act only from what you know. Keep the other person's freedom visible.",
      principle: "Mindfulness, non-clinging, and right intention",
    };
  }

  if (angerText || feeling === "anger" || hasAny(allText, ["hate", "betray", "unfair", "revenge", "furious"])) {
    return {
      seeingClearly:
        angerText
          ? `Anger has been named: “${angerText}” It may be protecting hurt, fear, or a wish to be respected. Anger is an event in the mind, not a permanent identity.`
          : "Anger is present. It may be protecting hurt, fear, or a wish to be respected. Anger is an event in the mind, not a permanent identity.",
      possibleWrongView:
        "Possible wrong view: believing that returning harm will remove the original pain, or that anger gives a complete picture of the other person.",
      meaning:
        "The mind has narrowed around one painful interpretation. It may ignore conditions, consequences, and the other person's limited understanding. Seeing this is not excusing harm.",
      wiserSubstitute:
        "A wiser view is to protect yourself without feeding hatred. Name the boundary. Name the request. Choose words that are firm, truthful, and not designed to wound.",
      smallPractice:
        "Delay the response for ten minutes. Feel the heat in the body. Then write one sentence that states the fact and one sentence that states the boundary.",
      principle: "Right speech, harmlessness, and wise effort",
    };
  }

  if (fearText || feeling === "fear" || hasAny(allText, ["worried", "anxious", "uncertain", "afraid"])) {
    return {
      seeingClearly:
        fearText
          ? `Fear has been named: “${fearText}” The mind is trying to protect you by predicting danger. A prediction is not yet a fact.`
          : "Fear is present. The mind is trying to protect you by predicting danger. A prediction is not yet a fact.",
      possibleWrongView:
        "Possible wrong view: treating the most feared outcome as certain, then making every decision from that imagined certainty.",
      meaning:
        "Fear becomes confusing when possibility is mistaken for reality. Wise view does not deny risk. It measures risk, sees conditions, and chooses a non-harming response.",
      wiserSubstitute:
        "A wiser view is to separate what is known, what is possible, and what can be done now. You can prepare without rehearsing suffering all day.",
      smallPractice:
        "Say quietly: known, possible, next. Name one fact, one uncertainty, and one kind action for the next hour.",
      principle: "Mindfulness, clear comprehension, and wise effort",
    };
  }

  if (feeling === "sadness" || hasAny(allText, ["grief", "lost", "lonely", "empty"])) {
    const relatedLoss = hasAny(priorStoryContext, ["grandma", "grandmother", "pet", "loss", "lost", "grief", "died", "death", "passed"]);
    return {
      seeingClearly: relatedLoss
        ? "Today’s sadness is real. An earlier loss may be echoing through it, but the present feeling still has its own time and conditions. Meet this moment as it is."
        : "Sadness is present. It asks to be felt with care. It does not prove that your life is without meaning or that this state will never change.",
      possibleWrongView:
        "Possible wrong view: making a passing painful state into a permanent conclusion about yourself, your future, or your worth, or claiming certainty about another being’s karma.",
      meaning:
        "The mind is turning present pain into a fixed self-story. Feelings have causes and conditions. Because conditions change, the feeling can change too. Dhamma does not require us to know the full workings of karma.",
      wiserSubstitute:
        "A wiser view is to honour the life that was here, accept that beings and conditions change, and keep the heart free from forced certainty. Let gratitude become anumodanā: rejoice in wholesome qualities and dedicate a kind intention without demanding a particular result.",
      smallPractice:
        "Name today’s feeling. Remember one wholesome quality or moment. Then offer a quiet anumodanā and take one caring action for the living beings around you.",
      principle: "Impermanence, compassion, gratitude, and wise attention",
    };
  }

  return {
    seeingClearly:
      facts && assumptions
        ? `You have named what is known and what is assumed. Facts can be held carefully; assumptions can be examined without becoming conclusions. ${facts}`
        : "A thought and feeling have appeared together. We can observe both without immediately obeying either one.",
    possibleWrongView:
      "Possible wrong view: assuming that the first interpretation is the whole truth, or that a feeling must become an action.",
    meaning:
      "The mind receives an event, adds meaning, and then reacts to its own meaning. Clear seeing creates a small space between feeling and action.",
    wiserSubstitute:
      "A wiser view is to ask what is known, what is assumed, and what action reduces harm. Let the next choice be honest, steady, and free from needless pressure.",
    smallPractice:
      "Pause before the next action. Name the feeling. Name the wish. Choose one response that you would respect tomorrow.",
    principle: "Mindfulness, right intention, and non-harming",
  };
}

export function buildInsight(story: Story, answers: ReflectionAnswer[], masterScript = "", connectedRoomContext = "", priorStoryContext = "", meProfileContext = "", planningContext = ""): DhammaInsight {
  const insight = buildLocalInsight(story, answers, masterScript, connectedRoomContext, priorStoryContext, meProfileContext, planningContext);
  const allText = [story.title, story.content, story.feeling, story.where ?? "", ...Object.values(story.structured ?? {}), ...answers.map((answer) => answer.answer)].join(" ");
  const mentorQuestion = story.structured?.assumptions?.trim()
    ? "What would change if this assumption stayed a question for one more day?"
    : "What changed in the moment before this feeling became a conclusion?";
  const potentialDirection = story.feeling === "anger"
    ? "This moment may train firm care without hatred."
    : story.feeling === "fear"
      ? "This moment may train preparation without surrendering to prediction."
      : story.feeling === "sadness"
        ? "This moment may train tenderness without turning loss into a permanent identity."
        : "This moment may train a more truthful, less harmful way of meeting conditions.";
  return { ...insight, dhammaKeys: getDhammaKeys(inferDhammaKeyIds(allText, story.feeling)), mentorQuestion, potentialDirection };
}
