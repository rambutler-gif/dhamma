import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Crypto from "expo-crypto";
import * as SecureStore from "expo-secure-store";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";

import type { MeProfile, ThoughtBox } from "@/lib/types";

const BOXES_KEY = "dhamma-thought-boxes-v1";
const ME_PROFILE_KEY = "dhammapath-me-profile-v1";
const PASSWORD_KEY = "dhamma-master-password-digest-v1";

export const DEFAULT_BOXES: ThoughtBox[] = [
  { id: "me", name: "Me", description: "The central office connecting every part of life.", prompt: "What is happening in me, beneath this Room?", accent: "#1B2A25", script: "Hold the whole person in view. Notice changing feelings, intentions, conditions, responsibilities, and freedom. Let each Room remain distinct while returning to non-harming, clear seeing, and compassion." },
  { id: "work", name: "My work", description: "Decisions, people, and responsibilities.", prompt: "What is the most important work situation to see clearly?", accent: "#B56A38", script: "Look at duty, intention, speech, and consequence. Separate what is yours to do from what belongs to others." },
  { id: "personal", name: "My personal", description: "Home, family, feelings, and relationships.", prompt: "What is moving in your personal life?", accent: "#B56A38", script: "Meet feeling with honesty. Protect boundaries without feeding blame. Remember that people act from changing conditions." },
  { id: "project-1", name: "Project 1", description: "A space for one important project.", prompt: "What is the next clear step for this project?", accent: "#587A5A", script: "See the aim, the conditions, and the next harmless action. Do not confuse planning with control." },
  { id: "project-2", name: "Project 2", description: "A second space for focused thinking.", prompt: "What needs attention in this project?", accent: "#587A5A", script: "Notice craving for completion. Return to causes, conditions, effort, and patient progress." },
  { id: "career", name: "Career", description: "Direction, growth, and wise livelihood.", prompt: "What kind of work would support a meaningful life?", accent: "#8065A8", script: "Consider livelihood, values, skill, and impact. Do not measure the whole self by status or income." },
  { id: "travel", name: "Travel", description: "Places, plans, and new experiences.", prompt: "What do you hope travel will teach or change?", accent: "#3E7A83", script: "Enjoy discovery without demanding permanence. Plan carefully, stay present, and let experience be experience." },
  { id: "business", name: "Business ideas", description: "Ideas, risks, and useful possibilities.", prompt: "What problem could this idea solve without causing harm?", accent: "#A27632", script: "Examine intention, benefit, risk, and livelihood. Let wisdom guide ambition, not greed or fear." },
];

export const EMPTY_ME_PROFILE: MeProfile = {
  name: "",
  lifeStage: "",
  importantPeople: "",
  values: "",
  responsibilities: "",
  guidancePreference: "",
};

type PrivateSpaceContextValue = {
  boxes: ThoughtBox[];
  meProfile: MeProfile;
  isLoaded: boolean;
  isLocked: boolean;
  hasPassword: boolean;
  unlock: (password: string) => Promise<boolean>;
  verifyPassword: (password: string) => Promise<boolean>;
  setMasterPassword: (password: string) => Promise<void>;
  changeMasterPassword: (current: string, next: string) => Promise<boolean>;
  updateBox: (id: string, input: Partial<Pick<ThoughtBox, "name" | "description" | "prompt" | "script">>) => Promise<void>;
  updateMeProfile: (input: Partial<MeProfile>) => Promise<void>;
  deleteBox: (id: string) => Promise<void>;
  addBox: (input: Pick<ThoughtBox, "name" | "description" | "prompt" | "script">) => Promise<ThoughtBox>;
  lock: () => void;
};

const PrivateSpaceContext = createContext<PrivateSpaceContextValue | null>(null);

async function secureGet(key: string) {
  if (Platform.OS === "web") return typeof localStorage === "undefined" ? null : localStorage.getItem(key);
  return SecureStore.getItemAsync(key);
}

async function secureSet(key: string, value: string) {
  if (Platform.OS === "web") { localStorage.setItem(key, value); return; }
  await SecureStore.setItemAsync(key, value, { requireAuthentication: false });
}

async function digest(password: string) {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, password);
}

export function PrivateSpaceProvider({ children }: { children: React.ReactNode }) {
  const [boxes, setBoxes] = useState<ThoughtBox[]>(DEFAULT_BOXES);
  const [meProfile, setMeProfile] = useState<MeProfile>(EMPTY_ME_PROFILE);
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasPassword, setHasPassword] = useState(false);
  const [isLocked, setIsLocked] = useState(true);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(BOXES_KEY), AsyncStorage.getItem(ME_PROFILE_KEY), secureGet(PASSWORD_KEY)]).then(([storedBoxes, storedProfile, storedPassword]) => {
      if (storedBoxes) {
        try {
          const parsed = JSON.parse(storedBoxes) as ThoughtBox[];
          if (Array.isArray(parsed)) {
            setBoxes(parsed.some((box) => box.id === "me") ? parsed : [DEFAULT_BOXES[0], ...parsed]);
          }
        } catch { /* use defaults */ }
      }
      if (storedProfile) {
        try {
          const parsed = JSON.parse(storedProfile) as Partial<MeProfile>;
          setMeProfile({ ...EMPTY_ME_PROFILE, ...parsed });
        } catch { /* use empty profile */ }
      }
      setHasPassword(Boolean(storedPassword));
      setIsLocked(Boolean(storedPassword));
      setIsLoaded(true);
    }).catch(() => setIsLoaded(true));
  }, []);

  const persistBoxes = useCallback(async (next: ThoughtBox[]) => {
    setBoxes(next);
    await AsyncStorage.setItem(BOXES_KEY, JSON.stringify(next));
  }, []);

  const unlock = useCallback(async (password: string) => {
    const stored = await secureGet(PASSWORD_KEY);
    if (!stored) return false;
    const valid = (await digest(password)) === stored;
    if (valid) setIsLocked(false);
    return valid;
  }, []);

  const verifyPassword = useCallback(async (password: string) => {
    const stored = await secureGet(PASSWORD_KEY);
    return Boolean(stored) && (await digest(password)) === stored;
  }, []);

  const setMasterPassword = useCallback(async (password: string) => {
    await secureSet(PASSWORD_KEY, await digest(password));
    setHasPassword(true);
    setIsLocked(false);
  }, []);

  const changeMasterPassword = useCallback(async (current: string, next: string) => {
    const valid = await unlock(current);
    if (!valid) return false;
    await secureSet(PASSWORD_KEY, await digest(next));
    return true;
  }, [unlock]);

  const updateBox = useCallback(async (id: string, input: Partial<Pick<ThoughtBox, "name" | "description" | "prompt" | "script">>) => {
    await persistBoxes(boxes.map((box) => box.id === id ? { ...box, ...input } : box));
  }, [boxes, persistBoxes]);

  const updateMeProfile = useCallback(async (input: Partial<MeProfile>) => {
    const next = { ...meProfile, ...input };
    setMeProfile(next);
    await AsyncStorage.setItem(ME_PROFILE_KEY, JSON.stringify(next));
  }, [meProfile]);

  const deleteBox = useCallback(async (id: string) => {
    await persistBoxes(boxes.filter((box) => box.id !== id));
  }, [boxes, persistBoxes]);

  const addBox = useCallback(async (input: Pick<ThoughtBox, "name" | "description" | "prompt" | "script">) => {
    const box: ThoughtBox = { ...input, id: `box-${Date.now()}`, accent: "#B56A38" };
    await persistBoxes([...boxes, box]);
    return box;
  }, [boxes, persistBoxes]);

  const value = useMemo(() => ({ boxes, meProfile, isLoaded, isLocked, hasPassword, unlock, verifyPassword, setMasterPassword, changeMasterPassword, updateBox, updateMeProfile, deleteBox, addBox, lock: () => setIsLocked(true) }), [boxes, meProfile, isLoaded, isLocked, hasPassword, unlock, verifyPassword, setMasterPassword, changeMasterPassword, updateBox, updateMeProfile, deleteBox, addBox]);
  return <PrivateSpaceContext.Provider value={value}>{children}</PrivateSpaceContext.Provider>;
}

export function usePrivateSpace() {
  const context = useContext(PrivateSpaceContext);
  if (!context) throw new Error("usePrivateSpace must be used within PrivateSpaceProvider");
  return context;
}
