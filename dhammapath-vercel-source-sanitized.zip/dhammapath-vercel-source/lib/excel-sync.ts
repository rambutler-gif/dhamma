import * as XLSX from "xlsx";
import type { BaseEntity, ChecklistItem as SyncChecklistItem, OfficeTask as SyncOfficeTask, Project as SyncProject, SyncConflict, SyncEntityType, SyncSummary, TrainingRecord as SyncTrainingRecord } from "@/types/sync";
import type { OfficeTask as AppOfficeTask } from "./executive-dashboard-context";
import type { Project as AppProject, TrainingRecord as AppTrainingRecord } from "./operational-context";

// ---------------------------------------------------------------------------
// App <-> sync type adapters
//
// The real app types (OfficeTask, Project, TrainingRecord) don't line up
// field-for-field with the sync layer's simplified shape (see types/sync.ts).
// These adapters are the single place that translation happens, so the rest
// of the app never has to know the sync layer exists.
// ---------------------------------------------------------------------------

const STATUS_APP_TO_SYNC: Record<AppOfficeTask["status"], SyncOfficeTask["status"]> = {
  open: "pending",
  rolled: "in-progress",
  done: "completed",
};
const STATUS_SYNC_TO_APP: Record<SyncOfficeTask["status"], AppOfficeTask["status"]> = {
  pending: "open",
  "in-progress": "rolled",
  completed: "done",
};

export function appTaskToSync(task: AppOfficeTask): SyncOfficeTask {
  return {
    id: task.id,
    task: task.task,
    category: task.category,
    project: task.projectId,
    severity: task.severity,
    priority: task.priority,
    owner: task.ownerName,
    date: task.date,
    status: STATUS_APP_TO_SYNC[task.status],
    createdAt: task.createdAt ?? task.date,
    updatedAt: task.updatedAt ?? task.createdAt ?? task.date,
  };
}

export function syncTaskToAppPatch(sync: SyncOfficeTask): Partial<AppOfficeTask> {
  return {
    task: sync.task,
    category: sync.category,
    projectId: sync.project,
    ownerName: sync.owner,
    date: sync.date,
    status: STATUS_SYNC_TO_APP[sync.status] ?? "open",
    updatedAt: sync.updatedAt,
  };
}

export function appProjectToSync(project: AppProject): SyncProject {
  return {
    id: project.id,
    product: project.product,
    name: project.name,
    status: project.status,
    deadline: project.deadline,
    reviewDate: project.reviewDate,
    remark: project.remark,
    createdAt: project.createdAt,
    updatedAt: project.updatedAt,
  };
}

export function syncProjectToAppPatch(sync: SyncProject): Partial<AppProject> {
  return {
    product: sync.product,
    name: sync.name,
    status: sync.status as AppProject["status"],
    deadline: sync.deadline,
    reviewDate: sync.reviewDate,
    remark: sync.remark ?? "",
    updatedAt: sync.updatedAt,
  };
}

export function appTrainingToSync(training: AppTrainingRecord): SyncTrainingRecord {
  return { id: training.id, date: training.date, topic: training.topic, createdAt: training.createdAt, updatedAt: training.updatedAt };
}

export function syncTrainingToAppPatch(sync: SyncTrainingRecord): Partial<AppTrainingRecord> {
  return { date: sync.date, topic: sync.topic, updatedAt: sync.updatedAt };
}

// Checklist is structurally different: one app record holds many completed
// dates. The sheet flattens this to one row per (item, date) pair, same
// shape the old export already used. Import is additive-only for v1: a row
// present and marked done adds that date if missing. A row's *absence* never
// removes a completion — that would be a silent destructive delete driven by
// someone forgetting a row in a spreadsheet, too risky for v1.
export type ChecklistRow = { itemId: string; title: string; note: string; date: string; done: boolean };

export function checklistToRows(items: { id: string; title: string; note: string; completedDates: string[] }[]): ChecklistRow[] {
  return items.flatMap((item) => item.completedDates.map((date) => ({ itemId: item.id, title: item.title, note: item.note, date, done: true })));
}

// ---------------------------------------------------------------------------
// Workbook build (export)
// ---------------------------------------------------------------------------

export type WorkbookData = {
  tasks: SyncOfficeTask[];
  projects: SyncProject[];
  checklistRows: ChecklistRow[];
  trainings: SyncTrainingRecord[];
};

const TASK_HEADERS = ["id", "task", "category", "project", "severity", "priority", "owner", "date", "status", "createdAt", "updatedAt"] as const;
const PROJECT_HEADERS = ["id", "product", "name", "status", "deadline", "reviewDate", "remark", "createdAt", "updatedAt"] as const;
const CHECKLIST_HEADERS = ["itemId", "title", "note", "date", "done"] as const;
const TRAINING_HEADERS = ["id", "date", "topic", "createdAt", "updatedAt"] as const;

function sheetFromRows<T extends Record<string, unknown>>(rows: T[], headers: readonly string[]) {
  const aoa = [headers as unknown as string[], ...rows.map((row) => headers.map((h) => (row as Record<string, unknown>)[h] ?? ""))];
  return XLSX.utils.aoa_to_sheet(aoa);
}

export function buildWorkbook(data: WorkbookData): XLSX.WorkBook {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, sheetFromRows(data.tasks as unknown as Record<string, unknown>[], TASK_HEADERS), "Tasks");
  XLSX.utils.book_append_sheet(wb, sheetFromRows(data.projects as unknown as Record<string, unknown>[], PROJECT_HEADERS), "Projects");
  XLSX.utils.book_append_sheet(wb, sheetFromRows(data.checklistRows as unknown as Record<string, unknown>[], CHECKLIST_HEADERS), "Checklist");
  XLSX.utils.book_append_sheet(wb, sheetFromRows(data.trainings as unknown as Record<string, unknown>[], TRAINING_HEADERS), "Training");
  return wb;
}

export function workbookToArrayBuffer(wb: XLSX.WorkBook): ArrayBuffer {
  return XLSX.write(wb, { type: "array", bookType: "xlsx" });
}

// ---------------------------------------------------------------------------
// Workbook parse (import)
// ---------------------------------------------------------------------------

export type ParsedWorkbook = {
  tasks: SyncOfficeTask[];
  projects: SyncProject[];
  checklistRows: ChecklistRow[];
  trainings: SyncTrainingRecord[];
  errors: string[];
};

function readSheetRows(wb: XLSX.WorkBook, sheetName: string): Record<string, unknown>[] {
  const sheet = wb.Sheets[sheetName];
  if (!sheet) return [];
  return XLSX.utils.sheet_to_json(sheet, { defval: "" });
}

function requireString(row: Record<string, unknown>, field: string, errors: string[], sheetName: string, rowIndex: number): string | null {
  const value = row[field];
  if (typeof value !== "string" || !value.trim()) {
    errors.push(`${sheetName} row ${rowIndex + 2}: missing "${field}", skipped`);
    return null;
  }
  return value.trim();
}

export function parseWorkbookBuffer(buffer: ArrayBuffer): ParsedWorkbook {
  const errors: string[] = [];
  const wb = XLSX.read(buffer, { type: "array" });

  const tasks: SyncOfficeTask[] = [];
  readSheetRows(wb, "Tasks").forEach((row, i) => {
    const id = requireString(row, "id", errors, "Tasks", i);
    const task = requireString(row, "task", errors, "Tasks", i);
    const date = requireString(row, "date", errors, "Tasks", i);
    if (!id || !task || !date) return;
    const status = String(row.status || "pending") as SyncOfficeTask["status"];
    tasks.push({
      id,
      task,
      category: String(row.category || ""),
      project: row.project ? String(row.project) : undefined,
      severity: row.severity ? String(row.severity) : undefined,
      priority: row.priority ? String(row.priority) : undefined,
      owner: row.owner ? String(row.owner) : undefined,
      date,
      status: ["pending", "in-progress", "completed"].includes(status) ? status : "pending",
      createdAt: String(row.createdAt || date),
      updatedAt: String(row.updatedAt || row.createdAt || date),
    });
  });

  const projects: SyncProject[] = [];
  readSheetRows(wb, "Projects").forEach((row, i) => {
    const id = requireString(row, "id", errors, "Projects", i);
    const name = requireString(row, "name", errors, "Projects", i);
    if (!id || !name) return;
    const now = new Date().toISOString();
    projects.push({
      id,
      product: String(row.product || ""),
      name,
      status: String(row.status || "planned"),
      deadline: row.deadline ? String(row.deadline) : undefined,
      reviewDate: row.reviewDate ? String(row.reviewDate) : undefined,
      remark: row.remark ? String(row.remark) : undefined,
      createdAt: String(row.createdAt || now),
      updatedAt: String(row.updatedAt || row.createdAt || now),
    });
  });

  const checklistRows: ChecklistRow[] = [];
  readSheetRows(wb, "Checklist").forEach((row, i) => {
    const itemId = requireString(row, "itemId", errors, "Checklist", i);
    const title = requireString(row, "title", errors, "Checklist", i);
    const date = requireString(row, "date", errors, "Checklist", i);
    if (!itemId || !title || !date) return;
    checklistRows.push({ itemId, title, note: String(row.note || ""), date, done: String(row.done).toLowerCase() !== "false" && row.done !== "" ? Boolean(row.done) : true });
  });

  const trainings: SyncTrainingRecord[] = [];
  readSheetRows(wb, "Training").forEach((row, i) => {
    const id = requireString(row, "id", errors, "Training", i);
    const date = requireString(row, "date", errors, "Training", i);
    const topic = requireString(row, "topic", errors, "Training", i);
    if (!id || !date || !topic) return;
    trainings.push({ id, date, topic, createdAt: String(row.createdAt || date), updatedAt: String(row.updatedAt || row.createdAt || date) });
  });

  return { tasks, projects, checklistRows, trainings, errors };
}

// ---------------------------------------------------------------------------
// Diff / merge
//
// Rule: if the incoming id isn't known locally, it's new -> add.
// If both sides changed since the last sync, it's a conflict -> ask the user.
// If only the incoming side changed, take it -> update.
// Otherwise -> skip, nothing meaningfully changed.
// On a first-ever import (lastSyncedAt is null), any local/incoming mismatch
// on a shared id is treated as a conflict rather than silently picking a
// side, since there's no baseline to reason from yet.
// ---------------------------------------------------------------------------

function isEqualIgnoringTimestamps<T extends BaseEntity>(a: T, b: T): boolean {
  const strip = ({ updatedAt: _u, createdAt: _c, ...rest }: T) => rest;
  return JSON.stringify(strip(a)) === JSON.stringify(strip(b));
}

export function mergeRecords<T extends BaseEntity>(local: T[], incoming: T[], entityType: SyncEntityType, lastSyncedAt: string | null): { toAdd: T[]; toUpdate: T[]; conflicts: SyncConflict<T>[]; skipped: number } {
  const localById = new Map(local.map((item) => [item.id, item]));
  const toAdd: T[] = [];
  const toUpdate: T[] = [];
  const conflicts: SyncConflict<T>[] = [];
  let skipped = 0;

  for (const incomingItem of incoming) {
    const localItem = localById.get(incomingItem.id);
    if (!localItem) {
      toAdd.push(incomingItem);
      continue;
    }
    if (isEqualIgnoringTimestamps(localItem, incomingItem)) {
      skipped += 1;
      continue;
    }
    const localChangedSinceSync = !lastSyncedAt || localItem.updatedAt > lastSyncedAt;
    const incomingChangedSinceSync = !lastSyncedAt || incomingItem.updatedAt > lastSyncedAt;
    if (localChangedSinceSync && incomingChangedSinceSync) {
      conflicts.push({ id: incomingItem.id, entityType, appVersion: localItem, excelVersion: incomingItem });
    } else if (incomingItem.updatedAt > localItem.updatedAt) {
      toUpdate.push(incomingItem);
    } else {
      skipped += 1;
    }
  }
  return { toAdd, toUpdate, conflicts, skipped };
}

export function summarize(results: { toAdd: unknown[]; toUpdate: unknown[]; conflicts: unknown[]; skipped: number }[]): SyncSummary {
  return results.reduce(
    (acc, r) => ({ added: acc.added + r.toAdd.length, updated: acc.updated + r.toUpdate.length, skipped: acc.skipped + r.skipped, conflicts: acc.conflicts + r.conflicts.length }),
    { added: 0, updated: 0, skipped: 0, conflicts: 0 },
  );
}
