export function compliancePercent(loggedDates: string[], startDate: string, endDate: string) {
  const start = new Date(`${startDate}T12:00:00`).getTime();
  const end = new Date(`${endDate}T12:00:00`).getTime();
  const total = Math.max(1, Math.floor((end - start) / 86400000) + 1);
  return Math.min(100, Math.round((loggedDates.filter((date) => { const time = new Date(`${date}T12:00:00`).getTime(); return time >= start && time <= end; }).length / total) * 100));
}

export function monthDays(year: number, month: number) {
  const total = new Date(year, month + 1, 0).getDate();
  return Array.from({ length: total }, (_, index) => `${year}-${String(month + 1).padStart(2, "0")}-${String(index + 1).padStart(2, "0")}`);
}

export function activeHabits<T extends { status: string }>(habits: T[]) { return habits.filter((habit) => habit.status !== "retired"); }
export function taskNeedsEscalation(task: { status: string; rolloverCount: number }) { return task.status !== "done" && task.rolloverCount >= 2; }
export function taskRolloverLabel(task: { severity: "High" | "Medium" | "Low" }) { return task.severity === "High" ? "MOVE TO TOMORROW" : "ROLLED TO POOL"; }
export function habitCompletion(habit: { completedDates: string[] }, year: number, month: number) { const days = monthDays(year, month); const logged = days.filter((day) => habit.completedDates.includes(day)).length; return Math.round((logged / days.length) * 100); }
export function certReadyForDecision(item: { loggedDates: string[]; startDate: string; endDate: string }, today = new Date().toISOString().slice(0, 10)) { return today > item.endDate && compliancePercent(item.loggedDates, item.startDate, item.endDate) >= 90; }
