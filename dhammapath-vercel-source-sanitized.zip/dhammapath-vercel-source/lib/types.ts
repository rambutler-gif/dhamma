export type Feeling =
  | "sadness"
  | "anger"
  | "fear"
  | "longing"
  | "confusion"
  | "hope"
  | "relief"
  | "calm"
  | "other";

export type EmotionCheckIn = {
  id: string;
  emotion: Feeling;
  intensity: 1 | 2 | 3 | 4 | 5;
  note?: string;
  createdAt: string;
};

export type ReflectionAnswer = {
  questionId: string;
  question: string;
  answer: string;
};

export type DhammaReference = {
  key: string;
  pali: string;
  meaning: string;
  description: string;
  reference: string;
  referenceUrl: string;
};

export type DhammaInsight = {
  seeingClearly: string;
  possibleWrongView: string;
  meaning: string;
  wiserSubstitute: string;
  smallPractice: string;
  principle: string;
  dhammaKeys?: DhammaReference[];
  mentorQuestion?: string;
  potentialDirection?: string;
};

export type ThoughtBox = {
  id: string;
  name: string;
  description: string;
  prompt: string;
  accent: string;
  script: string;
};

export type MeProfile = {
  name: string;
  lifeStage: string;
  importantPeople: string;
  values: string;
  responsibilities: string;
  guidancePreference: string;
};

export type PlanningItemType = "diary" | "upcoming" | "move" | "goal";
export type PlanningPriority = "high" | "medium" | "low";

export type PlanningItem = {
  id: string;
  type: PlanningItemType;
  title: string;
  note: string;
  date: string;
  completed: boolean;
  createdAt: string;
  priority?: PlanningPriority;
  rolloverCount?: number;
  escalated?: boolean;
  archivedAt?: string;
  sourceEventId?: string;
  sourceEventTitle?: string;
};

export type Habit = {
  id: string;
  title: string;
  note: string;
  createdAt: string;
  completedDates: string[];
};

export type StructuredReflection = {
  facts: string;
  assumptions: string;
  craving: string;
  fear: string;
  anger: string;
  selfStory: string;
};

export type Story = {
  id: string;
  title: string;
  content: string;
  structured?: StructuredReflection;
  feeling: Feeling;
  where?: string;
  boxId?: string;
  createdAt: string;
  updatedAt: string;
  followUp?: string;
  insight?: DhammaInsight;
  reflectionAnswers?: ReflectionAnswer[];
  emotionCheckIns?: EmotionCheckIn[];
};

export type ReflectionQuestion = {
  id: string;
  label: string;
  prompt: string;
  helper: string;
};

export const FEELINGS: Array<{ key: Feeling; label: string }> = [
  { key: "sadness", label: "Sadness" },
  { key: "anger", label: "Anger" },
  { key: "fear", label: "Fear" },
  { key: "longing", label: "Longing" },
  { key: "confusion", label: "Confusion" },
  { key: "hope", label: "Hope" },
  { key: "relief", label: "Relief" },
  { key: "calm", label: "Calm" },
  { key: "other", label: "Other" },
];

export const REFLECTION_QUESTIONS: ReflectionQuestion[] = [
  {
    id: "who",
    label: "Who",
    prompt: "Who is involved in this story?",
    helper: "Name the people, including yourself.",
  },
  {
    id: "what",
    label: "What",
    prompt: "What happened, as plainly as you can say it?",
    helper: "Separate events from your interpretation.",
  },
  {
    id: "when",
    label: "When",
    prompt: "When did this feeling or pattern begin?",
    helper: "Notice what was happening then.",
  },
  {
    id: "where",
    label: "Where",
    prompt: "Where did this happen, and what was around you?",
    helper: "Place and circumstance can change what a moment means.",
  },
  {
    id: "why",
    label: "Why",
    prompt: "Why do you think this happened or matters now?",
    helper: "Keep this as a question, not a fixed conclusion.",
  },
  {
    id: "how",
    label: "How",
    prompt: "How did you respond, and how did others respond?",
    helper: "Notice words, actions, silence, and consequences.",
  },
  {
    id: "feeling",
    label: "Feeling",
    prompt: "What do you feel in the body and mind now?",
    helper: "Use simple words. Nothing needs to be hidden.",
  },
  {
    id: "want",
    label: "Want",
    prompt: "What do you want to happen next?",
    helper: "Look for the wish beneath the first answer.",
  },
];
