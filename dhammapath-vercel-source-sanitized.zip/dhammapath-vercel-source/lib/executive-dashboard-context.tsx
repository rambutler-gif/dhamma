import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { nextForwardDate } from "@/lib/executive-task-utils";

export { activeHabits, certReadyForDecision, compliancePercent, habitCompletion, monthDays, taskNeedsEscalation, taskRolloverLabel } from "@/lib/executive-dashboard-utils";

export type HabitFrequency = "daily" | "alt-day" | "weekly";
export type RegistryStatus = "active" | "trial" | "retired";
export type TaskSeverity = "High" | "Medium" | "Low";
export type TaskPriority = "high" | "medium" | "low";
export type OfficeTaskStatus = "open" | "done" | "rolled";
export type TaskWorkflowEvent = { type: "forwarded" | "reassigned"; at: string; fromDate?: string; toDate?: string; fromOwner?: string; toOwner?: string };
export type CertStatus = "trial" | "graduated" | "dropped";

export type ExecutiveHabit = { id: string; name: string; icon: string; frequency: HabitFrequency; status: RegistryStatus; startDate: string; completedDates: string[] };
export type OfficeTask = { id: string; task: string; category: string; severity: TaskSeverity; priority: TaskPriority; contactName?: string; ownerName?: string; projectId?: string; deadline?: string; reviewDate?: string; remark?: string; workflowHistory?: TaskWorkflowEvent[]; createdAt?: string; updatedAt?: string; status: OfficeTaskStatus; date: string; rolloverCount: number };
export type CertPrepItem = { id: string; item: string; startDate: string; endDate: string; frequencyRequired: string; status: CertStatus; loggedDates: string[] };

type ExecutiveDashboardValue = {
  habits: ExecutiveHabit[];
  tasks: OfficeTask[];
  certItems: CertPrepItem[];
  isLoaded: boolean;
  addHabit: (input: Omit<ExecutiveHabit, "id" | "status" | "startDate" | "completedDates">) => Promise<void>;
  toggleHabitDate: (id: string, date: string) => Promise<void>;
  graduateHabit: (id: string) => Promise<void>;
  retireHabit: (id: string) => Promise<void>;
  addTask: (input: Omit<OfficeTask, "id" | "status" | "rolloverCount">) => Promise<void>;
  updateTask: (id: string, input: Partial<Pick<OfficeTask, "status" | "date" | "rolloverCount" | "priority" | "task" | "category" | "projectId" | "ownerName" | "deadline" | "reviewDate" | "remark" | "updatedAt">>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  forwardTask: (id: string) => Promise<void>;
  reassignTask: (id: string, ownerName: string) => Promise<void>;
  addCertItem: (input: Omit<CertPrepItem, "id" | "status" | "loggedDates">) => Promise<void>;
  toggleCertDate: (id: string, date: string) => Promise<void>;
  updateCertStatus: (id: string, status: CertStatus) => Promise<void>;
};

const KEYS = { habits: "dhammapath-executive-habits-v1", tasks: "dhammapath-executive-tasks-v1", cert: "dhammapath-executive-cert-v1" };
const DashboardContext = createContext<ExecutiveDashboardValue | null>(null);
const parse = <T,>(value: string | null): T[] => { if (!value) return []; try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch { return []; } };
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export function ExecutiveDashboardProvider({ children }: { children: React.ReactNode }) {
  const [habits, setHabits] = useState<ExecutiveHabit[]>([]);
  const [tasks, setTasks] = useState<OfficeTask[]>([]);
  const [certItems, setCertItems] = useState<CertPrepItem[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => { Promise.all(Object.values(KEYS).map((key) => AsyncStorage.getItem(key))).then(([h, t, c]) => { setHabits(parse<ExecutiveHabit>(h)); setTasks(parse<OfficeTask>(t).map((task) => ({ ...task, priority: task.priority ?? "medium", contactName: task.contactName?.trim() || undefined, ownerName: task.ownerName?.trim() || undefined, projectId: task.projectId?.trim() || undefined }))); setCertItems(parse<CertPrepItem>(c)); setIsLoaded(true); }).catch(() => setIsLoaded(true)); }, []);
  const persist = useCallback(async <T,>(key: string, value: T[], setter: (next: T[]) => void) => { setter(value); await AsyncStorage.setItem(key, JSON.stringify(value)); }, []);
  const addHabit = useCallback(async (input: Omit<ExecutiveHabit, "id" | "status" | "startDate" | "completedDates">) => { const next = [...habits, { ...input, id: uid(), status: "trial" as const, startDate: new Date().toISOString().slice(0, 10), completedDates: [] }]; await persist(KEYS.habits, next, setHabits); }, [habits, persist]);
  const toggleHabitDate = useCallback(async (id: string, date: string) => { const next = habits.map((habit) => habit.id !== id ? habit : { ...habit, completedDates: habit.completedDates.includes(date) ? habit.completedDates.filter((entry) => entry !== date) : [...habit.completedDates, date] }); await persist(KEYS.habits, next, setHabits); }, [habits, persist]);
  const graduateHabit = useCallback(async (id: string) => { await persist(KEYS.habits, habits.map((habit) => habit.id === id ? { ...habit, status: "active" as const } : habit), setHabits); }, [habits, persist]);
  const retireHabit = useCallback(async (id: string) => { await persist(KEYS.habits, habits.map((habit) => habit.id === id ? { ...habit, status: "retired" as const } : habit), setHabits); }, [habits, persist]);
  const addTask = useCallback(async (input: Omit<OfficeTask, "id" | "status" | "rolloverCount">) => { const now = new Date().toISOString(); await persist(KEYS.tasks, [...tasks, { ...input, priority: input.priority ?? "medium", id: uid(), createdAt: now, updatedAt: now, status: "open" as const, rolloverCount: 0 }], setTasks); }, [tasks, persist]);
  const updateTask = useCallback(async (id: string, input: Partial<Pick<OfficeTask, "status" | "date" | "rolloverCount" | "priority" | "task" | "category" | "projectId" | "ownerName" | "deadline" | "reviewDate" | "remark" | "updatedAt">>) => { await persist(KEYS.tasks, tasks.map((task) => task.id === id ? { ...task, ...input, updatedAt: new Date().toISOString() } : task), setTasks); }, [tasks, persist]);
  const deleteTask = useCallback(async (id: string) => { await persist(KEYS.tasks, tasks.filter((task) => task.id !== id), setTasks); }, [tasks, persist]);
  const forwardTask = useCallback(async (id: string) => { const next = tasks.map((task) => { if (task.id !== id) return task; const toDate = nextForwardDate(task.date); return { ...task, date: toDate, status: "rolled" as const, rolloverCount: (task.rolloverCount ?? 0) + 1, updatedAt: new Date().toISOString(), workflowHistory: [...(task.workflowHistory ?? []), { type: "forwarded" as const, at: new Date().toISOString(), fromDate: task.date, toDate }] }; }); await persist(KEYS.tasks, next, setTasks); }, [tasks, persist]);
  const reassignTask = useCallback(async (id: string, ownerName: string) => { const next = tasks.map((task) => task.id === id ? { ...task, ownerName: ownerName.trim() || undefined, workflowHistory: [...(task.workflowHistory ?? []), { type: "reassigned" as const, at: new Date().toISOString(), fromOwner: task.ownerName, toOwner: ownerName.trim() || undefined }] } : task); await persist(KEYS.tasks, next, setTasks); }, [tasks, persist]);
  const addCertItem = useCallback(async (input: Omit<CertPrepItem, "id" | "status" | "loggedDates">) => { await persist(KEYS.cert, [...certItems, { ...input, id: uid(), status: "trial" as const, loggedDates: [] }], setCertItems); }, [certItems, persist]);
  const toggleCertDate = useCallback(async (id: string, date: string) => { const next = certItems.map((item) => item.id !== id ? item : { ...item, loggedDates: item.loggedDates.includes(date) ? item.loggedDates.filter((entry) => entry !== date) : [...item.loggedDates, date] }); await persist(KEYS.cert, next, setCertItems); }, [certItems, persist]);
  const updateCertStatus = useCallback(async (id: string, status: CertStatus) => { await persist(KEYS.cert, certItems.map((item) => item.id === id ? { ...item, status } : item), setCertItems); }, [certItems, persist]);
  return <DashboardContext.Provider value={useMemo(() => ({ habits, tasks, certItems, isLoaded, addHabit, toggleHabitDate, graduateHabit, retireHabit, addTask, updateTask, deleteTask, forwardTask, reassignTask, addCertItem, toggleCertDate, updateCertStatus }), [habits, tasks, certItems, isLoaded, addHabit, toggleHabitDate, graduateHabit, retireHabit, addTask, updateTask, deleteTask, forwardTask, reassignTask, addCertItem, toggleCertDate, updateCertStatus])}>{children}</DashboardContext.Provider>;
}

export function useExecutiveDashboard() { const context = useContext(DashboardContext); if (!context) throw new Error("useExecutiveDashboard must be used within ExecutiveDashboardProvider"); return context; }

