export type DhammaKey = {
  key: string;
  pali: string;
  meaning: string;
  description: string;
  reference: string;
  referenceUrl: string;
};

export const DHAMMA_KEYS: Record<string, DhammaKey> = {
  fourTruths: {
    key: "fourTruths",
    pali: "cattāri ariyasaccāni",
    meaning: "Four Noble Truths",
    description: "Notice suffering, its conditions, its possibility of ending, and the path of practice.",
    reference: "Dhammacakkappavattana Sutta, SN 56.11",
    referenceUrl: "https://suttacentral.net/sn56.11/en/sujato",
  },
  craving: {
    key: "craving",
    pali: "taṇhā",
    meaning: "Craving",
    description: "Examine the pull that demands a particular feeling, person, or outcome.",
    reference: "Dhammacakkappavattana Sutta, SN 56.11",
    referenceUrl: "https://suttacentral.net/sn56.11/en/sujato",
  },
  impermanence: {
    key: "impermanence",
    pali: "anicca",
    meaning: "Inconstancy",
    description: "See that feelings, conditions, relationships, and identities change.",
    reference: "Anattalakkhaṇa Sutta, SN 22.59",
    referenceUrl: "https://suttacentral.net/sn22.59/en/sujato",
  },
  notSelf: {
    key: "notSelf",
    pali: "anattā",
    meaning: "Not a fixed self",
    description: "Treat a self-story as a changing process, not a permanent verdict.",
    reference: "Anattalakkhaṇa Sutta, SN 22.59",
    referenceUrl: "https://suttacentral.net/sn22.59/en/sujato",
  },
  mindfulness: {
    key: "mindfulness",
    pali: "sati",
    meaning: "Mindfulness",
    description: "Know the present body, feeling, mind, and mental qualities clearly.",
    reference: "Satipaṭṭhāna Sutta, MN 10",
    referenceUrl: "https://suttacentral.net/mn10/en/sujato",
  },
  rightSpeech: {
    key: "rightSpeech",
    pali: "sammā vācā",
    meaning: "Right speech",
    description: "Choose speech that is truthful, useful, timely, and non-harming.",
    reference: "Abhaya Rājakumāra Sutta, MN 58",
    referenceUrl: "https://suttacentral.net/mn58/en/sujato",
  },
  rightIntention: {
    key: "rightIntention",
    pali: "sammā saṅkappa",
    meaning: "Right intention",
    description: "Examine whether the next movement comes from letting go, goodwill, and harmlessness.",
    reference: "Magga-vibhaṅga Sutta, SN 45.8",
    referenceUrl: "https://suttacentral.net/sn45.8/en/sujato",
  },
  lovingKindness: {
    key: "lovingKindness",
    pali: "mettā",
    meaning: "Goodwill",
    description: "Protect the welfare of yourself and others without possession or pressure.",
    reference: "Karaṇīyamettā Sutta, Snp 1.8",
    referenceUrl: "https://suttacentral.net/snp1.8/en/sujato",
  },
  compassion: {
    key: "compassion",
    pali: "karuṇā",
    meaning: "Compassion",
    description: "Meet suffering with a wish for its relief, guided by care and wise limits.",
    reference: "Brahmavihāra teachings, AN 4.125",
    referenceUrl: "https://suttacentral.net/an4.125/en/sujato",
  },
  dependentArising: {
    key: "dependentArising",
    pali: "paṭiccasamuppāda",
    meaning: "Dependent arising",
    description: "Trace how contact, feeling, wanting, clinging, and action condition one another.",
    reference: "Paccaya Sutta, SN 12.20",
    referenceUrl: "https://suttacentral.net/sn12.20/en/sujato",
  },
  wiseEffort: {
    key: "wiseEffort",
    pali: "sammā vāyāma",
    meaning: "Right effort",
    description: "Prevent harmful states, release them, cultivate helpful states, and sustain them.",
    reference: "Sammappadhāna Sutta, SN 49.1",
    referenceUrl: "https://suttacentral.net/sn49.1/en/sujato",
  },
};

export function getDhammaKeys(ids: string[]) {
  return ids.map((id) => DHAMMA_KEYS[id]).filter(Boolean);
}

export function inferDhammaKeyIds(text: string, feeling?: string) {
  const value = text.toLowerCase();
  const ids = new Set<string>(["fourTruths", "mindfulness"]);
  if (feeling === "sadness" || /loss|grief|change|death|missing|divorce/.test(value)) ids.add("impermanence");
  if (feeling === "anger" || /hate|revenge|fight|betray|argument|unfair/.test(value)) ids.add("rightSpeech");
  if (feeling === "fear" || /fear|afraid|anxious|worry|uncertain/.test(value)) ids.add("dependentArising");
  if (feeling === "longing" || /want|crush|love|attract|possess|need/.test(value)) ids.add("craving");
  if (/identity|failure|worth|always|never|i am|self-story/.test(value)) ids.add("notSelf");
  if (/kind|care|hurt|suffer|grief|compassion/.test(value)) ids.add("compassion");
  if (/intention|motive|wish|should|choice/.test(value)) ids.add("rightIntention");
  return [...ids];
}
