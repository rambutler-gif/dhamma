import { z } from "zod";

import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const insightSchema = z.object({
  seeingClearly: z.string().min(1).max(1800),
  possibleWrongView: z.string().min(1).max(1800),
  meaning: z.string().min(1).max(1800),
  wiserSubstitute: z.string().min(1).max(1800),
  smallPractice: z.string().min(1).max(1800),
  principle: z.string().min(1).max(300),
});

const structuredInput = z.object({
  facts: z.string().max(4000),
  assumptions: z.string().max(4000),
  craving: z.string().max(4000),
  fear: z.string().max(4000),
  anger: z.string().max(4000),
  selfStory: z.string().max(4000),
});

const reflectionInput = z.object({
  title: z.string().min(1).max(255),
  content: z.string().min(1).max(8000),
  feeling: z.string().max(80),
  where: z.string().max(500).optional(),
  masterScript: z.string().max(2000).optional(),
  centralScript: z.string().max(2500).optional(),
  meProfile: z.string().max(5000).optional(),
  planningContext: z.string().max(5000).optional(),
  connectedRoomContext: z.string().max(12000).optional(),
  priorStoryContext: z.string().max(12000).optional(),
  structured: structuredInput.optional(),
  answers: z.array(z.object({ question: z.string().max(500), answer: z.string().max(2000) })).max(20),
});

async function requestNvidiaInsight(input: z.infer<typeof reflectionInput>) {
  const apiKey = process.env.NVIDIA_API_KEY;
  if (!apiKey) throw new Error("NVIDIA NIM is not configured");

  const response = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "meta/llama-3.1-8b-instruct",
      temperature: 0.2,
      max_tokens: 900,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: "You are a careful Theravada Buddhist reflection companion. Do not diagnose. Do not claim authority over the user. Do not shame. Distinguish possible miccha-ditthi, wrong view, from samma-ditthi, right view. Consider conditions and circumstances. Explore wider Dhamma dimensions when relevant, including the Four Noble Truths, tanha and non-clinging, anicca, anatta as non-fixed identity, sati, right speech, right intention, right effort, metta, karuna, and dependent arising. Connect the situation to causes, conditions, ethics, mind states, and a practical next step. Return only valid JSON with exactly these keys: seeingClearly, possibleWrongView, meaning, wiserSubstitute, smallPractice, principle. Use plain English. Explain that the guidance is a reflection, not a verdict. Preserve the user's freedom. If danger or self-harm appears, advise immediate human support instead of analysis.",
        },
        {
          role: "user",
          content: JSON.stringify({
            story: input,
            structuredReflection: input.structured,
            centralMeScript: input.centralScript,
            meProfile: input.meProfile,
            planningContext: input.planningContext,
            connectedRoomContext: input.connectedRoomContext,
            priorStoryContext: input.priorStoryContext,
            instruction: "Reflect on this life situation using who, what, when, where, why, how, feeling, and want. Explore more than the surface emotion. Consider relevant Dhamma keys, causes and conditions, speech and intention, clinging, impermanence, compassion, and wise effort. Use the central Me context, personal profile, planning context, and connected Room scripts as guidance, but keep the current feeling distinct from prior entries. For grief, do not claim certainty about karma. You may suggest gratitude and anumodana as a wholesome practice. Be direct but compassionate.",
          }),
        },
      ],
    }),
  });

  if (!response.ok) throw new Error(`NVIDIA request failed: ${response.status}`);
  const payload = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = payload.choices?.[0]?.message?.content;
  if (!text) throw new Error("NVIDIA returned no insight");
  return insightSchema.parse(JSON.parse(text));
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  ai: router({
    // Public, not protected: this app has no login flow in the UI (see PrivateGate).
    // Real access control is the local master-password gate, not Manus OAuth session.
    // Leaving this on protectedProcedure would make mentor guidance permanently
    // unreachable since no session cookie is ever issued.
    reflect: publicProcedure.input(reflectionInput).mutation(({ input }) => requestNvidiaInsight(input)),
  }),
});

export type AppRouter = typeof appRouter;
