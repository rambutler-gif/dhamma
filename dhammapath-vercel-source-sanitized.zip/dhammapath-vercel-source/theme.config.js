/** @type {const} */
const themeColors = {
  primary: { light: '#B56A38', dark: '#D08A55' },
  background: { light: '#F7F4EE', dark: '#18211D' },
  surface: { light: '#FFFDF8', dark: '#24302A' },
  foreground: { light: '#1B2A25', dark: '#F6F2EA' },
  muted: { light: '#6C7770', dark: '#B2BBB4' },
  border: { light: '#E5DED2', dark: '#3B4942' },
  success: { light: '#587A5A', dark: '#88B28A' },
  warning: { light: '#A27632', dark: '#D2A354' },
  error: { light: '#B04A43', dark: '#E58A82' },
};

module.exports = { themeColors };
