# Wider Dhamma Reference Audit

## Current implementation

The local reflection engine currently prioritizes a small set of branches: self-story, craving, relationship conflict, attraction, anger, fear, sadness, and a general mindfulness response. It produces one insight object with seeing clearly, possible wrong view, meaning, wiser substitute, small practice, and one principle. It does not yet attach a canonical reference, Pali vocabulary, confidence note, or related teaching path.

The current context includes the active story, structured fields, selected Room script, other Room scripts, prior dated stories, Me profile, planning items, and answers. The present feeling remains primary. This is useful and should be preserved.

## Reference direction

The expanded system should map each reflection to multiple Dhamma keys. Examples include dukkha and its conditions, taṇhā and non-clinging, avijjā and mistaken interpretation, anicca, anattā as a careful non-fixed-self inquiry, mettā, karuṇā, upekkhā, right speech, right intention, right effort, satipaṭṭhāna, the five hindrances, dependent arising, the Four Noble Truths, and the Noble Eightfold Path.

Each insight should expose a short plain-language explanation, the Pali term, a source reference, one or more related keys, and a practical inquiry. The app must distinguish a teaching reference from a definitive judgment about the user. References should be transparent and non-authoritative in tone.

## Sources reviewed

1. The BBC overview of the Four Noble Truths explains dukkha, taṇhā, cessation, and the Eightfold Path. It also distinguishes tanhā as craving from wholesome desire or chanda. URL: https://www.bbc.co.uk/religion/religions/buddhism/beliefs/fournobletruths_1.shtml

2. Access to Insight search results identify the Satipaṭṭhāna Sutta as a direct framework for noticing states such as anger as present or absent. The page itself was protected by a verification screen during extraction. URL: https://www.accesstoinsight.org/tipitaka/mn/mn.010.nysa.html

3. SuttaCentral provides a Dhammapada entry and should be used as a primary source interface when accessible in the live app or through stable source links. URL: https://suttacentral.net/dhp

## Product conclusion

Offline mode should remain a private fallback. It should use the same wider key catalog and local citations where bundled. Online NVIDIA guidance should add deeper synthesis, broader cross-referencing, and current retrieval only when the user chooses it and the network is available. The UI should make this distinction visible instead of implying that offline local guidance is the complete intelligence of Dhammapath.
