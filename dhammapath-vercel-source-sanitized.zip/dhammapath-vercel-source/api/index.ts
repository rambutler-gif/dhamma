import "dotenv/config";
import { createApp } from "../server/_core/app";

// Vercel wraps this exported Express app as a serverless function.
// No app.listen() here — Vercel's runtime handles the HTTP server.
const app = createApp();

export default app;
