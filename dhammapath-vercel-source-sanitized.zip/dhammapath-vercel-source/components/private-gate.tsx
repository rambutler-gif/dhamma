import { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { usePrivateSpace } from "@/lib/private-space";

export function PrivateGate({ children }: { children: React.ReactNode }) {
  const { isLoaded, isLocked, hasPassword, unlock } = usePrivateSpace();
  const [password, setPassword] = useState("");
  const [isChecking, setIsChecking] = useState(false);

  if (!isLoaded) return <ScreenContainer className="items-center justify-center"><Text className="text-muted">Opening private space...</Text></ScreenContainer>;
  if (!hasPassword || !isLocked) return <>{children}</>;

  async function handleUnlock() {
    if (!password) return;
    setIsChecking(true);
    const valid = await unlock(password);
    setIsChecking(false);
    if (!valid) Alert.alert("That password did not match", "Try again. Your private space remains locked.");
    else setPassword("");
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-6" safeAreaClassName="bg-background">
      <View className="flex-1 justify-center">
        <View className="h-16 w-16 items-center justify-center rounded-full bg-foreground"><IconSymbol name="lock.fill" size={28} color="#F7F4EE" /></View>
        <Text className="mt-7 text-3xl font-bold leading-9 text-foreground">Your private space.</Text>
        <Text className="mt-3 text-base leading-6 text-muted">Enter your master password to continue.</Text>
        <TextInput value={password} onChangeText={setPassword} placeholder="Master password" placeholderTextColor="#9A9E98" secureTextEntry autoFocus onSubmitEditing={handleUnlock} returnKeyType="go" className="mt-8 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" />
        <Pressable onPress={handleUnlock} disabled={isChecking} style={({ pressed }) => [styles.button, pressed && styles.pressed, isChecking && styles.disabled]}><Text className="text-base font-bold text-background">{isChecking ? "Checking..." : "Unlock space"}</Text><IconSymbol name="arrow.left" size={19} color="#F7F4EE" style={styles.rotateIcon} /></Pressable>
        <Text className="mt-5 text-center text-xs leading-5 text-muted">Your password is not saved as plain text. Keep it safe.</Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  button: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 18, flexDirection: "row", justifyContent: "space-between", marginTop: 18, paddingHorizontal: 18, paddingVertical: 16 },
  rotateIcon: { transform: [{ rotate: "180deg" }] },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.55 },
});
