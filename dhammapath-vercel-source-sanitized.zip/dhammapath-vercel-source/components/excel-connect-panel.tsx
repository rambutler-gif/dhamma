import { useRef } from "react";
import { Alert, Platform, Pressable, StyleSheet, Text, View } from "react-native";

import { useExcelSync } from "@/lib/excel-sync-context";

function conflictLabel(entityType: string) {
  if (entityType === "task") return "Task";
  if (entityType === "project") return "Project";
  return "Training";
}

function conflictTitle(version: unknown): string {
  const v = version as { task?: string; name?: string; topic?: string };
  return v.task ?? v.name ?? v.topic ?? "Untitled";
}

export function ExcelConnectPanel() {
  const { lastSyncedAt, lastSummary, conflicts, isBusy, error, exportNow, importFile, resolveConflict } = useExcelSync();
  const inputRef = useRef<HTMLInputElement | null>(null);

  function triggerImport() {
    if (Platform.OS !== "web") {
      Alert.alert("Excel connect", "Import is available in the web version.");
      return;
    }
    inputRef.current?.click();
  }

  async function onFilePicked(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) await importFile(file);
    e.target.value = "";
  }

  return (
    <View style={styles.card}>
      <Text style={styles.eyebrow}>EXCEL CONNECT</Text>
      <Text style={styles.title}>Push and pull your tracking sheet</Text>
      <Text style={styles.help}>
        Manual, two-way. Export gives you a .xlsx with Tasks, Projects, Checklist, and Training. Edit it in Excel, then Import
        it back to merge those changes in. Nothing syncs on its own in the background.
      </Text>

      {Platform.OS === "web" ? (
        <input
          ref={inputRef}
          type="file"
          accept=".xlsx"
          style={{ display: "none" }}
          onChange={(e) => void onFilePicked(e)}
        />
      ) : null}

      <View style={styles.row}>
        <Pressable onPress={() => void exportNow()} style={styles.exportButton}>
          <Text style={styles.exportText}>Export Excel</Text>
        </Pressable>
        <Pressable onPress={triggerImport} disabled={isBusy} style={[styles.importButton, isBusy && styles.disabled]}>
          <Text style={styles.importText}>{isBusy ? "Importing..." : "Import Excel"}</Text>
        </Pressable>
      </View>

      <Text style={styles.meta}>
        {lastSyncedAt ? `Last synced ${new Date(lastSyncedAt).toLocaleString()}` : "Not synced yet on this device."}
      </Text>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      {lastSummary ? (
        <View style={styles.summaryRow}>
          <Text style={styles.summaryItem}>Added {lastSummary.added}</Text>
          <Text style={styles.summaryItem}>Updated {lastSummary.updated}</Text>
          <Text style={styles.summaryItem}>Skipped {lastSummary.skipped}</Text>
          <Text style={[styles.summaryItem, lastSummary.conflicts > 0 && styles.summaryWarning]}>Conflicts {lastSummary.conflicts}</Text>
        </View>
      ) : null}

      {conflicts.length > 0 ? (
        <View style={styles.conflictBlock}>
          <Text style={styles.conflictHeading}>Both sides changed. Pick which one wins.</Text>
          {conflicts.map((conflict) => (
            <View key={`${conflict.entityType}-${conflict.id}`} style={styles.conflictRow}>
              <Text style={styles.conflictTitle}>{conflictLabel(conflict.entityType)}: {conflictTitle(conflict.appVersion)}</Text>
              <Text style={styles.conflictDetail}>App has: {conflictTitle(conflict.appVersion)}</Text>
              <Text style={styles.conflictDetail}>Excel has: {conflictTitle(conflict.excelVersion)}</Text>
              <View style={styles.row}>
                <Pressable onPress={() => void resolveConflict(conflict, "keep-app")} style={styles.smallButton}>
                  <Text style={styles.smallButtonText}>Keep app</Text>
                </Pressable>
                <Pressable onPress={() => void resolveConflict(conflict, "keep-excel")} style={styles.smallButton}>
                  <Text style={styles.smallButtonText}>Keep Excel</Text>
                </Pressable>
              </View>
            </View>
          ))}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: "#FFF", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, marginTop: 12, padding: 14 },
  eyebrow: { color: "#B96B3C", fontSize: 10, fontWeight: "800", letterSpacing: 1.4 },
  title: { color: "#234137", fontSize: 17, fontWeight: "800", marginTop: 4 },
  help: { color: "#6E716B", fontSize: 11, lineHeight: 17, marginTop: 6 },
  row: { alignItems: "center", flexDirection: "row", gap: 8, marginTop: 10 },
  exportButton: { backgroundColor: "#234137", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9 },
  exportText: { color: "#FFF", fontSize: 11, fontWeight: "800" },
  importButton: { backgroundColor: "#B56A38", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9 },
  importText: { color: "#FFF", fontSize: 11, fontWeight: "800" },
  disabled: { opacity: 0.6 },
  meta: { color: "#74766F", fontSize: 10, marginTop: 8 },
  error: { color: "#A53D35", fontSize: 11, fontWeight: "700", marginTop: 8 },
  summaryRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginTop: 10 },
  summaryItem: { color: "#587A5A", fontSize: 10, fontWeight: "800" },
  summaryWarning: { color: "#B56A38" },
  conflictBlock: { borderTopColor: "#EDE7DC", borderTopWidth: 1, marginTop: 12, paddingTop: 10 },
  conflictHeading: { color: "#334139", fontSize: 11, fontWeight: "800" },
  conflictRow: { backgroundColor: "#FBF9F4", borderRadius: 12, marginTop: 8, padding: 10 },
  conflictTitle: { color: "#334139", fontSize: 11, fontWeight: "800" },
  conflictDetail: { color: "#74766F", fontSize: 10, marginTop: 3 },
  smallButton: { borderColor: "#A8CBB0", borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 6 },
  smallButtonText: { color: "#587A5A", fontSize: 9, fontWeight: "800" },
});
