import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  "house.fill": "home",
  "book.closed.fill": "menu-book",
  "calendar": "calendar-today",
  "people.fill": "people",
  "book": "menu-book",
  "square.grid.2x2.fill": "dashboard",
  "mappin.and.ellipse": "location-on",
  "leaf.fill": "spa",
  "gearshape.fill": "settings",
  "plus": "add",
  "arrow.left": "arrow-back",
  "chevron.right": "chevron-right",
  "chevron.down": "keyboard-arrow-down",
  "trash": "delete-outline",
  "magnifyingglass": "search",
  "lock.fill": "lock",
  "sparkles": "auto-awesome",
  "checkmark": "check",
  "xmark": "close",
  "heart.fill": "favorite",
  "ellipsis": "more-horiz",
} as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
