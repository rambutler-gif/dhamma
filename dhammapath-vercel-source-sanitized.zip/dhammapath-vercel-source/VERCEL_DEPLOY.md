# Dhammapath on Vercel

Dhammapath can be deployed as a web first personal application. Vercel serves the Expo web export from `dist-web`. The `vercel.json` file already defines the build command and route fallback.

## Deploy steps

1. Import the project into Vercel.
2. Select the project root.
3. Keep the build command as `pnpm build:web`.
4. Keep the output directory as `dist-web`.
5. Deploy the web version.
6. Set access to private when personal privacy is required.

## Local storage

Stories, the central Me profile, Rooms, diary entries, goals, habits, and saved practice responses remain in browser storage. Clearing browser data can remove them. The current web version does not provide cloud backup.

## NVIDIA guidance

The NVIDIA key must not be placed in the web bundle. Keep it in the protected backend as `NVIDIA_API_KEY`. The Vercel static deployment can use local guidance without that key. NVIDIA guidance requires the protected backend to remain available at its configured API base URL.

## Personal use

Use a private Vercel project or access restriction. Do not publish personal stories through a public URL. Vercel free plans may have usage limits and terms that can change. Do not treat free hosting as an unlimited lifetime guarantee.

## Install on Android

Open the deployed HTTPS URL in Chrome. Open the browser menu. Choose `Add to Home screen` or `Install app`. Confirm the name Dhammapath. Launch it from the new home screen icon.

## Install on iPhone

Open the deployed HTTPS URL in Safari. Tap Share. Choose `Add to Home Screen`. Confirm the name Dhammapath. Launch it from the new home screen icon.

## Offline behavior

The service worker caches the web shell and branding assets. Local stories, Rooms, the central Me profile, diary entries, goals, habits, and saved practice responses remain in browser storage. NVIDIA guidance requires an internet connection and a reachable protected backend. Clearing browser storage can remove local memories. This PWA is not an Android APK or an App Store application.

## Verification

After deployment, open the home page, `/calendar`, `/boxes`, `/practice`, and `/settings`. Confirm that the language switcher, central Me profile, local stories, diary entries, goals, and habits load correctly. Confirm that the browser reports the manifest and service worker as active.
