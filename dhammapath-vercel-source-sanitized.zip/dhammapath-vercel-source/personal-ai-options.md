# Personal AI Connection Research

Research date: 25 August 2026.

## Gemini Developer API
Source: https://ai.google.dev/gemini-api/docs/pricing

Google's official pricing page presents a Free tier for developers and small projects. It states that access is limited to certain models and free input and output tokens are available within limits. The same page presents a Paid tier for production applications with higher volumes and advanced features. Free access is therefore useful for a personal trial, but it should not be treated as unlimited or permanently guaranteed.

## Ollama
Source: https://docs.ollama.com/

Ollama's official documentation says users can start with open models, run models locally, or use larger models through Ollama Cloud. It provides local and cloud API paths plus JavaScript and Python integrations. A local model does not require an external provider API key, but it requires a computer or server with enough storage, memory, and processing power. A phone app generally cannot assume that Ollama is running locally on the phone; it would normally connect to a computer on the same network or to a separate server.

## Practical conclusion

For one personal user, the simplest options are a provider free tier with a private server side key, or a local Ollama installation on a personal computer. A provider free tier is easier and usually gives better mobile responsiveness. Ollama gives stronger data control and no per request provider charge, but hardware and maintenance become the user's responsibility. A single shared key should never be placed inside the mobile app. It must stay on a server or private gateway.
