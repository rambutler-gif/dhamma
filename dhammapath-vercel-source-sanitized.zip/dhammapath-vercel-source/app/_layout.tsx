import "../global.css";
import { useEffect } from "react";
import { Platform } from "react-native";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";

import { PrivateGate } from "@/components/private-gate";
import { LanguageProvider } from "@/lib/language-context";
import { PrivateSpaceProvider } from "@/lib/private-space";
import { PlanningProvider } from "@/lib/planning-context";
import { PeopleProvider } from "@/lib/people-context";
import { ExecutiveDashboardProvider } from "@/lib/executive-dashboard-context";
import { OperationalProvider } from "@/lib/operational-context";
import { ExcelSyncProvider } from "@/lib/excel-sync-context";
import { StoriesProvider } from "@/lib/stories-context";
import { ThemeProvider } from "@/lib/theme-provider";

export default function RootLayout() {
  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined" || !("serviceWorker" in navigator)) return;
    const register = () => {
      navigator.serviceWorker.register("/service-worker.js").catch(() => undefined);
    };
    if (document.readyState === "complete") register();
    else window.addEventListener("load", register);
    return () => window.removeEventListener("load", register);
  }, []);

  return (
    <ThemeProvider>
      <PrivateSpaceProvider>
        <LanguageProvider>
          <StoriesProvider>
          <PlanningProvider>
          <ExecutiveDashboardProvider>
          <OperationalProvider>
          <ExcelSyncProvider>
          <PeopleProvider>
          <StatusBar style="auto" />
          <PrivateGate>
            <Stack screenOptions={{ headerShown: false, animation: "slide_from_right" }} />
          </PrivateGate>
          </PeopleProvider>
          </ExcelSyncProvider>
          </OperationalProvider>
          </ExecutiveDashboardProvider>
          </PlanningProvider>
          </StoriesProvider>
        </LanguageProvider>
      </PrivateSpaceProvider>
    </ThemeProvider>
  );
}
