import { useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { buildConnectedRoomContext, buildInsight, buildMeProfileContext, buildPlanningContext, buildPriorStoryContext, containsCrisisLanguage, getReflectionQuestions } from "@/lib/reflection";
import { getStoryById, useStories } from "@/lib/stories-context";
import { usePrivateSpace } from "@/lib/private-space";
import { usePlanning } from "@/lib/planning-context";
import { FEELINGS, type DhammaInsight, type Feeling, type ReflectionAnswer } from "@/lib/types";
import { useLanguage } from "@/lib/language-context";
import { trpc } from "@/lib/trpc";

function InsightView({ insight, onPractise, onClose, onSaveCheckIn }: { insight: DhammaInsight; onPractise: () => void; onClose: () => void; onSaveCheckIn: (emotion: Feeling, intensity: 1 | 2 | 3 | 4 | 5, note?: string) => Promise<void> }) {
  const { t } = useLanguage();
  const [emotion, setEmotion] = useState<Feeling>("calm");
  const [intensity, setIntensity] = useState<1 | 2 | 3 | 4 | 5>(3);
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);

  async function saveCheckIn() {
    await onSaveCheckIn(emotion, intensity, note.trim() || undefined);
    setSaved(true);
  }
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center gap-2"><View className="h-2 w-2 rounded-full bg-success" /><Text className="text-xs font-bold uppercase tracking-widest text-success">{t("insight")}</Text></View>
        <Pressable onPress={onClose} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}><IconSymbol name="xmark" size={19} color="#1B2A25" /></Pressable>
      </View>
      <Text className="mt-7 text-3xl font-bold leading-9 text-foreground">{t("reflection")}</Text>
      <Text className="mt-3 text-base leading-6 text-muted">{t("answerPrivacy")}</Text>

      <InsightSection label={t("clearSeeing")} text={insight.seeingClearly} tone="neutral" />
      <InsightSection label={t("wrongView")} text={insight.possibleWrongView} tone="warning" />
      <InsightSection label={t("meaning")} text={insight.meaning} tone="neutral" />
      <InsightSection label={t("wiser")} text={insight.wiserSubstitute} tone="success" />
      <InsightSection label={t("smallPractice")} text={insight.smallPractice} tone="primary" />

      <View className="mt-5 rounded-2xl border border-border bg-surface px-4 py-3"><Text className="text-xs font-semibold text-muted">{t("grounded")} {insight.principle}.</Text></View>
      {insight.dhammaKeys?.length ? (
        <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("dhammaKeys")}</Text>
          <Text className="mt-2 text-sm leading-5 text-muted">{t("referenceNote")}</Text>
          {insight.dhammaKeys.map((item) => (
            <View key={item.key} className="mt-4 border-t border-border pt-4">
              <Text className="text-base font-bold text-foreground">{item.pali}</Text>
              <Text className="mt-1 text-sm font-semibold text-foreground">{item.meaning}</Text>
              <Text className="mt-1 text-sm leading-5 text-muted">{item.description}</Text>
              <Pressable onPress={() => Linking.openURL(item.referenceUrl)} style={({ pressed }) => [styles.referenceButton, pressed && styles.faded]}>
                <Text className="text-sm font-semibold text-primary">{t("sourceReference")}: {item.reference}</Text>
              </Pressable>
            </View>
          ))}
        </View>
      ) : null}
      {insight.mentorQuestion || insight.potentialDirection ? (
        <View className="mt-5 rounded-3xl border border-primary/30 bg-primary/10 px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("mentorLens")}</Text>
          {insight.mentorQuestion ? <><Text className="mt-4 text-xs font-bold uppercase tracking-widest text-primary">{t("momentQuestion")}</Text><Text className="mt-2 text-base font-semibold leading-6 text-foreground">{insight.mentorQuestion}</Text></> : null}
          {insight.potentialDirection ? <><Text className="mt-4 text-xs font-bold uppercase tracking-widest text-primary">{t("potentialDirection")}</Text><Text className="mt-2 text-sm leading-5 text-foreground">{insight.potentialDirection}</Text></> : null}
        </View>
      ) : null}
      <Text className="mt-5 text-center text-xs leading-5 text-muted">{t("choice")}</Text>
      <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5">
        <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("presentQuestion")}</Text>
        <Text className="mt-2 text-sm leading-5 text-muted">{t("recordMoment")}</Text>
        <View className="mt-4 flex-row flex-wrap gap-2">
          {FEELINGS.map((item) => (
            <Pressable key={item.key} onPress={() => setEmotion(item.key)} style={[styles.emotionChip, emotion === item.key && styles.emotionChipSelected]}>
              <Text className="text-sm font-semibold" style={{ color: emotion === item.key ? "#F7F4EE" : "#1B2A25" }}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
        <Text className="mt-4 text-sm font-semibold text-foreground">{t("intensity")}: {intensity}/5</Text>
        <View className="mt-2 flex-row gap-2">
          {[1, 2, 3, 4, 5].map((level) => (
            <Pressable key={level} onPress={() => setIntensity(level as 1 | 2 | 3 | 4 | 5)} style={[styles.levelButton, level <= intensity && styles.levelButtonSelected]}>
              <Text className="text-sm font-bold" style={{ color: level <= intensity ? "#F7F4EE" : "#6C7770" }}>{level}</Text>
            </Pressable>
          ))}
        </View>
        <TextInput value={note} onChangeText={setNote} placeholder={t("oneSentence")} placeholderTextColor="#9A9E98" className="mt-4 rounded-2xl border border-border bg-background px-4 py-3 text-sm text-foreground" />
        <Pressable onPress={saveCheckIn} disabled={saved} style={[styles.checkInButton, saved && styles.savedButton]}><Text className="text-sm font-bold text-background">{saved ? t("checkInSaved") : t("saveCheckIn")}</Text></Pressable>
      </View>
      <Pressable onPress={onPractise} style={({ pressed }) => [styles.practiceButton, pressed && styles.pressed]}><IconSymbol name="checkmark" size={18} color="#F7F4EE" /><Text className="ml-2 text-sm font-bold text-background">{t("practiseThis")}</Text></Pressable>
      <Pressable onPress={onClose} style={({ pressed }) => [styles.notNowButton, pressed && styles.faded]}><Text className="text-sm font-semibold text-muted">{t("notNow")}</Text></Pressable>
    </ScrollView>
  );
}

function InsightSection({ label, text, tone }: { label: string; text: string; tone: "neutral" | "warning" | "success" | "primary" }) {
  const classes = tone === "warning" ? "border-warning/30 bg-warning/10" : tone === "success" ? "border-success/30 bg-success/10" : tone === "primary" ? "border-primary/30 bg-primary/10" : "border-border bg-surface";
  const labelColor = tone === "warning" ? "text-warning" : tone === "success" ? "text-success" : tone === "primary" ? "text-primary" : "text-muted";
  return <View className={`mt-4 rounded-3xl border px-5 py-5 ${classes}`}><Text className={`text-xs font-bold uppercase tracking-widest ${labelColor}`}>{label}</Text><Text className="mt-3 text-base leading-6 text-foreground">{text}</Text></View>;
}

function SafetyCard({ onClose }: { onClose: () => void }) {
  const { t } = useLanguage();
  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5" safeAreaClassName="bg-background">
      <View className="flex-1 justify-center">
        <View className="h-14 w-14 items-center justify-center rounded-full bg-error/10"><IconSymbol name="heart.fill" size={25} color="#B04A43" /></View>
        <Text className="mt-6 text-3xl font-bold leading-9 text-foreground">{t("safetyTitle")}</Text>
        <Text className="mt-4 text-base leading-6 text-foreground">{t("safetyBody")}</Text>
        <View className="mt-6 rounded-3xl border border-error/30 bg-error/10 px-5 py-5"><Text className="text-base font-semibold leading-6 text-foreground">{t("urgentHelp")}</Text></View>
        <Text className="mt-5 text-sm leading-5 text-muted">{t("humanSupport")}</Text>
        <Pressable onPress={onClose} style={({ pressed }) => [styles.practiceButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{t("returnStory")}</Text></Pressable>
      </View>
    </ScreenContainer>
  );
}

export default function ReflectionScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { stories, isLoaded, updateStory, addEmotionCheckIn } = useStories();
  const { boxes, meProfile } = usePrivateSpace();
  const { items: planningItems, habits } = usePlanning();
  const { t } = useLanguage();
  const aiReflect = trpc.ai.reflect.useMutation();
  const story = useMemo(() => getStoryById(stories, id), [stories, id]);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [answers, setAnswers] = useState<ReflectionAnswer[]>([]);
  const [insight, setInsight] = useState<DhammaInsight | null>(story?.insight ?? null);
  const activeBox = boxes.find((box) => box.id === story?.boxId);
  const centralBox = boxes.find((box) => box.id === "me");
  const connectedRoomContext = buildConnectedRoomContext(boxes, story?.boxId);
  const priorStoryContext = story ? buildPriorStoryContext(stories, story.id) : "";
  const meProfileContext = buildMeProfileContext(meProfile);
  const planningContext = buildPlanningContext(planningItems, habits);
  const questions = getReflectionQuestions(activeBox);

  if (!isLoaded) return <ScreenContainer className="items-center justify-center"><Text className="text-muted">{t("openingStory")}</Text></ScreenContainer>;
  if (!story) return <ScreenContainer className="items-center justify-center"><Text className="text-xl font-bold text-foreground">{t("storyNotFound")}</Text></ScreenContainer>;
  const savedStory = story;
  if (containsCrisisLanguage(`${savedStory.title} ${savedStory.content} ${JSON.stringify(savedStory.structured ?? {})}`)) return <SafetyCard onClose={() => router.back()} />;
  if (insight) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5" safeAreaClassName="bg-background">
        <InsightView insight={insight} onClose={() => router.back()} onSaveCheckIn={(emotion, intensity, note) => addEmotionCheckIn(savedStory.id, { emotion, intensity, note })} onPractise={() => { Alert.alert("Practice saved", "Return to this small practice when you are ready."); router.push("/(tabs)/practice"); }} />
      </ScreenContainer>
    );
  }

  const currentQuestion = questions[questionIndex];
  const progress = `${questionIndex + 1} of ${questions.length}`;

  async function submitAnswer() {
    const nextAnswers = [...answers, { questionId: currentQuestion.id, question: currentQuestion.prompt, answer: answer.trim() || "I am not sure yet." }];
    if (containsCrisisLanguage(answer)) {
      return;
    }
    if (questionIndex < questions.length - 1) {
      setAnswers(nextAnswers);
      setAnswer("");
      setQuestionIndex((value) => value + 1);
      return;
    }
    const localInsight = buildInsight(savedStory, nextAnswers, activeBox?.script, connectedRoomContext, priorStoryContext, meProfileContext, planningContext);
    // Show the local, fully-offline insight immediately. No network wait.
    await updateStory(savedStory.id, { insight: localInsight, reflectionAnswers: nextAnswers });
    setAnswers(nextAnswers);
    setInsight(localInsight);

    // Silently try to upgrade to the deeper mentor version in the background.
    // If it succeeds, swap it in. If it fails or the backend isn't configured,
    // the local insight already on screen stays exactly as is.
    try {
      const enhanced = { ...await aiReflect.mutateAsync({
        title: savedStory.title,
        content: savedStory.content,
        feeling: savedStory.feeling,
        where: savedStory.where,
        structured: savedStory.structured,
        masterScript: activeBox?.script,
        centralScript: centralBox?.script,
        meProfile: meProfileContext,
        planningContext,
        connectedRoomContext,
        priorStoryContext,
        answers: nextAnswers.map((item) => ({ question: item.question, answer: item.answer })),
      }), dhammaKeys: localInsight.dhammaKeys, mentorQuestion: localInsight.mentorQuestion, potentialDirection: localInsight.potentialDirection };
      await updateStory(savedStory.id, { insight: enhanced, reflectionAnswers: nextAnswers });
      setInsight(enhanced);
    } catch {
      // Local insight already shown. Nothing to do.
    }
  }

  if (containsCrisisLanguage(answer)) return <SafetyCard onClose={() => router.back()} />;

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5" safeAreaClassName="bg-background">
      <KeyboardAvoidingView className="flex-1" behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View className="flex-row items-center justify-between"><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}><IconSymbol name="arrow.left" size={20} color="#1B2A25" /></Pressable><Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("reflection")}</Text><Text className="text-xs font-semibold text-muted">{progress}</Text></View>
          <View className="mt-7 h-1.5 overflow-hidden rounded-full bg-border"><View className="h-full rounded-full bg-primary" style={{ width: `${((questionIndex + 1) / questions.length) * 100}%` }} /></View>
          <Text className="mt-10 text-xs font-bold uppercase tracking-widest text-muted">{currentQuestion.label}</Text>
          <Text className="mt-3 text-3xl font-bold leading-9 text-foreground">{currentQuestion.prompt}</Text>
          <Text className="mt-3 text-base leading-6 text-muted">{currentQuestion.helper}</Text>
          <TextInput value={answer} onChangeText={setAnswer} placeholder="Write what is true..." placeholderTextColor="#9A9E98" multiline autoFocus textAlignVertical="top" className="mt-8 min-h-[210px] rounded-3xl border border-border bg-surface px-5 py-5 text-base leading-6 text-foreground" />
          <View className="mt-5 flex-row items-center justify-between"><Pressable onPress={() => { setAnswer(""); submitAnswer(); }} style={({ pressed }) => [styles.skipButton, pressed && styles.faded]}><Text className="text-sm font-semibold text-muted">{t("notSure")}</Text></Pressable><Pressable onPress={submitAnswer} style={({ pressed }) => [styles.nextButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{questionIndex === questions.length - 1 ? t("seeInsight") : t("continue")}</Text><IconSymbol name="chevron.right" size={18} color="#F7F4EE" /></Pressable></View>
          <Text className="mt-8 text-center text-xs leading-5 text-muted">{t("answerPrivacy")}</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 36 },
  iconButton: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, height: 40, justifyContent: "center", width: 40 },
  practiceButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 18, flexDirection: "row", justifyContent: "center", marginTop: 23, paddingVertical: 16 },
  notNowButton: { alignItems: "center", paddingVertical: 16 },
  skipButton: { paddingVertical: 14, paddingRight: 16 },
  nextButton: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 17, flexDirection: "row", gap: 10, paddingHorizontal: 17, paddingVertical: 14 },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  faded: { opacity: 0.6 },
  emotionChip: { backgroundColor: "#DCE7DF", borderRadius: 18, paddingHorizontal: 12, paddingVertical: 8 },
  emotionChipSelected: { backgroundColor: "#3E78A3" },
  levelButton: { alignItems: "center", backgroundColor: "#DCE7DF", borderRadius: 14, height: 34, justifyContent: "center", width: 34 },
  levelButtonSelected: { backgroundColor: "#C8753D" },
  checkInButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 16, marginTop: 14, paddingVertical: 13 },
  savedButton: { backgroundColor: "#D9E8D3" },
  referenceButton: { marginTop: 8 },
});
