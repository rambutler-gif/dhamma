import { useLocalSearchParams, useRouter } from "expo-router";
import { Image } from "expo-image";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useLanguage } from "@/lib/language-context";

const MAPS = {
  sutta: {
    title: "Sutta Piṭaka",
    tamilTitle: "சுத்த பிடகம்",
    descriptionKey: "suttaDescription",
    asset: require("@/assets/images/sutta-pitaka-mindmap.webp"),
  },
  vinaya: {
    title: "Vinaya Piṭaka",
    tamilTitle: "வினய பிடகம்",
    descriptionKey: "vinayaDescription",
    asset: require("@/assets/images/vinaya-pitaka-mindmap.webp"),
  },
} as const;

type MapKind = keyof typeof MAPS;

export default function PitakaViewerScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const { kind } = useLocalSearchParams<{ kind: string }>();
  const map = MAPS[(kind === "vinaya" ? "vinaya" : "sutta") as MapKind];

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-4" safeAreaClassName="bg-background">
      <View className="flex-row items-center justify-between pt-2">
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}>
          <IconSymbol name="arrow.left" size={20} color="#1B2A25" />
        </Pressable>
        <View className="items-center">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("learn")}</Text>
          <Text className="mt-1 text-base font-bold text-foreground">{kind === "vinaya" ? t("vinaya") : t("sutta")}</Text>
        </View>
        <View style={styles.iconButton} />
      </View>

      <Text className="mt-5 text-2xl font-bold text-foreground">{kind === "vinaya" ? t("vinaya") : t("sutta")}</Text>
      <Text className="mt-2 text-sm leading-5 text-muted">{t(map.descriptionKey)}</Text>
      <Text className="mt-1 text-xs leading-5 text-muted">{t("openMap")}</Text>

      <View className="mt-5 flex-1 overflow-hidden rounded-3xl border border-border bg-surface">
        <ScrollView horizontal showsHorizontalScrollIndicator={true} contentContainerStyle={styles.horizontalContent}>
          <ScrollView showsVerticalScrollIndicator={true} contentContainerStyle={styles.verticalContent}>
            <Image source={map.asset} contentFit="contain" cachePolicy="disk" transition={200} style={styles.mapImage} accessibilityLabel={`${map.title} Tamil mind map`} />
          </ScrollView>
        </ScrollView>
      </View>
      <Text className="mb-2 mt-3 text-center text-xs leading-5 text-muted">{t("sourceTexts")}</Text>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  horizontalContent: { minWidth: "100%", padding: 12 },
  verticalContent: { minHeight: "100%" },
  mapImage: { height: 690, width: 1235 },
  iconButton: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, height: 40, justifyContent: "center", width: 40 },
  faded: { opacity: 0.6 },
});
