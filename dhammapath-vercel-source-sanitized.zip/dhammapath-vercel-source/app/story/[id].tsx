import { useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { getStoryById, useStories } from "@/lib/stories-context";
import { usePrivateSpace } from "@/lib/private-space";
import { FEELINGS, type StructuredReflection } from "@/lib/types";
import { useLanguage } from "@/lib/language-context";

function feelingLabel(key: string) {
  return FEELINGS.find((feeling) => feeling.key === key)?.label ?? "Feeling";
}

function StructuredField({ label, value }: { label: string; value?: string }) {
  if (!value?.trim()) return null;
  return (
    <View className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4">
      <Text className="text-xs font-bold uppercase tracking-widest text-primary">{label}</Text>
      <Text className="mt-2 text-sm leading-6 text-foreground">{value}</Text>
    </View>
  );
}

function StructuredEditorField({ label, value, onChangeText }: { label: string; value: string; onChangeText: (value: string) => void }) {
  return (
    <View className="mt-3">
      <Text className="text-xs font-bold uppercase tracking-widest text-primary">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        multiline
        textAlignVertical="top"
        placeholder={label}
        placeholderTextColor="#9A9E98"
        className="mt-2 min-h-[82px] rounded-2xl border border-border bg-surface px-4 py-3 text-sm leading-6 text-foreground"
      />
    </View>
  );
}

const emptyStructuredReflection: StructuredReflection = {
  facts: "",
  assumptions: "",
  craving: "",
  fear: "",
  anger: "",
  selfStory: "",
};

export default function StoryDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { stories, updateStory, deleteStory } = useStories();
  const { boxes } = usePrivateSpace();
  const { t } = useLanguage();
  const story = useMemo(() => getStoryById(stories, id), [stories, id]);
  const [followUp, setFollowUp] = useState(story?.followUp ?? "");
  const [editingStructured, setEditingStructured] = useState(false);
  const [draftStructured, setDraftStructured] = useState<StructuredReflection>({ ...emptyStructuredReflection, ...story?.structured });
  const linkedBox = boxes.find((box) => box.id === story?.boxId);

  if (!story) {
    return (
      <ScreenContainer className="items-center justify-center px-6" edges={["top", "bottom", "left", "right"]}>
        <Text className="text-xl font-bold text-foreground">{t("storyNotFound")}</Text>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.smallButton, pressed && styles.faded]}>
          <Text className="font-semibold text-background">{t("goBack")}</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  const savedStory = story;

  async function saveFollowUp() {
    await updateStory(savedStory.id, { followUp: followUp.trim() });
    Alert.alert(t("savedTitle"), t("saveNote"));
  }

  async function saveStructured() {
    const cleaned: StructuredReflection = {
      facts: draftStructured.facts.trim(),
      assumptions: draftStructured.assumptions.trim(),
      craving: draftStructured.craving.trim(),
      fear: draftStructured.fear.trim(),
      anger: draftStructured.anger.trim(),
      selfStory: draftStructured.selfStory.trim(),
    };
    await updateStory(savedStory.id, { structured: cleaned });
    setDraftStructured(cleaned);
    setEditingStructured(false);
    Alert.alert(t("savedTitle"), t("saveStructured"));
  }

  function cancelStructuredEdit() {
    setDraftStructured({ ...emptyStructuredReflection, ...savedStory.structured });
    setEditingStructured(false);
  }

  function updateStructuredField(field: keyof StructuredReflection, value: string) {
    setDraftStructured((current) => ({ ...current, [field]: value }));
  }

  function confirmDelete() {
    Alert.alert("Delete this story?", "This cannot be undone on this device.", [
      { text: "Keep it", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => { await deleteStory(savedStory.id); router.replace("/(tabs)/stories"); } },
    ]);
  }

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} className="px-5" safeAreaClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View className="flex-row items-center justify-between">
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}>
            <IconSymbol name="arrow.left" size={20} color="#1B2A25" />
          </Pressable>
          <Text className="text-sm font-semibold uppercase tracking-widest text-muted">{t("story")}</Text>
          <Pressable onPress={confirmDelete} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}>
            <IconSymbol name="trash" size={19} color="#B04A43" />
          </Pressable>
        </View>

        {linkedBox ? <View className="mt-6 flex-row items-center gap-2 rounded-2xl bg-primary/10 px-4 py-3"><IconSymbol name="square.grid.2x2.fill" size={17} color="#B56A38" /><Text className="text-sm font-semibold text-foreground">{t("story")} · {linkedBox.name}</Text></View> : null}

        <View className="mt-8 flex-row items-center gap-2">
          <View className="h-2 w-2 rounded-full bg-primary" />
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{feelingLabel(savedStory.feeling)}</Text>
        </View>
        <Text className="mt-3 text-3xl font-bold leading-9 text-foreground">{savedStory.title}</Text>
        <Text className="mt-5 text-base leading-7 text-foreground">{savedStory.content}</Text>
        {savedStory.where ? <View className="mt-4 flex-row items-center gap-2"><IconSymbol name="mappin.and.ellipse" size={17} color="#587A5A" /><Text className="text-sm font-semibold text-muted">{t("whereHappened")}: {savedStory.where}</Text></View> : null}

        <View className="mt-8">
          <View className="flex-row items-center justify-between">
            <Text className="flex-1 text-xs font-bold uppercase tracking-widest text-muted">{t("structuredReflection")}</Text>
            <Pressable
              onPress={() => (editingStructured ? cancelStructuredEdit() : setEditingStructured(true))}
              style={({ pressed }) => [styles.smallOutlineButton, pressed && styles.faded]}
            >
              <Text className="text-xs font-bold text-foreground">{editingStructured ? t("cancel") : t("editStructured")}</Text>
            </Pressable>
          </View>
          <Text className="mt-2 text-sm leading-5 text-muted">{t("structuredHelper")}</Text>
          {editingStructured ? (
            <>
              <StructuredEditorField label={t("factsLabel")} value={draftStructured.facts} onChangeText={(value) => updateStructuredField("facts", value)} />
              <StructuredEditorField label={t("assumptionsLabel")} value={draftStructured.assumptions} onChangeText={(value) => updateStructuredField("assumptions", value)} />
              <StructuredEditorField label={t("cravingLabel")} value={draftStructured.craving} onChangeText={(value) => updateStructuredField("craving", value)} />
              <StructuredEditorField label={t("fearLabel")} value={draftStructured.fear} onChangeText={(value) => updateStructuredField("fear", value)} />
              <StructuredEditorField label={t("angerLabel")} value={draftStructured.anger} onChangeText={(value) => updateStructuredField("anger", value)} />
              <StructuredEditorField label={t("selfStoryLabel")} value={draftStructured.selfStory} onChangeText={(value) => updateStructuredField("selfStory", value)} />
              <Pressable onPress={saveStructured} style={({ pressed }) => [styles.outlineButton, pressed && styles.faded]}>
                <Text className="text-sm font-bold text-foreground">{t("saveStructured")}</Text>
              </Pressable>
            </>
          ) : savedStory.structured && Object.values(savedStory.structured).some((value) => value.trim()) ? (
            <>
              <StructuredField label={t("factsLabel")} value={savedStory.structured.facts} />
              <StructuredField label={t("assumptionsLabel")} value={savedStory.structured.assumptions} />
              <StructuredField label={t("cravingLabel")} value={savedStory.structured.craving} />
              <StructuredField label={t("fearLabel")} value={savedStory.structured.fear} />
              <StructuredField label={t("angerLabel")} value={savedStory.structured.anger} />
              <StructuredField label={t("selfStoryLabel")} value={savedStory.structured.selfStory} />
            </>
          ) : (
            <View className="mt-3 rounded-2xl border border-dashed border-border px-4 py-4">
              <Text className="text-sm leading-5 text-muted">{t("structuredHelper")}</Text>
            </View>
          )}
        </View>

        <View className="mt-8 rounded-3xl bg-surface px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted">{t("gentleNextStep")}</Text>
          <Text className="mt-3 text-base leading-6 text-foreground">{t("storyGuidance")}</Text>
          <Pressable onPress={() => router.push({ pathname: "/reflection/[id]", params: { id: savedStory.id } })} style={({ pressed }) => [styles.reflectButton, pressed && styles.pressed]}>
            <IconSymbol name="sparkles" size={18} color="#F7F4EE" />
            <Text className="ml-2 text-sm font-bold text-background">{t("beginReflection")}</Text>
          </Pressable>
        </View>

        {savedStory.insight ? (
          <Pressable onPress={() => router.push({ pathname: "/reflection/[id]", params: { id: savedStory.id, review: "true" } })} style={({ pressed }) => [styles.insightPreview, pressed && styles.faded]}>
            <View className="flex-1 pr-3">
              <Text className="text-xs font-bold uppercase tracking-widest text-success">{t("savedInsight")}</Text>
              <Text className="mt-2 text-base font-semibold text-foreground" numberOfLines={2}>{savedStory.insight.wiserSubstitute}</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color="#587A5A" />
          </Pressable>
        ) : null}

        {savedStory.reflectionAnswers?.length ? <View className="mt-8"><Text className="text-xs font-bold uppercase tracking-widest text-muted">{t("reflectionAnswers")}</Text>{savedStory.reflectionAnswers.map((entry, index) => <View key={`${entry.questionId}-${index}`} className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4"><View className="flex-row items-start"><View className="flex-1 pr-3"><Text className="text-xs font-bold uppercase tracking-widest text-primary">{entry.question}</Text><Text className="mt-2 text-sm leading-5 text-foreground">{entry.answer}</Text></View><Pressable onPress={() => Alert.alert(t("deleteAnswer"), t("deleteAnswerBody"), [{ text: t("cancel"), style: "cancel" }, { text: t("delete"), style: "destructive", onPress: () => updateStory(savedStory.id, { reflectionAnswers: savedStory.reflectionAnswers?.filter((_, answerIndex) => answerIndex !== index) }) }])} style={({ pressed }) => [styles.deleteAnswer, pressed && styles.faded]}><IconSymbol name="trash" size={16} color="#B04A43" /></Pressable></View></View>)}</View> : null}

        <View className="mt-8">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted">{t("followUpNote")}</Text>
          <TextInput
            value={followUp}
            onChangeText={setFollowUp}
            placeholder={t("presentQuestion")}
            placeholderTextColor="#9A9E98"
            multiline
            textAlignVertical="top"
            className="mt-3 min-h-[120px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground"
          />
          <Pressable onPress={saveFollowUp} style={({ pressed }) => [styles.outlineButton, pressed && styles.faded]}>
            <Text className="text-sm font-bold text-foreground">{t("saveNote")}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 36 },
  iconButton: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, height: 40, justifyContent: "center", width: 40 },
  reflectButton: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 16, flexDirection: "row", justifyContent: "center", marginTop: 18, paddingVertical: 14 },
  insightPreview: { alignItems: "center", backgroundColor: "#EDF4EA", borderRadius: 22, flexDirection: "row", marginTop: 14, padding: 17 },
  deleteAnswer: { padding: 5 },
  outlineButton: { alignItems: "center", borderColor: "#1B2A25", borderRadius: 16, borderWidth: 1, marginTop: 12, paddingVertical: 13 },
  smallOutlineButton: { alignItems: "center", borderColor: "#D9D2C5", borderRadius: 14, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 8 },
  smallButton: { backgroundColor: "#1B2A25", borderRadius: 16, marginTop: 18, paddingHorizontal: 18, paddingVertical: 13 },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  faded: { opacity: 0.6 },
});
