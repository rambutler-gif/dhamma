import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useStories } from "@/lib/stories-context";
import { FEELINGS, type Feeling } from "@/lib/types";
import { useLanguage } from "@/lib/language-context";

export default function NewStoryScreen() {
  const router = useRouter();
  const { boxId } = useLocalSearchParams<{ boxId?: string }>();
  const { addStory } = useStories();
  const { t } = useLanguage();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [where, setWhere] = useState("");
  const [facts, setFacts] = useState("");
  const [assumptions, setAssumptions] = useState("");
  const [craving, setCraving] = useState("");
  const [fear, setFear] = useState("");
  const [anger, setAnger] = useState("");
  const [selfStory, setSelfStory] = useState("");
  const [feeling, setFeeling] = useState<Feeling>("other");
  const [isSaving, setIsSaving] = useState(false);

  async function saveStory() {
    if (!title.trim() || !content.trim()) {
      Alert.alert(t("title"), t("writeExperience"));
      return;
    }
    setIsSaving(true);
    try {
      const story = await addStory({ title, content, feeling, where, boxId: typeof boxId === "string" ? boxId : undefined, structured: { facts: facts.trim(), assumptions: assumptions.trim(), craving: craving.trim(), fear: fear.trim(), anger: anger.trim(), selfStory: selfStory.trim() } });
      router.replace({ pathname: "/story/[id]", params: { id: story.id } });
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} className="px-5" safeAreaClassName="bg-background">
      <KeyboardAvoidingView className="flex-1" behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View className="flex-row items-center justify-between">
            <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}>
              <IconSymbol name="arrow.left" size={20} color="#1B2A25" />
            </Pressable>
            <Text className="text-sm font-semibold uppercase tracking-widest text-muted">{boxId ? t("story") : t("story")}</Text>
            <View className="w-10" />
          </View>

          <Text className="mt-8 text-3xl font-bold leading-9 text-foreground">{t("letItBeTrue")}</Text>
          <Text className="mt-3 text-base leading-6 text-muted">{t("writeExperience")}</Text>

          <Text className="mt-8 text-xs font-bold uppercase tracking-widest text-muted">{t("title")}</Text>
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder={t("title")}
            placeholderTextColor="#9A9E98"
            className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground"
            returnKeyType="next"
          />

          <Text className="mt-6 text-xs font-bold uppercase tracking-widest text-muted">{t("whatHappened")}</Text>
          <TextInput
            value={content}
            onChangeText={setContent}
            placeholder="I have been carrying..."
            placeholderTextColor="#9A9E98"
            multiline
            textAlignVertical="top"
            className="mt-3 min-h-[190px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground"
          />
          <Text className="mt-2 text-right text-xs text-muted">{content.length} characters</Text>

          <Text className="mt-6 text-xs font-bold uppercase tracking-widest text-muted">{t("whereHappened")}</Text>
          <TextInput value={where} onChangeText={setWhere} placeholder={t("whereHappened")} placeholderTextColor="#9A9E98" className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" />

          <View className="mt-7 rounded-3xl border border-border bg-primary/5 px-4 py-4">
            <Text className="text-base font-bold text-foreground">{t("structuredReflection")}</Text>
            <Text className="mt-1 text-sm leading-5 text-muted">{t("structuredHelper")}</Text>
            <Text className="mt-5 text-xs font-bold uppercase tracking-widest text-muted">{t("factsLabel")}</Text>
            <TextInput value={facts} onChangeText={setFacts} placeholder={t("factsLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[74px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
            <Text className="mt-4 text-xs font-bold uppercase tracking-widest text-muted">{t("assumptionsLabel")}</Text>
            <TextInput value={assumptions} onChangeText={setAssumptions} placeholder={t("assumptionsLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[74px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
            <Text className="mt-4 text-xs font-bold uppercase tracking-widest text-muted">{t("cravingLabel")}</Text>
            <TextInput value={craving} onChangeText={setCraving} placeholder={t("cravingLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[66px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
            <Text className="mt-4 text-xs font-bold uppercase tracking-widest text-muted">{t("fearLabel")}</Text>
            <TextInput value={fear} onChangeText={setFear} placeholder={t("fearLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[66px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
            <Text className="mt-4 text-xs font-bold uppercase tracking-widest text-muted">{t("angerLabel")}</Text>
            <TextInput value={anger} onChangeText={setAnger} placeholder={t("angerLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[66px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
            <Text className="mt-4 text-xs font-bold uppercase tracking-widest text-muted">{t("selfStoryLabel")}</Text>
            <TextInput value={selfStory} onChangeText={setSelfStory} placeholder={t("selfStoryLabel")} placeholderTextColor="#9A9E98" multiline className="mt-2 min-h-[74px] rounded-2xl border border-border bg-surface px-4 py-3 text-base leading-6 text-foreground" />
          </View>

          <Text className="mt-6 text-xs font-bold uppercase tracking-widest text-muted">{t("closestNow")}</Text>
          <View className="mt-3 flex-row flex-wrap gap-2">
            {FEELINGS.map((item) => {
              const selected = feeling === item.key;
              return (
                <Pressable
                  key={item.key}
                  onPress={() => setFeeling(item.key)}
                  style={({ pressed }) => [styles.feelingChip, selected && styles.selectedChip, pressed && styles.faded]}
                >
                  <Text className={selected ? "text-sm font-semibold text-background" : "text-sm font-semibold text-foreground"}>{item.label}</Text>
                </Pressable>
              );
            })}
          </View>

          <View className="mt-8 flex-row rounded-2xl bg-primary/10 px-4 py-3">
            <Text className="mr-3 text-base text-primary">i</Text>
            <Text className="flex-1 text-xs leading-5 text-muted">{t("privateJournal")}</Text>
          </View>

          <Pressable onPress={saveStory} disabled={isSaving} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed, isSaving && styles.disabled]}>
            <Text className="text-base font-bold text-background">{isSaving ? t("savedTitle") : t("saveNote")}</Text>
            <IconSymbol name="checkmark" size={19} color="#F7F4EE" />
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 34 },
  iconButton: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, height: 40, justifyContent: "center", width: 40 },
  feelingChip: { backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10 },
  selectedChip: { backgroundColor: "#B56A38", borderColor: "#B56A38" },
  saveButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 18, flexDirection: "row", justifyContent: "space-between", marginTop: 24, paddingHorizontal: 18, paddingVertical: 16 },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  faded: { opacity: 0.6 },
  disabled: { opacity: 0.55 },
});
