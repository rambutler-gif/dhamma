import { useMemo, useState } from "react";
import { Alert, FlatList, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useLanguage } from "@/lib/language-context";
import { usePlanning } from "@/lib/planning-context";
import { usePeople, type PersonRelationship } from "@/lib/people-context";
import { activeHabits, compliancePercent, habitCompletion, monthDays, taskNeedsEscalation, taskRolloverLabel, useExecutiveDashboard } from "@/lib/executive-dashboard-context";
import { useStories } from "@/lib/stories-context";
import { FEELINGS, type EmotionCheckIn, type PlanningItem, type PlanningItemType, type Story } from "@/lib/types";
import { FourWeekLifecycle } from "@/lib/lifecycle-view";
import { OperationalControlCenter } from "@/lib/operational-control-center";
import { useOperational } from "@/lib/operational-context";

function dayKey(value: string) {
  return value.slice(0, 10);
}

function formatDay(value: string) {
  return new Intl.DateTimeFormat("en-IN", { weekday: "short", day: "numeric", month: "short" }).format(new Date(`${value}T12:00:00`));
}

function emotionLabel(emotion: EmotionCheckIn["emotion"]) {
  return FEELINGS.find((item) => item.key === emotion)?.label ?? "Feeling";
}

type CalendarEntry = { day: string; items: Array<{ story: Story; checkIn: EmotionCheckIn }> };
type ComposerKind = PlanningItemType | "habit";
type DotState = "done" | "missed" | "empty";

function monthTitle(value: Date) {
  return new Intl.DateTimeFormat("en-IN", { month: "long", year: "numeric" }).format(value);
}
function dateLabel(value: string) {
  return new Intl.DateTimeFormat("en-IN", { weekday: "short", day: "numeric", month: "short" }).format(new Date(`${value}T12:00:00`));
}


const WEEKLY_AUDIT_PROMPT = `You are an elite Hospitality Management Consultant and Executive Coach. Perform a comprehensive weekend audit of my Hospitality Executive Dashboard and calendar data for the upcoming week.

Audit stalled tasks in Weekly Sprints and Daily Work. Identify rollover and escalated tasks. Cross-reference Setbacks & Pivot Log and weekly diary entries. Diagnose the systemic cause. Recommend delegation.

Calculate completion rates for Hydration, Industry Intel, and Physical Decompression. Flag drops and correlate them with high-stress events.

Surface Investors, VIP guests, critical Suppliers, and ExCom contacts outside their target windows. Suggest two or three relationship touchpoints.

Scan the upcoming week. Highlight the three highest-stakes events. Create tactical preparation checklists.

Return clean Markdown with: Executive Summary, Critical Bottlenecks, Personal Velocity, CRM Touchpoints, and Focus Agenda. Separate verified facts from missing data. Do not invent records.`;

const MASTER_ORCHESTRATION_PROMPT = `You are the executive orchestration layer for a private Hospitality Executive Dashboard.

Sync the dashboard with the connected calendar. Fetch today's events. Create Daily Work items from hotel walks, owner briefings, supplier meetings, and operational reviews. Match named stakeholders against Personal CRM and update Last Contacted.

At the end of every week, move completed high-impact tasks to the current month's Completed Archive. Roll unfinished tactical tasks into the next Weekly Sprints block. If a task rolls over for two consecutive weeks, move it to Quarterly & Monthly with the tag [ESCALATED FROM WEEKLY].

Parse the daily diary. Check Hydration, Industry Intel, and Physical Decompression. Record unexpected disruptions and bottlenecks in Setbacks & Pivot Log.

Strict rules: preserve task history, never delete evidence, never invent events, clearly mark missing data, and keep the operator in control.`;

async function copyPrompt(prompt: string) {
  if (Platform.OS === "web" && typeof navigator !== "undefined" && navigator.clipboard) {
    await navigator.clipboard.writeText(prompt);
    return;
  }
  Alert.alert("Prompt", prompt);
}

export default function CalendarScreen() {
  const { stories, deleteStory } = useStories();
  const { items, habits, addItem, updateItem, deleteItem, addHabit, toggleHabit, deleteHabit, rolloverSummary, runWeeklyRollover, captureCalendarEvent } = usePlanning();
  const { people, addPerson, deletePerson, markContactedFromEvent } = usePeople();
  const executive = useExecutiveDashboard();
  const { t } = useLanguage();
  const [composer, setComposer] = useState<ComposerKind | null>(null);
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [monthCursor, setMonthCursor] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [personName, setPersonName] = useState("");
  const [personRelationship, setPersonRelationship] = useState<PersonRelationship>("other");
  const [personNextContact, setPersonNextContact] = useState("");
  const [personNotes, setPersonNotes] = useState("");
  const [eventText, setEventText] = useState("");
  const [eventDate, setEventDate] = useState(() => new Date().toISOString().slice(0, 10));

  async function savePerson() {
    if (!personName.trim()) return;
    await addPerson({ name: personName.trim(), relationship: personRelationship, nextContact: personNextContact.trim() || undefined, notes: personNotes.trim(), room: undefined, interactions: [] });
    setPersonName(""); setPersonNextContact(""); setPersonNotes("");
  }

  function removeStoryEntry(story: Story) {
    Alert.alert("Delete this entry?", `Only “${story.title}” will be removed. Its Room will stay available.`, [
      { text: t("cancel"), style: "cancel" },
      { text: t("delete"), style: "destructive", onPress: () => deleteStory(story.id) },
    ]);
  }

  function openComposer(kind: ComposerKind) {
    setComposer(kind);
    setTitle("");
    setNote("");
    setDate(new Date().toISOString().slice(0, 10));
  }

  async function saveComposer() {
    if (!title.trim()) return;
    if (composer === "habit") {
      await addHabit({ title, note });
    } else if (composer) {
      await addItem({ type: composer, title, note, date });
    }
    setComposer(null);
  }

  const entries = useMemo<CalendarEntry[]>(() => {
    const grouped = new Map<string, CalendarEntry["items"]>();
    stories.forEach((story) => {
      (story.emotionCheckIns ?? []).forEach((checkIn) => {
        const day = dayKey(checkIn.createdAt);
        grouped.set(day, [...(grouped.get(day) ?? []), { story, checkIn }]);
      });
    });
    return Array.from(grouped.entries()).sort(([left], [right]) => right.localeCompare(left)).map(([day, groupedItems]) => ({ day, items: groupedItems }));
  }, [stories]);

  const typeLabel = (type: PlanningItemType) => type === "diary" ? t("diary") : type === "upcoming" ? t("upcomingWork") : type === "move" ? t("importantMove") : t("goal");
  const visiblePlans = items.filter((item) => !item.archivedAt && item.date === selectedDate).slice(0, 12);
  const archivedPlans = items.filter((item) => item.archivedAt).slice(0, 12);
  const today = new Date().toISOString().slice(0, 10);
  const monthDateKeys = monthDays(monthCursor.getFullYear(), monthCursor.getMonth());
  const executiveHabits = activeHabits(executive.habits).slice(0, 6);
  const selectedExecutiveTasks = executive.tasks.filter((task) => task.date === selectedDate);
  const selectedCertItems = executive.certItems.filter((item) => selectedDate >= item.startDate && selectedDate <= item.endDate);
  const dotState = (day: string): DotState => {
    const dayTasks = executive.tasks.filter((task) => task.date === day);
    const dayHabits = executiveHabits;
    const dayCert = executive.certItems.filter((item) => day >= item.startDate && day <= item.endDate);
    const hasData = dayTasks.length + dayHabits.length + dayCert.length > 0;
    if (!hasData) return "empty";
    const complete = dayTasks.every((task) => task.status === "done") && dayHabits.every((habit) => habit.completedDates.includes(day)) && dayCert.every((item) => item.loggedDates.includes(day));
    return complete ? "done" : "missed";
  };
  async function toggleDateStatus(day: string) {
    const state = dotState(day);
    const shouldComplete = state !== "done";
    for (const task of executive.tasks.filter((item) => item.date === day)) await executive.updateTask(task.id, { status: shouldComplete ? "done" : "open" });
    for (const habit of executiveHabits) {
      if (habit.completedDates.includes(day) !== shouldComplete) await executive.toggleHabitDate(habit.id, day);
    }
    for (const item of executive.certItems.filter((cert) => day >= cert.startDate && day <= cert.endDate)) {
      if (item.loggedDates.includes(day) !== shouldComplete) await executive.toggleCertDate(item.id, day);
    }
  }

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <FlatList
        data={entries}
        keyExtractor={(item) => item.day}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <Text className="text-sm font-semibold tracking-widest text-primary">{t("appName").toUpperCase()}</Text>
            <Text className="mt-1 text-3xl font-bold text-foreground">{t("calendarTitle")}</Text>
            <Text className="mt-2 text-sm leading-5 text-muted">{t("calendarHelp")}</Text>
            <View className="mt-6 rounded-3xl bg-foreground px-5 py-5"><Text className="text-xs font-semibold uppercase tracking-widest text-primary">{t("impermanent")}</Text><Text className="mt-3 text-xl font-semibold leading-7 text-background">{t("impermanent")}</Text><Text className="mt-2 text-sm leading-5 text-background" style={styles.softText}>{t("changingFeeling")}</Text></View>

            <View className="mt-7"><Text className="text-xl font-bold text-foreground">{t("planning")}</Text><Text className="mt-1 text-sm leading-5 text-muted">{t("planningHelp")}</Text><Text className="mt-2 text-xs leading-5 text-muted">{t("profilePlanning")}</Text><View className="mt-4 flex-row flex-wrap gap-2"><Pressable onPress={() => openComposer("diary")} style={({ pressed }) => [styles.planChip, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("addDiary")}</Text></Pressable><Pressable onPress={() => openComposer("upcoming")} style={({ pressed }) => [styles.planChip, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("addWork")}</Text></Pressable><Pressable onPress={() => openComposer("move")} style={({ pressed }) => [styles.planChip, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("addMove")}</Text></Pressable><Pressable onPress={() => openComposer("goal")} style={({ pressed }) => [styles.planChip, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("addGoal")}</Text></Pressable><Pressable onPress={() => openComposer("habit")} style={({ pressed }) => [styles.planChip, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("addHabit")}</Text></Pressable></View></View>

            <FourWeekLifecycle />

            <OperationalControlCenter />

            <ExecutiveCalendarPanel />

            <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-xs font-bold uppercase tracking-widest text-primary">People and contacts</Text><Text className="mt-2 text-base font-bold text-foreground">Private relationship layer</Text><Text className="mt-2 text-xs leading-5 text-muted">This stays inside Dhammapath. No external CRM is connected.</Text><TextInput value={personName} onChangeText={setPersonName} placeholder="Name" placeholderTextColor="#8A877F" style={styles.input} /><TextInput value={personRelationship} onChangeText={(value) => setPersonRelationship((value || "other") as PersonRelationship)} placeholder="Relationship" placeholderTextColor="#8A877F" style={styles.input} /><TextInput value={personNextContact} onChangeText={setPersonNextContact} placeholder="Next contact: YYYY-MM-DD" placeholderTextColor="#8A877F" style={styles.input} /><TextInput value={personNotes} onChangeText={setPersonNotes} placeholder="Private notes" placeholderTextColor="#8A877F" style={[styles.input, styles.multilineInput]} multiline /><Pressable onPress={() => void savePerson()} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">Save person</Text></Pressable>{people.length === 0 ? <Text className="mt-3 text-sm text-muted">No people saved yet.</Text> : people.map((person) => <View key={person.id} className="mt-3 flex-row items-center rounded-2xl border border-border px-3 py-3"><View className="flex-1"><Text className="text-sm font-semibold text-foreground">{person.name}</Text><Text className="mt-1 text-xs text-muted">{person.relationship} · Last contacted: {person.lastContacted ?? "not recorded"}{person.nextContact ? ` · Next: ${person.nextContact}` : ""}</Text>{person.notes ? <Text className="mt-1 text-xs text-muted" numberOfLines={1}>{person.notes}</Text> : null}</View><Pressable onPress={() => void deletePerson(person.id)} style={({ pressed }) => [styles.smallDelete, pressed && styles.faded]}><Text className="text-xs font-semibold text-error">Delete</Text></Pressable></View>)}<View className="mt-5 border-t border-border pt-4"><Text className="text-xs font-bold uppercase tracking-widest text-primary">Match calendar event</Text><Text className="mt-2 text-xs leading-5 text-muted">Paste an event title. Matching names receive the event date as Last contacted.</Text><TextInput value={eventText} onChangeText={setEventText} placeholder="Event title or meeting text" placeholderTextColor="#8A877F" style={styles.input} /><TextInput value={eventDate} onChangeText={setEventDate} placeholder="Event date: YYYY-MM-DD" placeholderTextColor="#8A877F" style={styles.input} /><View className="flex-row flex-wrap gap-2"><Pressable onPress={async () => { const matched = await markContactedFromEvent(eventText, eventDate); Alert.alert("Contact update", matched.length ? `${matched.length} contact(s) updated.` : "No saved name matched this event."); }} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">Update Last contacted</Text></Pressable><Pressable onPress={async () => { const captured = await captureCalendarEvent({ title: eventText, date: eventDate }); Alert.alert("Diary capture", captured ? "Calendar event saved privately." : "Enter an event title and date first."); }} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">Capture as diary</Text></Pressable></View></View></View>

            <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5"><View className="flex-row items-center justify-between"><View><Text className="text-xs font-bold uppercase tracking-widest text-primary">Weekly rollover</Text><Text className="mt-2 text-base font-bold text-foreground">Automatic lifecycle review</Text></View><Pressable onPress={() => void runWeeklyRollover()} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">Run now</Text></Pressable></View><Text className="mt-2 text-xs leading-5 text-muted">Runs when the app opens. Completed items move to the monthly archive. Open items roll forward. Items reaching two rollovers escalate.</Text>{rolloverSummary ? <Text className="mt-3 text-xs font-semibold text-primary">Last review: {rolloverSummary.completedArchived} archived · {rolloverSummary.weeklyRolled} rolled · {rolloverSummary.escalated} escalated</Text> : null}</View>

            {archivedPlans.length > 0 ? <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-xs font-bold uppercase tracking-widest text-primary">Completed archive</Text><Text className="mt-2 text-sm leading-5 text-muted">Historical completed work remains stored by month.</Text>{archivedPlans.map((item) => <View key={item.id} className="mt-3 rounded-2xl border border-border px-3 py-3"><Text className="text-sm font-semibold text-foreground">{item.title}</Text><Text className="mt-1 text-xs text-muted">{typeLabel(item.type)} · {item.archivedAt?.slice(0, 7) ?? "Archive"}</Text></View>)}</View> : null}

            <View className="mt-6 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("weeklyAudit")}</Text><Text className="mt-2 text-base font-bold text-foreground">{t("auditHelp")}</Text><Text className="mt-2 text-xs leading-5 text-muted">Google Calendar is not connected yet. Calendar events are not imported into local planning.</Text><View className="mt-4 flex-row flex-wrap gap-2"><Pressable onPress={() => copyPrompt(WEEKLY_AUDIT_PROMPT)} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("copyPrompt")}</Text></Pressable></View></View>
            <View className="mt-4 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("orchestration")}</Text><Text className="mt-2 text-base font-bold text-foreground">{t("orchestrationHelp")}</Text><Text className="mt-2 text-xs leading-5 text-muted">Use this prompt with the dashboard when reviewing calendar and CRM information.</Text><Pressable onPress={() => copyPrompt(MASTER_ORCHESTRATION_PROMPT)} style={({ pressed }) => [styles.promptButton, pressed && styles.pressed]}><Text className="text-xs font-bold text-primary">{t("copyPrompt")}</Text></Pressable></View>

            {visiblePlans.length > 0 ? <View className="mt-5"><Text className="mb-2 text-base font-bold text-foreground">{t("upcomingWork")}</Text>{visiblePlans.map((item) => <PlanningRow key={item.id} item={item} label={typeLabel(item.type)} onToggle={() => updateItem(item.id, { completed: !item.completed })} onDelete={() => deleteItem(item.id)} />)}</View> : <View className="mt-5 rounded-2xl border border-dashed border-border px-4 py-4"><Text className="text-sm text-muted">{t("noPlans")}</Text></View>}

            {habits.length > 0 ? <View className="mt-6"><Text className="mb-2 text-base font-bold text-foreground">{t("habit")}</Text>{habits.map((habit) => <View key={habit.id} className="mb-2 flex-row items-center rounded-2xl border border-border bg-surface px-4 py-3"><Pressable onPress={() => toggleHabit(habit.id, today)} style={[styles.check, habit.completedDates.includes(today) && styles.checkDone]}><Text className="text-xs font-bold text-background">{habit.completedDates.includes(today) ? "✓" : ""}</Text></Pressable><View className="ml-3 flex-1"><Text className="text-sm font-semibold text-foreground">{habit.title}</Text>{habit.note ? <Text className="mt-1 text-xs text-muted" numberOfLines={1}>{habit.note}</Text> : null}</View><Pressable onPress={() => deleteHabit(habit.id)} style={({ pressed }) => [styles.smallDelete, pressed && styles.faded]}><Text className="text-xs font-semibold text-error">{t("deleteItem")}</Text></Pressable></View>)}</View> : null}
            <Text className="mb-1 mt-8 text-xl font-bold text-foreground">{t("checkIns")}</Text>
          </View>
        }
        renderItem={({ item }) => <View className="mt-3 rounded-2xl border border-border bg-surface p-4"><Text className="text-sm font-semibold text-foreground">{formatDay(item.day)}</Text>{item.items.map(({ story, checkIn }) => <Pressable key={checkIn.id} onLongPress={() => removeStoryEntry(story)} style={({ pressed }) => [styles.row, pressed && styles.pressed]}><View className="flex-1"><Text className="text-base font-semibold text-foreground">{emotionLabel(checkIn.emotion)}</Text><Text className="mt-1 text-sm text-muted" numberOfLines={1}>{story.title}</Text></View><View className="items-end"><Text className="text-base font-bold text-primary">{checkIn.intensity}/5</Text><Text className="mt-1 text-xs text-muted">intensity</Text><Text className="mt-1 text-xs font-semibold text-primary">Hold to delete this entry</Text></View></Pressable>)}</View>}
        ListEmptyComponent={<View className="mt-3 rounded-3xl border border-dashed border-border px-6 py-8"><Text className="text-center text-lg font-semibold text-foreground">{t("noCheckIns")}</Text><Text className="mt-2 text-center text-sm leading-5 text-muted">{t("completeReflection")}</Text></View>}
      />

      <Modal visible={Boolean(composer)} transparent animationType="slide" onRequestClose={() => setComposer(null)}><View className="flex-1 justify-end bg-black/35"><View className="rounded-t-3xl bg-background px-5 pb-8 pt-5"><View className="flex-row items-center justify-between"><Text className="text-xl font-bold text-foreground">{composer === "habit" ? t("addHabit") : composer ? typeLabel(composer) : t("planning")}</Text><Pressable onPress={() => setComposer(null)} style={({ pressed }) => [styles.closeButton, pressed && styles.faded]}><Text className="text-lg text-foreground">×</Text></Pressable></View><TextInput value={title} onChangeText={setTitle} placeholder={t("titlePlaceholder")} placeholderTextColor="#9A9E98" className="mt-5 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={note} onChangeText={setNote} placeholder={t("notePlaceholder")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[88px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" />{composer !== "habit" ? <TextInput value={date} onChangeText={setDate} placeholder={t("datePlaceholder")} placeholderTextColor="#9A9E98" className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /> : null}<Pressable onPress={saveComposer} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{composer === "habit" ? t("saveHabit") : t("saveItem")}</Text></Pressable></View></View></Modal>
    </ScreenContainer>
  );
}

function ExecutiveCalendarPanel() {
  const { t } = useLanguage();
  const { habits, tasks, certItems, toggleHabitDate, updateTask, toggleCertDate } = useExecutiveDashboard();
  const { trainings } = useOperational();
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [monthCursor, setMonthCursor] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const active = activeHabits(habits).slice(0, 6);
  const days = monthDays(monthCursor.getFullYear(), monthCursor.getMonth());
  const leading = Array.from({ length: new Date(monthCursor.getFullYear(), monthCursor.getMonth(), 1).getDay() }, () => "");
  const grid = [...leading, ...days];
  const selectedTasks = tasks.filter((task) => task.date === selectedDate);
  const selectedCert = certItems.filter((item) => selectedDate >= item.startDate && selectedDate <= item.endDate);
  const selectedTraining = trainings.filter((training) => training.date === selectedDate);
  const today = new Date().toISOString().slice(0, 10);
  const statusFor = (day: string): DotState => {
    if (!day) return "empty";
    const dayTasks = tasks.filter((task) => task.date === day);
    const dayCert = certItems.filter((item) => day >= item.startDate && day <= item.endDate);
    const hasData = dayTasks.length > 0 || dayCert.length > 0 || (active.length > 0 && day <= today);
    if (!hasData) return "empty";
    return dayTasks.every((task) => task.status === "done") && active.every((habit) => habit.completedDates.includes(day)) && dayCert.every((item) => item.loggedDates.includes(day)) ? "done" : "missed";
  };
  async function toggleDay(day: string) {
    if (!day) return;
    const shouldComplete = statusFor(day) !== "done";
    for (const task of tasks.filter((item) => item.date === day)) await updateTask(task.id, { status: shouldComplete ? "done" : "open" });
    for (const habit of active) if (habit.completedDates.includes(day) !== shouldComplete) await toggleHabitDate(habit.id, day);
    for (const item of certItems.filter((cert) => day >= cert.startDate && day <= cert.endDate)) if (item.loggedDates.includes(day) !== shouldComplete) await toggleCertDate(item.id, day);
  }
  return <View className="mt-7 rounded-3xl border border-border bg-surface px-4 py-5"><View className="flex-row items-center justify-between"><View><Text className="text-xs font-bold uppercase tracking-widest text-primary">Executive calendar</Text><Text className="mt-2 text-xl font-bold text-foreground">{monthTitle(monthCursor)}</Text></View><View className="flex-row gap-2"><Pressable accessibilityLabel={t("previousMonth")} onPress={() => setMonthCursor(new Date(monthCursor.getFullYear(), monthCursor.getMonth() - 1, 1))} style={styles.monthButton}><Text className="text-base font-bold text-primary">‹</Text></Pressable><Pressable accessibilityLabel={t("nextMonth")} onPress={() => setMonthCursor(new Date(monthCursor.getFullYear(), monthCursor.getMonth() + 1, 1))} style={styles.monthButton}><Text className="text-base font-bold text-primary">›</Text></Pressable></View></View><Text className="mt-2 text-xs leading-5 text-muted">Tap a date to inspect it. Tap its dot to mark the date done or not done.</Text><View className="mt-4 flex-row justify-between">{["S", "M", "T", "W", "T", "F", "S"].map((label, index) => <Text key={`${label}-${index}`} className="w-[13%] text-center text-[10px] font-bold text-muted">{label}</Text>)}</View><View className="mt-2 flex-row flex-wrap">{grid.map((day, index) => { const state = statusFor(day); return <Pressable key={`${day}-${index}`} disabled={!day} onPress={() => setSelectedDate(day)} style={[styles.dayCell, day === selectedDate && styles.dayCellSelected]}><Text className={`text-xs ${day === selectedDate ? "font-bold text-primary" : "text-foreground"}`}>{day ? Number(day.slice(-2)) : ""}</Text>{day && trainings.some((training) => training.date === day) ? <Text accessibilityLabel={`${dateLabel(day)} training pin`} className="text-[10px] font-bold text-primary">●</Text> : null}{day ? <Pressable accessibilityLabel={`${dateLabel(day)} ${state === "done" ? t("done") : state === "missed" ? t("notDone") : t("noDatePlans")}`} onPress={() => { setSelectedDate(day); void toggleDay(day); }} style={[styles.statusDot, state === "done" && styles.statusDone, state === "missed" && styles.statusMissed, state === "empty" && styles.statusEmpty]} /> : null}</Pressable>; })}</View><View className="mt-4 flex-row flex-wrap gap-3"><View className="flex-row items-center"><View style={[styles.legendDot, styles.trainingLegend]} /><Text className="ml-1 text-xs text-muted">Training</Text></View><View className="flex-row items-center"><View style={[styles.legendDot, styles.statusDone]} /><Text className="ml-1 text-xs text-muted">{t("done")}</Text></View><View className="flex-row items-center"><View style={[styles.legendDot, styles.statusMissed]} /><Text className="ml-1 text-xs text-muted">{t("notDone")}</Text></View><View className="flex-row items-center"><View style={[styles.legendDot, styles.statusEmpty]} /><Text className="ml-1 text-xs text-muted">·</Text></View></View><View className="mt-5 rounded-2xl border border-border bg-background px-4 py-4"><Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("selectDate")}</Text><Text className="mt-2 text-base font-bold text-foreground">{dateLabel(selectedDate)}</Text>{selectedTasks.length === 0 && selectedCert.length === 0 && selectedTraining.length === 0 ? <Text className="mt-2 text-sm text-muted">{t("noDatePlans")}</Text> : null}{selectedTraining.map((training) => <View key={training.id} className="mt-3 rounded-2xl border border-primary/30 bg-background px-3 py-3"><Text className="text-sm font-semibold text-foreground">Training</Text><Text className="mt-1 text-xs text-muted">{training.topic}</Text></View>)}{selectedTasks.map((task) => <View key={task.id} className="mt-3 flex-row items-center"><View style={[styles.miniStatus, task.status === "done" && styles.statusDone]} /><View className="ml-2 flex-1"><Text className="text-sm font-semibold text-foreground">{task.task}</Text><Text className="text-xs text-muted">{task.severity} · {task.status === "done" ? t("done") : taskNeedsEscalation(task) ? `[ESCALATED FROM WEEKLY]` : taskRolloverLabel(task)}</Text></View></View>)}{selectedCert.map((item) => <View key={item.id} className="mt-3"><Text className="text-sm font-semibold text-foreground">{item.item}</Text><Text className="text-xs text-muted">{compliancePercent(item.loggedDates, item.startDate, item.endDate)}% · {item.status}</Text></View>)}</View><View className="mt-5"><Text className="text-base font-bold text-foreground">Habit registry</Text>{active.length === 0 ? <Text className="mt-2 text-sm text-muted">No active habits in the registry.</Text> : active.map((habit) => <View key={habit.id} className="mt-3 flex-row items-center"><View style={[styles.miniStatus, habit.completedDates.includes(selectedDate) && styles.statusDone]} /><View className="ml-2 flex-1"><Text className="text-sm font-semibold text-foreground">{habit.icon} {habit.name}</Text><Text className="text-xs text-muted">{habit.frequency} · {habit.status} · {habitCompletion(habit, monthCursor.getFullYear(), monthCursor.getMonth())}% this month</Text></View></View>)}</View><View className="mt-5"><Text className="text-base font-bold text-foreground">Cert-prep registry</Text>{certItems.length === 0 ? <Text className="mt-2 text-sm text-muted">No cert-prep items in the registry.</Text> : certItems.map((item) => <View key={item.id} className="mt-3 rounded-2xl border border-border px-3 py-3"><Text className="text-sm font-semibold text-foreground">{item.item}</Text><Text className="mt-1 text-xs text-muted">{item.startDate} → {item.endDate} · {compliancePercent(item.loggedDates, item.startDate, item.endDate)}% · {item.status}</Text></View>)}</View></View>;
}

function PlanningRow({ item, label, onToggle, onDelete }: { item: PlanningItem; label: string; onToggle: () => void; onDelete: () => void }) {
  return <View className="mb-2 flex-row items-center rounded-2xl border border-border bg-surface px-4 py-3"><Pressable onPress={onToggle} style={[styles.check, item.completed && styles.checkDone]}><Text className="text-xs font-bold text-background">{item.completed ? "✓" : ""}</Text></Pressable><View className="ml-3 flex-1"><Text className="text-[10px] font-bold uppercase tracking-widest text-primary">{label}</Text><Text className={`mt-1 text-sm font-semibold ${item.completed ? "text-muted line-through" : "text-foreground"}`}>{item.title}</Text>{item.note ? <Text className="mt-1 text-xs text-muted" numberOfLines={1}>{item.note}</Text> : null}<Text className="mt-1 text-xs text-muted">{item.date}</Text></View><Pressable onPress={onDelete} style={({ pressed }) => [styles.smallDelete, pressed && styles.faded]}><Text className="text-xs font-semibold text-error">{item.completed ? "" : "×"}</Text></Pressable></View>;
}

const styles = StyleSheet.create({
  content: { paddingTop: 12, paddingBottom: 36 },
  row: { alignItems: "center", borderTopColor: "#E5DED2", borderTopWidth: 1, flexDirection: "row", marginTop: 12, paddingTop: 12 },
  planChip: { backgroundColor: "#E8EFE9", borderColor: "#C7D8CA", borderRadius: 16, borderWidth: 1, paddingHorizontal: 11, paddingVertical: 9 },
  promptButton: { alignSelf: "flex-start", backgroundColor: "#E8EFE9", borderColor: "#C7D8CA", borderRadius: 14, borderWidth: 1, marginTop: 12, paddingHorizontal: 12, paddingVertical: 10 },
  input: { backgroundColor: "#FBF9F4", borderColor: "#E5DED2", borderRadius: 12, borderWidth: 1, color: "#1B2A24", fontSize: 14, marginTop: 8, paddingHorizontal: 12, paddingVertical: 11 },
  multilineInput: { minHeight: 72, textAlignVertical: "top" },
  monthButton: { alignItems: "center", borderColor: "#C7D8CA", borderRadius: 14, borderWidth: 1, height: 34, justifyContent: "center", width: 34 },
  dayCell: { alignItems: "center", borderRadius: 12, marginBottom: 4, marginHorizontal: "0.7%", minHeight: 45, paddingTop: 6, width: "12.8%" },
  dayCellSelected: { backgroundColor: "#E8EFE9" },
  statusDot: { borderRadius: 6, height: 10, marginTop: 5, width: 10 },
  legendDot: { borderRadius: 5, height: 10, width: 10 },
  miniStatus: { backgroundColor: "#E0DDD4", borderRadius: 6, height: 12, width: 12 },
  statusDone: { backgroundColor: "#587A5A" },
  statusMissed: { backgroundColor: "#B56A38" },
  trainingLegend: { backgroundColor: "#B56A38" }, statusEmpty: { backgroundColor: "#D5D0C6" },
  check: { alignItems: "center", backgroundColor: "#C7D8CA", borderRadius: 12, height: 24, justifyContent: "center", width: 24 },
  checkDone: { backgroundColor: "#587A5A" },
  smallDelete: { paddingHorizontal: 6, paddingVertical: 8 },
  closeButton: { alignItems: "center", borderColor: "#E5DED2", borderRadius: 18, borderWidth: 1, height: 36, justifyContent: "center", width: 36 },
  saveButton: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 16, marginTop: 15, paddingVertical: 15 },
  pressed: { opacity: 0.75 },
  faded: { opacity: 0.55 },
  softText: { opacity: 0.72 },
});
