import { useState } from "react";
import { Pressable, StyleSheet, Text, View, useWindowDimensions } from "react-native";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { LANGUAGES, useLanguage } from "@/lib/language-context";

function GlobalLanguageSwitcher() {
  const colors = useColors();
  const { language, setLanguage } = useLanguage();
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState(false);
  const active = LANGUAGES.find((item) => item.key === language) ?? LANGUAGES[0];

  return (
    <View style={[styles.switcher, { top: Math.max(insets.top, 8) + 6 }]} pointerEvents="box-none">
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Change language"
        accessibilityState={{ expanded: open }}
        onPress={() => setOpen((value) => !value)}
        style={({ pressed }) => [styles.languageButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
      >
        <Text style={[styles.languageCode, { color: colors.primary }]}>{active.key.toUpperCase()}</Text>
        <Text style={[styles.languageName, { color: colors.foreground }]}>{active.native}</Text>
        <IconSymbol name="chevron.down" size={14} color={colors.muted} />
      </Pressable>
      {open ? (
        <View style={[styles.menu, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {LANGUAGES.map((item) => (
            <Pressable
              key={item.key}
              accessibilityRole="menuitem"
              onPress={async () => { await setLanguage(item.key); setOpen(false); }}
              style={({ pressed }) => [styles.menuItem, language === item.key && { backgroundColor: colors.primary }, pressed && styles.pressed]}
            >
              <Text style={[styles.menuNative, { color: language === item.key ? colors.background : colors.foreground }]}>{item.native}</Text>
              <Text style={[styles.menuLabel, { color: language === item.key ? colors.background : colors.muted }]}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
}

export default function TabLayout() {
  const colors = useColors();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const compactNav = width < 520;
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);

  return (
    <View style={styles.root}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.muted,
          tabBarButton: HapticTab,
          tabBarStyle: {
            height: 58 + bottomPadding,
            paddingTop: 7,
            paddingBottom: bottomPadding,
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            borderTopWidth: 0.5,
          },
          tabBarLabelStyle: { fontSize: compactNav ? 9 : 11, fontWeight: "600" },
        }}
      >
        <Tabs.Screen name="index" options={{ title: compactNav ? "Home" : t("home"), tabBarIcon: ({ color }) => <IconSymbol name="house.fill" size={23} color={color} /> }} />
        <Tabs.Screen name="stories" options={{ title: compactNav ? "Log" : t("stories"), tabBarIcon: ({ color }) => <IconSymbol name="book.closed.fill" size={23} color={color} /> }} />
        <Tabs.Screen name="learn" options={{ title: compactNav ? "Learn" : t("learn"), tabBarIcon: ({ color }) => <IconSymbol name="book" size={23} color={color} /> }} />
        <Tabs.Screen name="calendar" options={{ title: compactNav ? "Days" : t("calendar"), tabBarIcon: ({ color }) => <IconSymbol name="calendar" size={23} color={color} /> }} />
        <Tabs.Screen name="people" options={{ title: compactNav ? "People" : "People", tabBarIcon: ({ color }) => <IconSymbol name="people.fill" size={23} color={color} /> }} />
        <Tabs.Screen name="boxes" options={{ title: compactNav ? "Rooms" : t("boxes"), tabBarIcon: ({ color }) => <IconSymbol name="square.grid.2x2.fill" size={23} color={color} /> }} />
        <Tabs.Screen name="practice" options={{ title: compactNav ? "Do" : t("practice"), tabBarIcon: ({ color }) => <IconSymbol name="leaf.fill" size={23} color={color} /> }} />
        <Tabs.Screen name="settings" options={{ title: compactNav ? "More" : t("settings"), tabBarIcon: ({ color }) => <IconSymbol name="gearshape.fill" size={23} color={color} /> }} />
      </Tabs>
      <GlobalLanguageSwitcher />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  switcher: { position: "absolute", right: 12, zIndex: 20 },
  languageButton: { alignItems: "center", borderRadius: 18, borderWidth: 1, flexDirection: "row", gap: 6, minHeight: 36, paddingHorizontal: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 5, elevation: 3 },
  languageCode: { fontSize: 11, fontWeight: "800", letterSpacing: 0.6 },
  languageName: { fontSize: 12, fontWeight: "700", maxWidth: 70 },
  menu: { borderRadius: 16, borderWidth: 1, marginTop: 6, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 8, elevation: 5, minWidth: 150 },
  menuItem: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12, paddingVertical: 11 },
  menuNative: { fontSize: 14, fontWeight: "700" },
  menuLabel: { fontSize: 11, marginLeft: 10 },
  pressed: { opacity: 0.65 },
});
