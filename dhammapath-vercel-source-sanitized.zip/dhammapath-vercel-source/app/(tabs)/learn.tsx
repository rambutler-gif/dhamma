import { useState } from "react";
import { useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useLanguage } from "@/lib/language-context";

const terms = [
  { pali: "sati", english: "mindfulness", tamil: "நினைவுணர்வு", note: "Remembering to attend carefully to the present experience." },
  { pali: "mettā", english: "loving-kindness", tamil: "மைத்திரி", note: "A non-harming wish for welfare, without possession." },
  { pali: "anicca", english: "impermanence", tamil: "நிலையாமை", note: "All conditioned experiences arise and pass away." },
  { pali: "sammā-diṭṭhi", english: "right view", tamil: "சம்மா தித்தி", note: "Seeing experience through causes, conditions, and consequences." },
];

export default function LearnScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const [query, setQuery] = useState("");
  const filtered = terms.filter((term) => `${term.pali} ${term.english} ${term.tamil}`.toLowerCase().includes(query.toLowerCase()));

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <Text className="text-sm font-semibold tracking-widest text-primary">{t("appName").toUpperCase()}</Text>
        <Text className="mt-1 text-3xl font-bold text-foreground">{t("learn")}</Text>
        <Text className="mt-2 text-sm leading-5 text-muted">{t("learnIntro")}</Text>

        <View className="mt-6 rounded-3xl border border-border bg-surface px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("paliSearch")}</Text>
          <View className="mt-4 flex-row flex-wrap gap-2">
            {terms.map((term) => (
              <Pressable key={term.pali} onPress={() => setQuery(term.pali)} style={({ pressed }) => [styles.termChip, pressed && styles.pressed]}>
                <Text className="text-sm font-semibold text-foreground">{term.pali}</Text>
              </Pressable>
            ))}
          </View>
          <Text className="mt-4 text-sm text-muted">{t("termCount")} {filtered.length}</Text>
          {filtered.map((term) => (
            <View key={term.pali} className="mt-4 border-t border-border pt-4">
              <Text className="text-xl font-bold text-foreground">{term.pali}</Text>
              <Text className="mt-1 text-base font-semibold text-primary">{term.english}</Text>
              <Text className="mt-1 text-base text-foreground">{term.tamil}</Text>
              <Text className="mt-2 text-sm leading-5 text-muted">{term.note}</Text>
            </View>
          ))}
        </View>

        <View className="mt-5 rounded-3xl bg-foreground px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("todayVerse")}</Text>
          <Text className="mt-4 text-lg font-semibold leading-7 text-background">Manopubbaṅgamā dhammā, manoseṭṭhā manomayā.</Text>
          <Text className="mt-3 text-xl font-semibold leading-7 text-background">{t("verseMeaning")}</Text>
          <Text className="mt-3 text-sm leading-5 text-background" style={styles.softText}>{t("verseReflection")}</Text>
          <Text className="mt-3 text-sm leading-5 text-background" style={styles.softText}>{t("verseTamil")}</Text>
          <Text className="mt-3 text-xs leading-5 text-background" style={styles.softText}>Source: Dhammapada 1–2. Translation: Acharya Buddharakkhita.</Text>
        </View>

        <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("reflectionPractice")}</Text>
          <Text className="mt-3 text-xl font-bold text-foreground">{t("reflectionPracticeTitle")}</Text>
          <Text className="mt-2 text-sm leading-5 text-muted">{t("reflectionPracticeDescription")}</Text>
          <Text className="mt-2 text-xs leading-5 text-muted">{t("reflectionPracticeSource")}</Text>
          <Pressable onPress={() => router.push("/(tabs)/practice")} style={({ pressed }) => [styles.readButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{t("openPractice")}</Text></Pressable>
        </View>

        <View className="mt-5 rounded-3xl border border-border bg-surface px-5 py-5">
          <Text className="text-xs font-bold uppercase tracking-widest text-primary">{t("mindMaps")}</Text>
          <Pressable onPress={() => router.push({ pathname: "/learn/[kind]", params: { kind: "sutta" } })} style={({ pressed }) => [styles.mapCard, pressed && styles.pressed]}>
            <Text className="text-base font-semibold text-foreground">{t("sutta")}</Text>
            <Text className="mt-1 text-sm leading-5 text-muted">{t("suttaDetail")}</Text>
            <Text className="mt-2 text-xs font-semibold text-primary">{t("openMap")}</Text>
          </Pressable>
          <Pressable onPress={() => router.push({ pathname: "/learn/[kind]", params: { kind: "vinaya" } })} style={({ pressed }) => [styles.mapCard, pressed && styles.pressed]}>
            <Text className="text-base font-semibold text-foreground">{t("vinaya")}</Text>
            <Text className="mt-1 text-sm leading-5 text-muted">{t("vinayaDetail")}</Text>
            <Text className="mt-2 text-xs font-semibold text-primary">{t("openMap")}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 12, paddingBottom: 36 },
  termChip: { backgroundColor: "#DCE7DF", borderRadius: 18, paddingHorizontal: 12, paddingVertical: 8 },
  mapCard: { backgroundColor: "#F7F4EE", borderColor: "#E5DED2", borderRadius: 18, borderWidth: 1, marginTop: 14, padding: 14 },
  readButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 16, marginTop: 16, paddingVertical: 13 },
  pressed: { opacity: 0.62 },
  softText: { opacity: 0.72 },
});
