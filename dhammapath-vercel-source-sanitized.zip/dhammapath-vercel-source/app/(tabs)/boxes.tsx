import { useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { EMPTY_ME_PROFILE, usePrivateSpace } from "@/lib/private-space";
import type { MeProfile, ThoughtBox } from "@/lib/types";
import { useLanguage } from "@/lib/language-context";

export default function BoxesScreen() {
  const router = useRouter();
  const { boxes, meProfile, hasPassword, updateBox, updateMeProfile, deleteBox, addBox, verifyPassword } = usePrivateSpace();
  const { t } = useLanguage();
  const [editing, setEditing] = useState<ThoughtBox | null>(null);
  const [draftName, setDraftName] = useState("");
  const [draftScript, setDraftScript] = useState("");
  const [masterPassword, setMasterPassword] = useState("");
  const [deleting, setDeleting] = useState<ThoughtBox | null>(null);
  const [deletePassword, setDeletePassword] = useState("");
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newPrompt, setNewPrompt] = useState("");
  const [newScript, setNewScript] = useState("");
  const [profileEditing, setProfileEditing] = useState(false);
  const [profileDraft, setProfileDraft] = useState<MeProfile>(EMPTY_ME_PROFILE);
  const [profilePassword, setProfilePassword] = useState("");
  const [profileSaved, setProfileSaved] = useState(false);

  function openEditor(box: ThoughtBox) {
    setEditing(box);
    setDraftName(box.name);
    setDraftScript(box.script);
    setMasterPassword("");
  }

  function openProfile() {
    setProfileDraft(meProfile);
    setProfilePassword("");
    setProfileSaved(false);
    setProfileEditing(true);
  }

  function updateProfileField(field: keyof MeProfile, value: string) {
    setProfileDraft((current) => ({ ...current, [field]: value }));
  }

  async function saveProfile() {
    if (!hasPassword) {
      Alert.alert("Set your master password first", "Open Settings and create your master password before saving your Me profile.");
      return;
    }
    if (!(await verifyPassword(profilePassword))) {
      Alert.alert("Password required", "Your Me profile was not changed.");
      return;
    }
    await updateMeProfile(Object.fromEntries(Object.entries(profileDraft).map(([key, value]) => [key, value.trim()])) as MeProfile);
    setProfileSaved(true);
    setProfilePassword("");
  }

  async function saveScript() {
    if (!editing) return;
    if (!hasPassword) {
      Alert.alert("Set your master password first", "Open Settings and create your master password before changing a script.");
      return;
    }
    if (!(await verifyPassword(masterPassword))) {
      Alert.alert("Password required", "The script was not changed.");
      return;
    }
    const nextName = draftName.trim();
    if (!nextName) {
      Alert.alert("Room name required", "Add a name before saving.");
      return;
    }
    await updateBox(editing.id, { name: nextName, script: draftScript.trim() });
    setEditing(null);
  }

  function requestDelete(box: ThoughtBox) {
    Alert.alert("Delete this script box?", "This action removes the box from your private space.", [
      { text: "Cancel", style: "cancel" },
      { text: "Continue", style: "destructive", onPress: () => { setDeleting(box); setDeletePassword(""); } },
    ]);
  }

  async function deleteProtectedBox() {
    if (!deleting) return;
    if (!(await verifyPassword(deletePassword))) { Alert.alert("Password required", "The box was not deleted."); return; }
    await deleteBox(deleting.id);
    setDeleting(null);
    setDeletePassword("");
  }

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View className="flex-row items-end justify-between pt-2"><View><Text className="text-sm font-semibold tracking-widest text-primary">PRIVATE SPACE</Text><Text className="mt-1 text-3xl font-bold text-foreground">{t("boxes")}</Text></View><View className="h-11 w-11 items-center justify-center rounded-full bg-foreground"><IconSymbol name="lock.fill" size={19} color="#F7F4EE" /></View></View>
        <Text className="mt-3 text-base leading-6 text-muted">Choose a Room. Its master script guides the reflection.</Text>
        <View className="mt-4 rounded-2xl border border-primary/20 bg-primary/5 px-4 py-4"><Text className="text-sm font-bold text-foreground">Me is the central office.</Text><Text className="mt-1 text-sm leading-5 text-muted">Every Room connects here. Work, family, friends, and projects stay distinct, while each reflection can consider the wider pattern.</Text><Pressable onPress={openProfile} style={({ pressed }) => [styles.profileButton, pressed && styles.faded]}><Text className="text-sm font-bold text-primary">{t("meProfile")}</Text></Pressable></View>
        <Pressable onPress={() => { setCreating(true); setNewName(""); setNewDescription(""); setNewPrompt(""); setNewScript(""); }} style={({ pressed }) => [styles.addRoomButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{t("createRoom")}</Text></Pressable>
        {!hasPassword ? <View className="mt-5 rounded-2xl border border-warning/30 bg-warning/10 px-4 py-3"><Text className="text-sm leading-5 text-foreground">Set a master password in Settings. Script changes and box deletion need it.</Text></View> : null}
        <View className="mt-7 gap-3">
          {boxes.map((box) => <View key={box.id} className="rounded-3xl border border-border bg-surface px-5 py-5"><View className="flex-row items-start"><View className="h-10 w-10 items-center justify-center rounded-full" style={{ backgroundColor: `${box.accent}20` }}><IconSymbol name="book.closed.fill" size={20} color={box.accent} /></View><View className="ml-3 flex-1"><Text className="text-lg font-bold text-foreground">{box.name}</Text><Text className="mt-1 text-sm leading-5 text-muted">{box.description}</Text></View></View><Text className="mt-4 text-sm italic leading-5 text-foreground">“{box.prompt}”</Text><View className="mt-4 flex-row gap-2"><Pressable onPress={() => router.push({ pathname: "/story/new", params: { boxId: box.id } })} style={({ pressed }) => [styles.reflectButton, pressed && styles.pressed]}><IconSymbol name="sparkles" size={16} color="#F7F4EE" /><Text className="ml-2 text-xs font-bold text-background">Open box</Text></Pressable><Pressable onPress={() => openEditor(box)} style={({ pressed }) => [styles.editButton, pressed && styles.faded]}><Text className="text-xs font-bold text-foreground">Edit script</Text></Pressable>{box.id !== "me" ? <Pressable onPress={() => requestDelete(box)} style={({ pressed }) => [styles.deleteButton, pressed && styles.faded]}><IconSymbol name="trash" size={16} color="#B04A43" /></Pressable> : null}</View></View>)}
        </View>
        <Text className="mt-7 text-center text-xs leading-5 text-muted">Each box keeps a different part of life in view.</Text>
      </ScrollView>

      <Modal visible={creating} transparent animationType="slide" onRequestClose={() => setCreating(false)}>
        <View className="flex-1 justify-end bg-black/35"><View className="rounded-t-3xl bg-background px-5 pb-8 pt-5"><View className="flex-row items-center justify-between"><Text className="text-xl font-bold text-foreground">{t("createRoom")}</Text><Pressable onPress={() => setCreating(false)} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}><IconSymbol name="xmark" size={18} color="#1B2A25" /></Pressable></View><Text className="mt-2 text-sm leading-5 text-muted">Give one area of life its own clear context.</Text><TextInput value={newName} onChangeText={setNewName} placeholder={t("roomName")} placeholderTextColor="#9A9E98" className="mt-5 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={newDescription} onChangeText={setNewDescription} placeholder={t("description")} placeholderTextColor="#9A9E98" className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={newPrompt} onChangeText={setNewPrompt} placeholder={t("reflectionPrompt")} placeholderTextColor="#9A9E98" className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={newScript} onChangeText={setNewScript} placeholder={t("masterScript")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[90px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><Pressable onPress={async () => { if (!newName.trim()) { Alert.alert("Room name required", "Add a name before saving."); return; } await addBox({ name: newName.trim(), description: newDescription.trim() || "A private area for reflection.", prompt: newPrompt.trim() || "What is important to see clearly here?", script: newScript.trim() || "Look at intention, causes, conditions, and consequences without blame." }); setCreating(false); }} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{t("saveRoom")}</Text></Pressable></View></View>
      </Modal>

      <Modal visible={profileEditing} transparent animationType="slide" onRequestClose={() => setProfileEditing(false)}>
        <View className="flex-1 justify-end bg-black/35"><View className="max-h-[92%] rounded-t-3xl bg-background px-5 pb-8 pt-5"><View className="flex-row items-center justify-between"><Text className="text-xl font-bold text-foreground">{t("meProfile")}</Text><Pressable onPress={() => setProfileEditing(false)} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}><IconSymbol name="xmark" size={18} color="#1B2A25" /></Pressable></View><Text className="mt-2 text-sm leading-5 text-muted">{t("meProfileIntro")}</Text><ScrollView keyboardShouldPersistTaps="handled"><TextInput value={profileDraft.name} onChangeText={(value) => updateProfileField("name", value)} placeholder={t("yourName")} placeholderTextColor="#9A9E98" className="mt-5 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={profileDraft.lifeStage} onChangeText={(value) => updateProfileField("lifeStage", value)} placeholder={t("lifeStage")} placeholderTextColor="#9A9E98" className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={profileDraft.importantPeople} onChangeText={(value) => updateProfileField("importantPeople", value)} placeholder={t("importantPeople")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[72px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><TextInput value={profileDraft.values} onChangeText={(value) => updateProfileField("values", value)} placeholder={t("values")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[72px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><TextInput value={profileDraft.responsibilities} onChangeText={(value) => updateProfileField("responsibilities", value)} placeholder={t("responsibilities")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[72px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><TextInput value={profileDraft.guidancePreference} onChangeText={(value) => updateProfileField("guidancePreference", value)} placeholder={t("guidancePreference")} placeholderTextColor="#9A9E98" multiline className="mt-3 min-h-[72px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><TextInput value={profilePassword} onChangeText={setProfilePassword} placeholder={t("masterScript")} placeholderTextColor="#9A9E98" secureTextEntry className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><Text className="mt-3 text-xs leading-5 text-muted">{t("profilePrivacy")}</Text><Pressable onPress={saveProfile} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">{profileSaved ? t("profileSaved") : t("saveProfile")}</Text></Pressable></ScrollView></View></View>
      </Modal>

      <Modal visible={Boolean(editing)} transparent animationType="slide" onRequestClose={() => setEditing(null)}>
        <View className="flex-1 justify-end bg-black/35"><View className="rounded-t-3xl bg-background px-5 pb-8 pt-5"><View className="flex-row items-center justify-between"><Text className="text-xl font-bold text-foreground">Edit master script</Text><Pressable onPress={() => setEditing(null)} style={({ pressed }) => [styles.iconButton, pressed && styles.faded]}><IconSymbol name="xmark" size={18} color="#1B2A25" /></Pressable></View><Text className="mt-2 text-sm leading-5 text-muted">This script shapes questions and advice for this box.</Text><TextInput value={draftName} onChangeText={setDraftName} placeholder={t("roomName")} placeholderTextColor="#9A9E98" className="mt-5 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><TextInput value={draftScript} onChangeText={setDraftScript} multiline textAlignVertical="top" className="mt-5 min-h-[145px] rounded-2xl border border-border bg-surface px-4 py-4 text-base leading-6 text-foreground" /><TextInput value={masterPassword} onChangeText={setMasterPassword} placeholder="Master password" placeholderTextColor="#9A9E98" secureTextEntry className="mt-3 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><Pressable onPress={saveScript} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">Save protected script</Text></Pressable></View></View>
      </Modal>

      <Modal visible={Boolean(deleting)} transparent animationType="fade" onRequestClose={() => setDeleting(null)}><View className="flex-1 items-center justify-center bg-black/35 px-5"><View className="w-full rounded-3xl bg-background px-5 py-5"><Text className="text-xl font-bold text-foreground">Delete script box?</Text><Text className="mt-2 text-sm leading-5 text-muted">Enter your master password to remove {deleting?.name}.</Text><TextInput value={deletePassword} onChangeText={setDeletePassword} placeholder="Master password" placeholderTextColor="#9A9E98" secureTextEntry className="mt-5 rounded-2xl border border-border bg-surface px-4 py-4 text-base text-foreground" /><View className="mt-4 flex-row justify-end gap-3"><Pressable onPress={() => setDeleting(null)} style={({ pressed }) => [styles.editButton, pressed && styles.faded]}><Text className="text-sm font-bold text-foreground">Cancel</Text></Pressable><Pressable onPress={deleteProtectedBox} style={({ pressed }) => [styles.deleteConfirmButton, pressed && styles.pressed]}><Text className="text-sm font-bold text-background">Delete box</Text></Pressable></View></View></View></Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 38 },
  addRoomButton: { alignItems: "center", backgroundColor: "#C8753D", borderRadius: 16, marginTop: 16, paddingVertical: 14 },
  reflectButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 14, flexDirection: "row", paddingHorizontal: 12, paddingVertical: 11 },
  editButton: { alignItems: "center", borderColor: "#E5DED2", borderRadius: 14, borderWidth: 1, justifyContent: "center", paddingHorizontal: 12, paddingVertical: 11 },
  deleteButton: { alignItems: "center", justifyContent: "center", paddingHorizontal: 9 },
  iconButton: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 18, borderWidth: 1, height: 36, justifyContent: "center", width: 36 },
  deleteConfirmButton: { alignItems: "center", backgroundColor: "#B04A43", borderRadius: 14, justifyContent: "center", paddingHorizontal: 15, paddingVertical: 11 },
  saveButton: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 16, marginTop: 15, paddingVertical: 15 },
  profileButton: { alignSelf: "flex-start", marginTop: 13, paddingVertical: 4 },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  faded: { opacity: 0.6 },
});
