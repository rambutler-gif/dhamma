import { useRouter } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useStories } from "@/lib/stories-context";
import { useLanguage } from "@/lib/language-context";
import { FEELINGS, type Story } from "@/lib/types";

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short" }).format(new Date(value));
}

function feelingLabel(key: Story["feeling"]) {
  return FEELINGS.find((feeling) => feeling.key === key)?.label ?? "Feeling";
}

export default function HomeScreen() {
  const router = useRouter();
  const { stories, isLoaded } = useStories();
  const { t } = useLanguage();
  const recentStories = stories.slice(0, 3);

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <FlatList
        data={recentStories}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View>
            <View className="flex-row items-center justify-between pt-2">
              <View>
                <Text className="text-sm font-semibold tracking-widest text-primary">{t("appName").toUpperCase()}</Text>
                <Text className="mt-1 text-3xl font-bold text-foreground">What is present?</Text>
              </View>
              <View className="h-11 w-11 items-center justify-center rounded-full bg-primary/10">
                <Text className="text-xl text-primary">◌</Text>
              </View>
            </View>

            <View className="mt-7 rounded-3xl bg-foreground px-5 py-6">
              <Text className="text-xs font-semibold uppercase tracking-widest text-primary">{t("todayReflection")}</Text>
              <Text className="mt-4 text-2xl font-semibold leading-8 text-background">
                {t("presentQuestion")}
              </Text>
              <Text className="mt-3 text-sm leading-5 text-background" style={styles.darkSupportingText}>
                {t("noPerformance")}
              </Text>
              <Pressable
                onPress={() => router.push("/story/new")}
                style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}
              >
                <Text className="text-sm font-bold text-background">{t("share")}</Text>
                <IconSymbol name="arrow.left" size={18} color="#F7F4EE" style={styles.rotateIcon} />
              </Pressable>
            </View>

            <View className="mt-4 flex-row items-center gap-2 rounded-2xl border border-border bg-surface px-4 py-3">
              <IconSymbol name="lock.fill" size={16} color="#587A5A" />
              <Text className="flex-1 text-xs leading-4 text-muted">{t("devicePrivate")}</Text>
            </View>

            <View className="mt-8 flex-row items-end justify-between">
              <View>
                <Text className="text-xl font-bold text-foreground">{t("yourStories")}</Text>
                <Text className="mt-1 text-sm text-muted">{t("tagline")}</Text>
              </View>
              {stories.length > 0 ? (
                <Pressable onPress={() => router.push("/(tabs)/stories")} style={({ pressed }) => pressed && styles.faded}>
                  <Text className="text-sm font-semibold text-primary">See all</Text>
                </Pressable>
              ) : null}
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => router.push({ pathname: "/story/[id]", params: { id: item.id } })}
            style={({ pressed }) => [styles.storyCard, pressed && styles.faded]}
          >
            <View className="flex-1 pr-3">
              <View className="flex-row items-center gap-2">
                <View className="h-2 w-2 rounded-full bg-primary" />
                <Text className="text-xs font-semibold uppercase tracking-wider text-primary">{feelingLabel(item.feeling)}</Text>
              </View>
              <Text className="mt-2 text-lg font-semibold text-foreground" numberOfLines={1}>{item.title}</Text>
              <Text className="mt-1 text-sm leading-5 text-muted" numberOfLines={2}>{item.content}</Text>
              <Text className="mt-3 text-xs font-medium text-muted">{formatDate(item.updatedAt)}</Text>
            </View>
            <IconSymbol name="chevron.right" size={21} color="#6C7770" />
          </Pressable>
        )}
        ListEmptyComponent={
          isLoaded ? (
            <View className="mt-6 rounded-3xl border border-dashed border-border px-6 py-8">
              <Text className="text-center text-lg font-semibold text-foreground">{t("firstStory")}</Text>
              <Text className="mt-2 text-center text-sm leading-5 text-muted">{t("unfinished")}</Text>
            </View>
          ) : null
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { paddingTop: 10, paddingBottom: 36 },
  primaryButton: {
    alignItems: "center",
    backgroundColor: "#B56A38",
    borderRadius: 18,
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 22,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  rotateIcon: { transform: [{ rotate: "180deg" }] },
  storyCard: {
    alignItems: "center",
    backgroundColor: "#FFFDF8",
    borderColor: "#E5DED2",
    borderRadius: 22,
    borderWidth: 1,
    flexDirection: "row",
    marginTop: 12,
    padding: 17,
  },
  pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
  faded: { opacity: 0.62 },
  darkSupportingText: { opacity: 0.72 },
});
