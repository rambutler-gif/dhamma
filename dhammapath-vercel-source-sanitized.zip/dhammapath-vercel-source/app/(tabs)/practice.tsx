import { useEffect, useState } from "react";
import { useRouter } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useLanguage } from "@/lib/language-context";
import { useStories } from "@/lib/stories-context";
import { clearAdvancedResponse, loadAdvancedResponses, saveAdvancedResponse } from "@/lib/advanced-reflection-storage";

type ExerciseId = "decision" | "boundary" | "attachment" | "repair";

type ExerciseText = {
  title: string;
  body: string;
  prompt: string;
  action: string;
};

const exerciseText: Record<string, { sectionTitle: string; sectionIntro: string; privacyNote: string; responseLabel: string; responsePlaceholder: string; saveResponse: string; clearResponse: string; savedResponse: string; open: string; close: string; exercises: Record<ExerciseId, ExerciseText> }> = {
  en: {
    sectionTitle: "Advanced reflection",
    sectionIntro: "For situations that need patience, honesty, and responsibility.",
    privacyNote: "This is a private exercise. It is not a score or diagnosis.",
    responseLabel: "Your private response",
    responsePlaceholder: "Write what you see, feel, or choose.",
    saveResponse: "Save response",
    clearResponse: "Clear response",
    savedResponse: "Response saved on this device.",
    open: "Open exercise",
    close: "Close exercise",
    exercises: {
      decision: { title: "A decision under pressure", body: "Separate what is known from what the mind predicts.", prompt: "What are the facts? What are you assuming? What intention will guide your choice? What consequence can you accept?", action: "Choose one clear step that reduces harm." },
      boundary: { title: "A boundary without hostility", body: "Protect what is yours without controlling another person.", prompt: "What belongs to you? What belongs to them? What clear sentence can you say without blame or threat?", action: "State one calm boundary. Then allow their response." },
      attachment: { title: "Attachment and uncertainty", body: "Meet longing without turning another person into an answer.", prompt: "What do you want? What are you afraid to feel? Which part is outside your control?", action: "Offer care without demanding possession." },
      repair: { title: "Repair after harm", body: "Turn remorse into responsibility, not self-punishment.", prompt: "What happened? Who was affected? What can you acknowledge? What repair is possible now?", action: "Make one specific amends, without demanding quick forgiveness." },
    },
  },
  hi: {
    sectionTitle: "उन्नत चिंतन",
    sectionIntro: "उन स्थितियों के लिए जिन्हें धैर्य, ईमानदारी और जिम्मेदारी चाहिए।",
    privacyNote: "यह निजी अभ्यास है। यह अंक या निदान नहीं है।",
    responseLabel: "आपका निजी उत्तर",
    responsePlaceholder: "जो आप देख रहे हैं, महसूस कर रहे हैं या चुन रहे हैं, उसे लिखें।",
    saveResponse: "उत्तर सुरक्षित करें",
    clearResponse: "उत्तर हटाएँ",
    savedResponse: "उत्तर इसी उपकरण पर सुरक्षित है।",
    open: "अभ्यास खोलें",
    close: "अभ्यास बंद करें",
    exercises: {
      decision: { title: "दबाव में निर्णय", body: "जो ज्ञात है, उसे मन की भविष्यवाणी से अलग करें।", prompt: "तथ्य क्या हैं? आप क्या मान रहे हैं? आपका निर्णय किस इरादे से चलेगा? कौन सा परिणाम आप स्वीकार कर सकते हैं?", action: "हानि घटाने वाला एक स्पष्ट कदम चुनें।" },
      boundary: { title: "बिना शत्रुता सीमा रखना", body: "दूसरे को नियंत्रित किए बिना अपनी रक्षा करें।", prompt: "आपकी जिम्मेदारी क्या है? उनकी जिम्मेदारी क्या है? बिना दोष या धमकी के कौन सा स्पष्ट वाक्य कह सकते हैं?", action: "एक शांत सीमा कहें। फिर उनकी प्रतिक्रिया को स्थान दें।" },
      attachment: { title: "आसक्ति और अनिश्चितता", body: "लालसा को देखें। दूसरे व्यक्ति को उत्तर न बनाएं।", prompt: "आप क्या चाहते हैं? आप किस भावना से डरते हैं? कौन सा भाग आपके नियंत्रण से बाहर है?", action: "स्वामित्व की मांग बिना देखभाल दें।" },
      repair: { title: "हानि के बाद सुधार", body: "पश्चाताप को जिम्मेदारी बनाएं। आत्म-दंड नहीं।", prompt: "क्या हुआ? किस पर प्रभाव पड़ा? आप क्या स्वीकार कर सकते हैं? अभी कौन सा सुधार संभव है?", action: "एक स्पष्ट सुधार करें। तुरंत क्षमा की मांग न करें।" },
    },
  },
  ta: {
    sectionTitle: "மேம்பட்ட சிந்தனை",
    sectionIntro: "பொறுமை, நேர்மை, பொறுப்பு தேவைப்படும் சூழல்களுக்கு.",
    privacyNote: "இது ஒரு தனிப்பட்ட பயிற்சி. இது மதிப்பெண்ணோ நோயறிதலோ அல்ல.",
    responseLabel: "உங்கள் தனிப்பட்ட பதில்",
    responsePlaceholder: "நீங்கள் காண்பது, உணர்வது அல்லது தேர்வு செய்வதை எழுதுங்கள்.",
    saveResponse: "பதிலைச் சேமிக்கவும்",
    clearResponse: "பதிலை அழிக்கவும்",
    savedResponse: "பதில் இந்த சாதனத்தில் சேமிக்கப்பட்டது.",
    open: "பயிற்சியைத் திறக்கவும்",
    close: "பயிற்சியை மூடவும்",
    exercises: {
      decision: { title: "அழுத்தத்தில் ஒரு முடிவு", body: "தெரிந்ததை மனத்தின் கணிப்பிலிருந்து பிரித்துப் பாருங்கள்.", prompt: "உண்மைகள் என்ன? நீங்கள் எதை ஊகிக்கிறீர்கள்? உங்கள் முடிவை எந்த நோக்கம் வழிநடத்தும்? எந்த விளைவை ஏற்க முடியும்?", action: "தீங்கை குறைக்கும் ஒரு தெளிவான படியைத் தேர்ந்தெடுக்கவும்." },
      boundary: { title: "விரோதமின்றி எல்லை", body: "மற்றவரைக் கட்டுப்படுத்தாமல் உங்களைப் பாதுகாத்துக் கொள்ளுங்கள்.", prompt: "உங்களுக்குரியது என்ன? அவர்களுக்குரியது என்ன? குற்றம்சாட்டாமல் அல்லது மிரட்டாமல் எந்தத் தெளிவான வாக்கியத்தைச் சொல்லலாம்?", action: "ஒரு அமைதியான எல்லையைச் சொல்லுங்கள். அவர்களின் பதிலுக்கு இடம் கொடுங்கள்." },
      attachment: { title: "பற்றும் நிச்சயமின்மையும்", body: "ஏக்கத்தைப் பாருங்கள். மற்றொருவரை ஒரு பதிலாக மாற்றாதீர்கள்.", prompt: "நீங்கள் எதை விரும்புகிறீர்கள்? எந்த உணர்வை எதிர்கொள்ளப் பயப்படுகிறீர்கள்? எந்தப் பகுதி உங்கள் கட்டுப்பாட்டுக்கு அப்பாற்பட்டது?", action: "உடைமை கோராமல் அக்கறை காட்டுங்கள்." },
      repair: { title: "தீங்குக்குப் பின் திருத்தம்", body: "வருத்தத்தைப் பொறுப்பாக மாற்றுங்கள். சுய தண்டனையாக அல்ல.", prompt: "என்ன நடந்தது? யார் பாதிக்கப்பட்டனர்? நீங்கள் எதை ஒப்புக்கொள்ளலாம்? இப்போது என்ன திருத்தம் சாத்தியம்?", action: "ஒரு குறிப்பிட்ட திருத்தத்தைச் செய்யுங்கள். உடனடி மன்னிப்பைக் கோராதீர்கள்." },
    },
  },
  si: {
    sectionTitle: "උසස් පරාවර්තනය",
    sectionIntro: "ඉවසීම, අවංකභාවය සහ වගකීම අවශ්‍ය අවස්ථා සඳහා.",
    privacyNote: "මෙය පුද්ගලික පුහුණුවකි. මෙය ලකුණක් හෝ රෝග විනිශ්චයක් නොවේ.",
    responseLabel: "ඔබගේ පුද්ගලික පිළිතුර",
    responsePlaceholder: "ඔබ දකින, දැනෙන හෝ තෝරන දේ ලියන්න.",
    saveResponse: "පිළිතුර සුරකින්න",
    clearResponse: "පිළිතුර මකන්න",
    savedResponse: "පිළිතුර මෙම උපාංගයේ සුරැකී ඇත.",
    open: "පුහුණුව විවෘත කරන්න",
    close: "පුහුණුව වසන්න",
    exercises: {
      decision: { title: "පීඩනය යටතේ තීරණයක්", body: "දන්නා දේ සිතේ අනාවැකියෙන් වෙන්කර බලන්න.", prompt: "කරුණු මොනවාද? ඔබ උපකල්පනය කරන්නේ කුමක්ද? ඔබේ තේරීම මෙහෙයවන්නේ කුමන අරමුණද? ඔබට පිළිගත හැකි ප්‍රතිඵලය කුමක්ද?", action: "හානිය අඩු කරන එක් පැහැදිලි පියවරක් තෝරන්න." },
      boundary: { title: "වෛරයකින් තොර සීමාවක්", body: "අනෙකා පාලනය නොකර ඔබට අයත් දේ ආරක්ෂා කරන්න.", prompt: "ඔබට අයත් දේ කුමක්ද? ඔවුන්ට අයත් දේ කුමක්ද? දොස් නොකියා හෝ තර්ජනය නොකර කුමන පැහැදිලි වාක්‍යයක් කිව හැකිද?", action: "සන්සුන් සීමාවක් කියන්න. ඔවුන්ගේ ප්‍රතිචාරයට ඉඩ දෙන්න." },
      attachment: { title: "ඇලීම සහ අවිනිශ්චිතතාව", body: "ආශාව දකින්න. අනෙකෙකු පිළිතුරක් බවට පත් නොකරන්න.", prompt: "ඔබට අවශ්‍ය කුමක්ද? ඔබට දැනීමට බිය කුමක්ද? ඔබේ පාලනයෙන් බැහැර කොටස කුමක්ද?", action: "අයිතිය ඉල්ලා නොසිට සැලකිල්ල දක්වන්න." },
      repair: { title: "හානියෙන් පසු පිළිසකර කිරීම", body: "පසුතැවීම වගකීමක් බවට පත් කරන්න. ස්වයං දඬුවමක් නොවේ.", prompt: "සිදු වූයේ කුමක්ද? බලපෑමට ලක් වූයේ කවුද? ඔබට පිළිගත හැක්කේ කුමක්ද? දැන් කළ හැකි පිළිසකරය කුමක්ද?", action: "එක් නිශ්චිත පිළිසකරයක් කරන්න. ඉක්මන් සමාවක් ඉල්ලා නොසිටින්න." },
    },
  },
  ml: {
    sectionTitle: "വിപുലമായ ചിന്തനം",
    sectionIntro: "ക്ഷമയും സത്യസന്ധതയും ഉത്തരവാദിത്വവും ആവശ്യമായ സാഹചര്യങ്ങൾക്ക്.",
    privacyNote: "ഇത് ഒരു സ്വകാര്യ പരിശീലനമാണ്. ഇത് സ്കോറോ രോഗനിർണ്ണയമോ അല്ല.",
    responseLabel: "നിങ്ങളുടെ സ്വകാര്യ മറുപടി",
    responsePlaceholder: "നിങ്ങൾ കാണുന്നതും അനുഭവിക്കുന്നതും തിരഞ്ഞെടുക്കുന്നതും എഴുതുക.",
    saveResponse: "മറുപടി സംരക്ഷിക്കുക",
    clearResponse: "മറുപടി മായ്ക്കുക",
    savedResponse: "മറുപടി ഈ ഉപകരണത്തിൽ സംരക്ഷിച്ചു.",
    open: "പരിശീലനം തുറക്കുക",
    close: "പരിശീലനം അടയ്ക്കുക",
    exercises: {
      decision: { title: "സമ്മർദ്ദത്തിലെ തീരുമാനം", body: "അറിയുന്നതിനെ മനസ്സിന്റെ പ്രവചനത്തിൽ നിന്ന് വേർതിരിക്കുക.", prompt: "വസ്തുതകൾ എന്താണ്? നിങ്ങൾ എന്താണ് അനുമാനിക്കുന്നത്? നിങ്ങളുടെ തിരഞ്ഞെടുപ്പിനെ ഏത് ഉദ്ദേശ്യം നയിക്കും? ഏത് ഫലം സ്വീകരിക്കാം?", action: "ദോഷം കുറയ്ക്കുന്ന ഒരു വ്യക്തമായ പടി തിരഞ്ഞെടുക്കുക." },
      boundary: { title: "വൈരമില്ലാത്ത അതിരുകൾ", body: "മറ്റൊരാളെ നിയന്ത്രിക്കാതെ നിങ്ങളുടേത് സംരക്ഷിക്കുക.", prompt: "നിങ്ങളുടേത് എന്താണ്? അവരുടേത് എന്താണ്? കുറ്റപ്പെടുത്തലോ ഭീഷണിയോ ഇല്ലാതെ ഏത് വ്യക്തമായ വാക്യം പറയാം?", action: "ശാന്തമായ ഒരു അതിർത്തി പറയുക. അവരുടെ പ്രതികരണത്തിന് ഇടം നൽകുക." },
      attachment: { title: "പറ്റിപ്പിടിത്തവും അനിശ്ചിതത്വവും", body: "ആഗ്രഹത്തെ കാണുക. മറ്റൊരാളെ ഒരു ഉത്തരമാക്കരുത്.", prompt: "നിങ്ങൾ എന്താണ് ആഗ്രഹിക്കുന്നത്? ഏത് വികാരത്തെയാണ് നിങ്ങൾ ഭയപ്പെടുന്നത്? നിങ്ങളുടെ നിയന്ത്രണത്തിന് പുറത്തുള്ള ഭാഗം ഏതാണ്?", action: "ഉടമസ്ഥത ആവശ്യപ്പെടാതെ കരുതൽ നൽകുക." },
      repair: { title: "ദോഷത്തിന് ശേഷമുള്ള പരിഹാരം", body: "പശ്ചാത്താപത്തെ ഉത്തരവാദിത്വമാക്കുക. സ്വയം ശിക്ഷയല്ല.", prompt: "എന്താണ് സംഭവിച്ചത്? ആരെയാണ് ബാധിച്ചത്? നിങ്ങൾക്ക് എന്ത് സമ്മതിക്കാം? ഇപ്പോൾ സാധ്യമായ പരിഹാരം എന്താണ്?", action: "ഒരു വ്യക്തമായ പരിഹാരം ചെയ്യുക. ഉടൻ ക്ഷമ ആവശ്യപ്പെടരുത്." },
    },
  },
};

const exerciseIds: ExerciseId[] = ["decision", "boundary", "attachment", "repair"];

const principles = [
  { title: "Pause before speech", body: "Is it true? Is it useful? Is now the right time?", icon: "chat" },
  { title: "Name the feeling", body: "A feeling can be known without becoming an order.", icon: "visibility" },
  { title: "Leave room for freedom", body: "Care does not require possession or control.", icon: "open-in-new" },
];

export default function PracticeScreen() {
  const router = useRouter();
  const { stories } = useStories();
  const { language } = useLanguage();
  const [selectedExerciseId, setSelectedExerciseId] = useState<ExerciseId | null>(null);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const [draftResponse, setDraftResponse] = useState("");
  const [responseStatus, setResponseStatus] = useState("");
  const savedPractices = stories.filter((story) => story.insight);
  const localized = exerciseText[language] ?? exerciseText.en;

  useEffect(() => {
    loadAdvancedResponses().then(setResponses).catch(() => setResponses({}));
  }, []);

  useEffect(() => {
    setDraftResponse(selectedExerciseId ? responses[selectedExerciseId] ?? "" : "");
    setResponseStatus("");
  }, [selectedExerciseId, responses]);

  async function handleSaveResponse() {
    if (!selectedExerciseId) return;
    await saveAdvancedResponse(selectedExerciseId, draftResponse);
    setResponses((current) => ({ ...current, [selectedExerciseId]: draftResponse.trim() }));
    setResponseStatus(localized.savedResponse);
  }

  async function handleClearResponse() {
    if (!selectedExerciseId) return;
    await clearAdvancedResponse(selectedExerciseId);
    setResponses((current) => {
      const next = { ...current };
      delete next[selectedExerciseId];
      return next;
    });
    setDraftResponse("");
    setResponseStatus("");
  }

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <FlatList
        data={savedPractices}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <Text className="pt-2 text-sm font-semibold tracking-widest text-primary">PRACTICE</Text>
            <Text className="mt-1 text-3xl font-bold text-foreground">One small step</Text>
            <Text className="mt-3 text-base leading-6 text-muted">Dhamma becomes visible through the next intention.</Text>
            <View className="mt-7 rounded-3xl bg-foreground px-5 py-6"><Text className="text-xs font-bold uppercase tracking-widest text-primary">For this moment</Text><Text className="mt-3 text-2xl font-semibold leading-8 text-background">Notice the wish. Do not rush to obey it.</Text><Text className="mt-3 text-sm leading-5 text-background" style={styles.darkSupportingText}>Stay with one breath. Then choose.</Text></View>
            <Text className="mt-8 text-xl font-bold text-foreground">{localized.sectionTitle}</Text>
            <Text className="mt-2 text-sm leading-5 text-muted">{localized.sectionIntro}</Text>
            <Text className="mt-2 text-xs leading-5 text-muted">{localized.privacyNote}</Text>
            {exerciseIds.map((id) => {
              const exercise = localized.exercises[id];
              const isSelected = selectedExerciseId === id;
              return (
                <Pressable key={id} onPress={() => setSelectedExerciseId(isSelected ? null : id)} style={({ pressed }) => [styles.exerciseCard, isSelected && styles.exerciseSelected, pressed && styles.faded]}>
                  <View className="flex-row items-start"><View className="h-9 w-9 items-center justify-center rounded-full bg-primary/10"><Text className="text-sm font-bold text-primary">{exerciseIds.indexOf(id) + 1}</Text></View><View className="ml-3 flex-1"><Text className="text-base font-bold text-foreground">{exercise.title}</Text><Text className="mt-1 text-sm leading-5 text-muted">{exercise.body}</Text></View></View>
                  {isSelected ? <View className="mt-4 border-t border-border pt-4"><Text className="text-sm font-semibold leading-5 text-foreground">{exercise.prompt}</Text><Text className="mt-3 text-sm font-semibold leading-5 text-primary">{exercise.action}</Text><Text className="mt-4 text-xs font-bold uppercase tracking-widest text-primary">{localized.responseLabel}</Text><TextInput multiline value={draftResponse} onChangeText={setDraftResponse} placeholder={localized.responsePlaceholder} placeholderTextColor="#8B918B" textAlignVertical="top" style={styles.responseInput} /><View className="mt-3 flex-row gap-2"><Pressable onPress={handleSaveResponse} style={({ pressed }) => [styles.responseButton, pressed && styles.faded]}><Text className="text-xs font-bold text-background">{localized.saveResponse}</Text></Pressable><Pressable onPress={handleClearResponse} style={({ pressed }) => [styles.clearButton, pressed && styles.faded]}><Text className="text-xs font-bold text-foreground">{localized.clearResponse}</Text></Pressable></View>{responseStatus ? <Text className="mt-2 text-xs font-semibold text-success">{responseStatus}</Text> : null}<Text className="mt-3 text-xs font-semibold text-muted">{localized.close}</Text></View> : <Text className="mt-3 text-xs font-semibold text-primary">{responses[id] ? localized.responseLabel : localized.open}</Text>}
                </Pressable>
              );
            })}
            <Text className="mt-8 text-xl font-bold text-foreground">Saved practices</Text>
            {savedPractices.length === 0 ? <Text className="mt-2 text-sm leading-5 text-muted">Insights you save will appear here.</Text> : null}
            <Text className="mt-8 text-xl font-bold text-foreground">Keep close</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => router.push({ pathname: "/story/[id]", params: { id: item.id } })} style={({ pressed }) => [styles.savedCard, pressed && styles.faded]}>
            <View className="h-9 w-9 items-center justify-center rounded-full bg-success/15"><IconSymbol name="checkmark" size={18} color="#587A5A" /></View>
            <View className="ml-3 flex-1"><Text className="text-xs font-bold uppercase tracking-widest text-success">{item.insight?.principle}</Text><Text className="mt-1 text-sm leading-5 text-foreground" numberOfLines={3}>{item.insight?.smallPractice}</Text></View>
            <IconSymbol name="chevron.right" size={19} color="#6C7770" />
          </Pressable>
        )}
        ListFooterComponent={<View className="mt-1">{principles.map((item) => <View key={item.title} className="mt-3 flex-row rounded-2xl border border-border bg-surface px-4 py-4"><View className="h-9 w-9 items-center justify-center rounded-full bg-primary/10"><IconSymbol name="leaf.fill" size={18} color="#B56A38" /></View><View className="ml-3 flex-1"><Text className="text-sm font-bold text-foreground">{item.title}</Text><Text className="mt-1 text-sm leading-5 text-muted">{item.body}</Text></View></View>)}</View>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 36 },
  savedCard: { alignItems: "center", backgroundColor: "#EDF4EA", borderRadius: 22, flexDirection: "row", marginTop: 12, padding: 15 },
  exerciseCard: { backgroundColor: "#F7F4EE", borderColor: "#E5DED2", borderRadius: 20, borderWidth: 1, marginTop: 12, padding: 15 },
  exerciseSelected: { backgroundColor: "#EDF4EA", borderColor: "#B56A38" },
  responseInput: { backgroundColor: "#FFFFFF", borderColor: "#D8DED7", borderRadius: 14, borderWidth: 1, color: "#1B2A25", fontSize: 15, minHeight: 96, marginTop: 10, padding: 12 },
  responseButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 12, flex: 1, paddingVertical: 11 },
  clearButton: { alignItems: "center", borderColor: "#D8DED7", borderRadius: 12, borderWidth: 1, flex: 1, paddingVertical: 11 },
  faded: { opacity: 0.62 },
  darkSupportingText: { opacity: 0.72 },
});
