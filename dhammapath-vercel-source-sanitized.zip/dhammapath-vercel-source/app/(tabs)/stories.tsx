import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useStories } from "@/lib/stories-context";
import { useLanguage } from "@/lib/language-context";
import { FEELINGS, type Story } from "@/lib/types";

function feelingLabel(key: Story["feeling"]) {
  return FEELINGS.find((feeling) => feeling.key === key)?.label ?? "Feeling";
}

function dayKey(value: string) {
  return value.slice(0, 10);
}

function formatDay(value: string) {
  return new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`));
}

type StoryDay = { day: string; items: Story[] };

export default function StoriesScreen() {
  const router = useRouter();
  const { stories, isLoaded, deleteStory } = useStories();
  const { t } = useLanguage();
  const [query, setQuery] = useState("");
  const visibleDays = useMemo<StoryDay[]>(() => {
    const normalized = query.trim().toLowerCase();
    const filtered = normalized ? stories.filter((story) => `${story.title} ${story.content} ${story.feeling}`.toLowerCase().includes(normalized)) : stories;
    const grouped = new Map<string, Story[]>();
    filtered.forEach((story) => {
      const day = dayKey(story.createdAt);
      grouped.set(day, [...(grouped.get(day) ?? []), story]);
    });
    return Array.from(grouped.entries()).map(([day, items]) => ({ day, items }));
  }, [query, stories]);

  function confirmDelete(story: Story) {
    Alert.alert("Delete this entry?", `Only “${story.title}” from ${formatDay(dayKey(story.createdAt))} will be removed. The Room will remain.`, [
      { text: t("cancel"), style: "cancel" },
      { text: t("delete"), style: "destructive", onPress: () => deleteStory(story.id) },
    ]);
  }

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <FlatList
        data={visibleDays}
        keyExtractor={(item) => item.day}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={<View><View className="flex-row items-end justify-between pt-2"><View><Text className="text-sm font-semibold tracking-widest text-primary">ARCHIVE</Text><Text className="mt-1 text-3xl font-bold text-foreground">Your stories</Text></View><Pressable onPress={() => router.push("/story/new")} style={({ pressed }) => [styles.addButton, pressed && styles.pressed]}><IconSymbol name="plus" size={21} color="#F7F4EE" /></Pressable></View><View className="mt-6 flex-row items-center rounded-2xl border border-border bg-surface px-4"><IconSymbol name="magnifyingglass" size={18} color="#6C7770" /><TextInput value={query} onChangeText={setQuery} placeholder="Search your words" placeholderTextColor="#9A9E98" className="ml-2 flex-1 py-3 text-base text-foreground" /></View><Text className="mt-6 text-sm text-muted">{stories.length === 0 ? "No stories yet" : `${stories.length} ${stories.length === 1 ? "story" : "stories"}`}</Text></View>}
        renderItem={({ item }) => <View className="mt-6"><Text className="text-sm font-bold uppercase tracking-widest text-primary">{formatDay(item.day)}</Text>{item.items.map((story) => <Pressable key={story.id} onPress={() => router.push({ pathname: "/story/[id]", params: { id: story.id } })} style={({ pressed }) => [styles.card, pressed && styles.faded]}><View className="flex-1 pr-3"><Text className="text-xs font-bold uppercase tracking-widest text-primary">{feelingLabel(story.feeling)}</Text><Text className="mt-2 text-lg font-semibold text-foreground">{story.title}</Text><Text className="mt-1 text-sm leading-5 text-muted" numberOfLines={2}>{story.content}</Text><Text className="mt-3 text-xs text-muted">Room entry</Text></View><Pressable accessibilityLabel="Delete this entry" onPress={(event) => { event.stopPropagation(); confirmDelete(story); }} style={({ pressed }) => [styles.deleteButton, pressed && styles.faded]}><IconSymbol name="trash" size={18} color="#B04A43" /></Pressable></Pressable>)}</View>}
        ListEmptyComponent={<View className="mt-10 items-center rounded-3xl border border-dashed border-border px-6 py-10"><View className="h-14 w-14 items-center justify-center rounded-full bg-primary/10"><IconSymbol name="book.closed.fill" size={25} color="#B56A38" /></View><Text className="mt-4 text-center text-lg font-semibold text-foreground">{isLoaded && query ? "Nothing matched." : "A quiet page is waiting."}</Text><Text className="mt-2 text-center text-sm leading-5 text-muted">{query ? "Try another word." : "Keep one honest moment here."}</Text></View>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 34 },
  addButton: { alignItems: "center", backgroundColor: "#1B2A25", borderRadius: 20, height: 42, justifyContent: "center", width: 42 },
  card: { alignItems: "center", backgroundColor: "#FFFDF8", borderColor: "#E5DED2", borderRadius: 22, borderWidth: 1, flexDirection: "row", marginTop: 12, padding: 17 },
  deleteButton: { alignItems: "center", borderColor: "#E5DED2", borderRadius: 16, borderWidth: 1, height: 36, justifyContent: "center", width: 36 },
  pressed: { opacity: 0.88, transform: [{ scale: 0.97 }] },
  faded: { opacity: 0.62 },
});
