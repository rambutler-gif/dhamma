import { useState } from "react";
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useStories } from "@/lib/stories-context";
import { usePrivateSpace } from "@/lib/private-space";
import { useLanguage } from "@/lib/language-context";
import { useThemeContext } from "@/lib/theme-provider";

export default function SettingsScreen() {
  const { stories, clearStories } = useStories();
  const { colorScheme, setColorScheme } = useThemeContext();
  const { language, setLanguage, languages, t } = useLanguage();
  const { hasPassword, setMasterPassword, changeMasterPassword, lock } = usePrivateSpace();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  function confirmClear() {
    Alert.alert("Clear all stories?", "Every story and saved insight will be removed from this device.", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear all", style: "destructive", onPress: clearStories },
    ]);
  }

  return (
    <ScreenContainer className="px-5" safeAreaClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <Text className="pt-2 text-sm font-semibold tracking-widest text-primary">{t("appName").toUpperCase()}</Text>
        <Text className="mt-1 text-3xl font-bold text-foreground">{t("settings")}</Text>
        <Text className="mt-3 text-base leading-6 text-muted">A Theravada life companion. Your choice remains yours.</Text>

        <Text className="mt-8 text-xs font-bold uppercase tracking-widest text-muted">{t("guidance")}</Text>
        <View className="mt-3 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-base font-semibold leading-6 text-foreground">This adviser is direct, not absolute.</Text><Text className="mt-2 text-sm leading-5 text-muted">It uses Theravada principles. It can be wrong. It does not diagnose. It does not replace a qualified teacher, therapist, doctor, or emergency service.</Text></View>

        <Text className="mt-7 text-xs font-bold uppercase tracking-widest text-muted">{t("appearance")}</Text>
        <View className="mt-3 flex-row rounded-2xl border border-border bg-surface p-1">
          {(["light", "dark"] as const).map((scheme) => <Pressable key={scheme} onPress={() => setColorScheme(scheme)} style={({ pressed }) => [styles.schemeButton, colorScheme === scheme && styles.schemeSelected, pressed && styles.faded]}><Text className={colorScheme === scheme ? "text-sm font-bold text-background" : "text-sm font-semibold text-muted"}>{scheme === "light" ? t("light") : t("dark")}</Text></Pressable>)}
        </View>

        <Text className="mt-7 text-xs font-bold uppercase tracking-widest text-muted">{t("chooseLanguage")}</Text>
        <View className="mt-3 rounded-3xl border border-border bg-surface px-4 py-4"><Text className="text-sm leading-5 text-muted">{t("languageHelp")}</Text><View className="mt-3 flex-row flex-wrap gap-2">{languages.map((item) => <Pressable key={item.key} onPress={() => setLanguage(item.key)} style={({ pressed }) => [styles.languageChip, language === item.key && styles.languageChipSelected, pressed && styles.faded]}><Text className={language === item.key ? "text-sm font-bold text-background" : "text-sm font-semibold text-foreground"}>{item.native}</Text></Pressable>)}</View></View>

        <Text className="mt-7 text-xs font-bold uppercase tracking-widest text-muted">{t("privateSpace")}</Text>
        <View className="mt-3 rounded-3xl border border-border bg-surface px-5 py-5"><Text className="text-base font-bold text-foreground">{hasPassword ? t("changePassword") : t("createPassword")}</Text><Text className="mt-2 text-sm leading-5 text-muted">This protects access to your thought boxes and script controls.</Text>{hasPassword ? <TextInput value={currentPassword} onChangeText={setCurrentPassword} placeholder="Current password" placeholderTextColor="#9A9E98" secureTextEntry className="mt-4 rounded-2xl border border-border bg-background px-4 py-3 text-base text-foreground" /> : null}<TextInput value={newPassword} onChangeText={setNewPassword} placeholder={hasPassword ? t("changePasswordButton") : t("savePassword")} placeholderTextColor="#9A9E98" secureTextEntry className="mt-3 rounded-2xl border border-border bg-background px-4 py-3 text-base text-foreground" /><TextInput value={confirmPassword} onChangeText={setConfirmPassword} placeholder="Repeat password" placeholderTextColor="#9A9E98" secureTextEntry className="mt-3 rounded-2xl border border-border bg-background px-4 py-3 text-base text-foreground" /><Pressable onPress={async () => { if (newPassword.length < 6 || newPassword !== confirmPassword) { Alert.alert("Check your password", "Use six or more characters. Both entries must match."); return; } const okay = hasPassword ? await changeMasterPassword(currentPassword, newPassword) : (await setMasterPassword(newPassword), true); if (!okay) { Alert.alert("Password did not match", "Your master password was not changed."); return; } setCurrentPassword(""); setNewPassword(""); setConfirmPassword(""); Alert.alert("Saved", "Your private space password is ready."); }} style={({ pressed }) => [styles.passwordButton, pressed && styles.faded]}><Text className="text-sm font-bold text-background">{hasPassword ? t("changePassword") : t("createPassword")}</Text></Pressable>{hasPassword ? <Pressable onPress={() => { lock(); Alert.alert("Private space locked", "Enter your master password to return."); }} style={({ pressed }) => [styles.lockButton, pressed && styles.faded]}><IconSymbol name="lock.fill" size={17} color="#1B2A25" /><Text className="ml-2 text-sm font-bold text-foreground">{t("lockNow")}</Text></Pressable> : null}</View>

        <Text className="mt-7 text-xs font-bold uppercase tracking-widest text-muted">{t("privacy")}</Text>
        <View className="mt-3 flex-row items-center rounded-2xl border border-border bg-surface px-4 py-4"><IconSymbol name="lock.fill" size={18} color="#587A5A" /><View className="ml-3 flex-1"><Text className="text-sm font-bold text-foreground">{t("localJournal")}</Text><Text className="mt-1 text-sm leading-5 text-muted">{stories.length} saved {stories.length === 1 ? "story" : "stories"} on this device.</Text></View></View>
        <Pressable onPress={confirmClear} style={({ pressed }) => [styles.dangerButton, pressed && styles.faded]}><IconSymbol name="trash" size={18} color="#B04A43" /><Text className="ml-2 text-sm font-semibold text-error">{t("clearStories")}</Text></Pressable>

        <Text className="mt-7 text-xs font-bold uppercase tracking-widest text-muted">{t("support")}</Text>
        <View className="mt-3 rounded-3xl border border-error/25 bg-error/10 px-5 py-5"><Text className="text-base font-bold text-foreground">{t("urgent")}</Text><Text className="mt-2 text-sm leading-5 text-foreground">If you may hurt yourself or someone else, contact local emergency services now. Move near another person. Tell them clearly what is happening.</Text><Pressable onPress={() => Linking.openURL("https://findahelpline.com/")} style={({ pressed }) => [styles.supportButton, pressed && styles.faded]}><Text className="text-sm font-bold text-background">Find local crisis support</Text></Pressable></View>

        <Text className="mt-8 text-center text-xs leading-5 text-muted">{t("appName")}{`\n`}{t("tagline")}</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 10, paddingBottom: 42 },
  schemeButton: { alignItems: "center", borderRadius: 16, flex: 1, paddingVertical: 11 },
  schemeSelected: { backgroundColor: "#1B2A25" },
  dangerButton: { alignItems: "center", flexDirection: "row", justifyContent: "center", marginTop: 14, paddingVertical: 12 },
  languageChip: { borderColor: "#E5DED2", borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10 },
  languageChipSelected: { backgroundColor: "#1B2A25", borderColor: "#1B2A25" },
  passwordButton: { alignItems: "center", backgroundColor: "#B56A38", borderRadius: 15, marginTop: 14, paddingVertical: 13 },
  lockButton: { alignItems: "center", borderColor: "#E5DED2", borderRadius: 15, borderWidth: 1, flexDirection: "row", justifyContent: "center", marginTop: 10, paddingVertical: 12 },
  supportButton: { alignItems: "center", backgroundColor: "#B04A43", borderRadius: 15, marginTop: 18, paddingVertical: 13 },
  faded: { opacity: 0.6 },
});
