# Comparable App Research

Research date: 25 August 2026.

## Reflection
Source: https://www.reflection.app/

Reflection positions itself as a private AI journaling and mental wellness coach. Its public feature list includes real time voice coaching, follow up questions while writing, asking the journal questions, guided journeys, voice transcription, biometrics or passcode locking, daily reminders, weekly and monthly reviews, search, and multi device sync. Its central promise is helping users gain clarity through journaling and AI coaching.

## Samadhi: Theravada Meditation
Source: https://play.google.com/store/apps/details?id=com.cjtoolseram.samadhi&hl=en_US

Samadhi presents itself as a quiet Theravada meditation companion. Its public description includes a daily Dhammapada or sutta contemplation, a progressive practice path covering anapanasati, metta, body mindfulness, vipassana, kasina, jhana, and upekkha, named teachers, curated canonical reading, and Buddha themed video playlists. It is primarily a meditation and Dhamma study product, rather than a personal life story adviser.

Initial differentiation: Dhamma Thought Adviser can combine a private life story journal, user selected thought boxes, master script based questions, direct wrong view and right view explanations, and small substitute practices. This is a different use case from a meditation course or a general AI journal.

## Plum Village App
Source: https://plumvillage.app/

The Plum Village App is a free mindfulness app from Thich Nhat Hanh's Zen community. Its public page highlights guided meditations, deep relaxations, talks, and practice resources, including care for difficult feelings. It is a teacher and practice library, not a personal life-story decision adviser, and it represents a different Buddhist tradition from the planned Theravada orientation.

## SuttaCentral
Source: https://suttacentral.net/

SuttaCentral is a major reference and reading platform for early Buddhist texts. Its public home presents the Tipiṭaka through Suttapiṭaka, Vinayapiṭaka, and Abhidhammapiṭaka sections, with translations, parallels, reader guides, indexes, terminology, offline use, and voice access. It is an important benchmark for scripture coverage and source discipline. Dhamma Thought Adviser should not claim to replace it. The opportunity is to provide a smaller, easier entry point that connects selected teachings to a user's private reflection.
