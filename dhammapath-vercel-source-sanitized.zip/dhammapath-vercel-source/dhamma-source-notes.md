# Dhamma source notes

## Dhammapada 1 to 20

Primary source: Access to Insight, Yamakavagga: Pairs.
URL: https://www.accesstoinsight.org/tipitaka/kn/dhp/dhp.01.budd.html

The source presents Dhammapada verses 1 and 2 with the translation: “Mind precedes all mental states. Mind is their chief; they are all mind-wrought.” Verse 1 links an impure mind with suffering following speech or action. Verse 2 links a pure mind with happiness following speech or action. The chapter also includes verse 5, which states that hatred is not appeased by hatred, and verses 11 and 12, which distinguish the essential from the unessential.

The app should label the wording as a translation and include the source link. The app should avoid presenting the verse as a medical or psychological guarantee.

## Right View

Primary source: Access to Insight, Right View: samma ditthi.
URL: https://www.accesstoinsight.org/ptf/dhamma/sacca/sacca4/samma-ditthi/index.html

The source defines right view through knowledge of stress, its origination, its cessation, and the path leading to its cessation, citing DN 22. It also explains that discerning wrong view as wrong view and right view as right view is itself right view, citing MN 117. The source describes wrong view as connected to consequences through resolve, speech, action, livelihood, effort, mindfulness, and concentration.

For Dhammapath, “wrong view” should be explained carefully as unhelpful or distorted seeing in the user’s situation. It should not label the user as bad. Responses should focus on causes, conditions, intention, speech, action, and consequences.

## Content guardrail

Use plain language beside Pali. Show source notes inside Learn. Do not invent exact Pali passages or translations when source verification is incomplete.

## Jātaka collection

Primary collection reference: SuttaCentral Jātaka collection.
URL: https://suttacentral.net/ja

The collection presents Jātaka material as past-life stories of the Buddha and lists stories including The Sandy Track and The Merchant Seriva. The app should use a clearly labeled simplified retelling, preserve the story title and source link, and avoid presenting a modern paraphrase as a verbatim canonical translation.
