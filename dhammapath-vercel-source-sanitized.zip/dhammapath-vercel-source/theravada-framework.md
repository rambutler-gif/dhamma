# Theravada Reflection Framework

The app should treat guidance as reflective education, not psychiatric diagnosis or a replacement for professional care.

## Core response pattern

1. Hear the user's experience without judgment.
2. Ask clarifying questions: who, what, when, how, and what is felt.
3. Separate observable facts from assumptions, craving, fear, anger, and self-story.
4. Identify whether the thought expresses right view or wrong view, using plain language.
5. Explain the meaning of the identified view.
6. Offer a wiser substitute based on the Four Noble Truths, intention, non-harming, impermanence, and responsibility.
7. Suggest one small action in right speech, right action, right effort, or mindfulness.
8. Respect autonomy. The user may follow or not follow the advice.

## Product language

Use direct but compassionate phrasing. Say: "This appears to be wrong view because..." Avoid shame, certainty about another person's mind, and claims of spiritual authority. Clarify that "wrong view" means an unhelpful or reality-distorting way of seeing, not that the person is bad.

## Example relationship flow

User: "I like a girl."
Questions: "Who is she to you? How do you know her? When did this feeling begin? What do you feel when you think of her? Are you seeing her as she is, or as an image built from desire?"

Reflection: "Wanting closeness is human. Suffering increases when the mind treats a desired outcome as necessary. This can become wrong view when imagination is mistaken for knowledge or possession is mistaken for love."

Substitute: "Know the feeling as feeling. Speak honestly and respectfully. Allow her freedom to answer. Let the result be uncertain without turning it into self-worth."

## Safety boundary

The app must never diagnose, claim guaranteed healing, encourage dependence, or replace urgent mental health support. If a user expresses immediate danger or self-harm, show urgent local emergency guidance and encourage contact with a qualified professional or trusted person.

## Primary sources

1. Access to Insight, "Right View: samma ditthi": https://www.accesstoinsight.org/ptf/dhamma/sacca/sacca4/samma-ditthi/index.html
2. Access to Insight, "The Discourse on Right View": https://www.accesstoinsight.org/lib/authors/nanamoli/wheel377.html
3. Spirit Rock, "The Five Hindrances": https://www.spiritrock.org/practice-guides/the-five-hindrances
