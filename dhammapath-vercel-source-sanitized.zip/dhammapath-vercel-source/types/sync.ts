export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface OfficeTask extends BaseEntity {
  task: string;
  category: string;
  project?: string;
  severity?: string;
  priority?: string;
  owner?: string;
  date: string;
  status: 'pending' | 'in-progress' | 'completed';
}

export interface Project extends BaseEntity {
  product: string;
  name: string;
  status: string;
  deadline?: string;
  reviewDate?: string;
  remark?: string;
}

export interface ChecklistItem extends BaseEntity {
  title: string;
  note?: string;
  date: string;
  done: boolean;
}

export interface TrainingRecord extends BaseEntity {
  date: string;
  topic: string;
}

export type SyncEntityType = 'task' | 'project' | 'checklist' | 'training';
export type SyncEntity = OfficeTask | Project | ChecklistItem | TrainingRecord;

export type ConflictResolution = 'keep-app' | 'keep-excel';

export interface SyncConflict<T> {
  id: string;
  entityType: SyncEntityType;
  appVersion: T;
  excelVersion: T;
}

export interface SyncSummary {
  added: number;
  updated: number;
  skipped: number;
  conflicts: number;
}
