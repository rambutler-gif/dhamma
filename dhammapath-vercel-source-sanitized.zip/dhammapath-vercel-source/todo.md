# Project TODO

- [x] Define Theravada reflection framework
- [x] Document portrait interface and one handed flows
- [x] Build calm home screen with daily reflection prompt
- [x] Build local life story storage
- [x] Build story list and story detail screens
- [x] Build guided who what when how feeling questions
- [x] Build wrong view explanation and meaning sections
- [x] Build wiser substitute advice and one small practice
- [x] Add user autonomy actions for practise and not now
- [x] Add safety escalation for immediate danger language
- [x] Add practice library screen
- [x] Add settings and privacy screen
- [x] Generate and install custom app branding icon
- [x] Add deterministic unit tests for local stories and guidance logic
- [x] Run TypeScript, lint, and test checks
- [x] Review app behavior and prepare checkpoint

- [x] Add Learn tab with Pali search
- [x] Add Tamil and English Pali meanings
- [x] Add daily Pali, Tamil, and English Dhamma verse
- [ ] Add easy to understand Jātaka stories
- [ ] Add Sutta Piṭaka mind map viewer
- [ ] Add Vinaya Piṭaka mind map viewer
- [ ] Add learning content tests and verify supplied image assets

- [x] Add master script model for each thought box
- [x] Connect Reflect to the selected thought box script
- [x] Generate reflection questions from the selected script
- [x] Add delete controls for individual questions and answers
- [x] Require master password for script access
- [x] Require master password before changing a script box
- [x] Require master password before deleting a script box
- [x] Add secure password change flow
- [x] Add permission and script management tests

- [x] Add language selector for English, Hindi, Tamil, Sinhala, and Malayalam
- [x] Persist the selected language locally
- [ ] Localize navigation, settings, privacy, and lock screens
- [ ] Localize reflection questions and guidance
- [ ] Localize Pali glossary, verses, and Jātaka content
- [x] Add language switching tests

- [x] Restore NVIDIA NIM router and mobile client connection
- [x] Restore NVIDIA API key validation test
- [x] Restore NVIDIA live chat test
- [x] Verify the key remains server side
- [x] Run TypeScript, tests, and lint after restoration

- [x] Restore expanded circumstance reflection
- [x] Restore Theravada companion framing
- [x] Restore Dhamma: The Path Within branding
- [x] Restore blue watercolor Buddhist logo assets
- [x] Restore NVIDIA NIM server connection
- [x] Restore NVIDIA key and chat tests
- [ ] Build Learn tab with Pali search
- [ ] Add Pali meanings in English, Hindi, Tamil, Sinhala, and Malayalam
- [ ] Add daily Pali verse with five language meanings
- [ ] Add easy Jātaka story reader
- [ ] Add Sutta Piṭaka mind map viewer
- [ ] Add Vinaya Piṭaka mind map viewer
- [ ] Add five language scripture content foundations
- [x] Run complete checks and visual review

- [ ] Diagnose backend service stuck at 1% during publish
- [ ] Recover backend deployment if the publish job is stalled
- [ ] Verify backend health after recovery

- [ ] Diagnose Expo access token not active during APK build
- [ ] Confirm Expo account and project ownership alignment
- [ ] Verify APK build authentication recovery path

- [ ] Recover frozen Expo publish job at 1%
- [ ] Verify the app remains unchanged after recovery

- [ ] Verify NVIDIA AI backend independently from Expo publishing
- [ ] Confirm Expo APK publishing remains a separate external blocker
- [ ] Document the immediate recovery action for each service

- [x] Confirm deleted Expo token does not affect backend health
- [x] Verify local backend remains healthy after Expo token deletion
- [x] Confirm frozen Expo queue cannot be cancelled from app backend

- [x] Inventory source, assets, tests, and documentation for export
- [x] Exclude API keys, database URLs, tokens, and private environment files
- [x] Write complete project blueprint
- [x] Create sanitized full source ZIP
- [x] Verify ZIP contents and secret exclusion

- [x] Diagnose blank or loading Upload Built API screen
- [x] Verify public backend deployment status after the blank screen
- [x] Document the safe recovery path for API upload

- [x] Preserve current app archive before clean rebuild
- [x] Create Dhammapath design specification
- [ ] Rebuild clean Expo foundation
- [ ] Rebuild private Rooms and reflection flow
- [x] Add emotion meter and calendar history
- [ ] Add Dhamma learning library and mind maps
- [ ] Reconnect protected NVIDIA AI route
- [ ] Run tests and prepare fresh Android build

- [ ] Complete Room creation and rename flow
- [x] Verify Room-linked story creation and detail flow
- [ ] Add full Jātaka reader content
- [x] Connect Sutta and Vinaya mind-map viewers
- [x] Add zoomable Sutta Piṭaka viewer screen
- [x] Add zoomable Vinaya Piṭaka viewer screen
- [x] Add five-language viewer labels
- [x] Expand reflection and learning localization
- [x] Localize all core screens in English, Hindi, Tamil, Sinhala, and Malayalam
- [x] Localize reflection questions and safety messages
- [x] Localize Learn terms, verses, stories, and mind-map labels
- [x] Test persisted language switching across app routes
- [x] Add visible language switcher dropdown to main navigation
- [x] Verify language changes update the current page and navigation labels

- [x] Diagnose Android personal-use build stuck at 1%
- [x] Confirm live backend remains unchanged during build recovery
- [x] Document APK build recovery action

- [ ] Preserve and archive the current project before rebuild
- [ ] Create a clean Expo foundation for the rebuilt app
- [ ] Rebuild private thought storage and locking
- [ ] Rebuild thought boxes and guided reflection
- [ ] Rebuild backend and NVIDIA NIM integration
- [ ] Revalidate branding, localization, tests, and Android build
- [ ] Add private emotion check-in after each reflection
- [ ] Add calendar-based reflection history view
- [ ] Show impermanence reminder without scoring or diagnosis
- [ ] Keep emotion history local and protected

- [x] Add five-language translation dictionary
- [x] Localize Home, Calendar, Learn, Settings, Rooms, reflection check-in, safety entry, and Piṭaka viewers
- [x] Keep language selection persisted locally
- [x] Run TypeScript and Vitest checks after localization
- [x] Finish localized story detail, story creation, practice, and deep guidance copy
- [ ] Human-review all Hindi, Tamil, Sinhala, and Malayalam wording
- [x] Audit all five-language keys for missing translations
- [ ] Remove remaining fixed English strings from visible screens
- [ ] Check long-script layout and dropdown labels
- [x] Cross-check the latest product prompt against the current implementation
- [x] Classify each prompt requirement as complete, partial, or missing
- [x] Record the remaining rebuild priorities

- [ ] Correct the white forehead mark to blue
- [ ] Visually verify the corrected artwork before delivery

- [x] Replace branding assets with the corrected blue-nose Buddha artwork
- [x] Validate the updated launcher and splash configuration

- [x] Add structured reflection fields for facts, assumptions, craving, fear, anger, and self-story
- [x] Persist facts and assumptions separately from the freeform story
- [x] Persist craving, fear, anger, and self-story reflection fields
- [x] Include structured fields in local insight context
- [x] Include structured fields in protected NVIDIA reflection input
- [x] Add five-language labels and prompts for structured fields
- [x] Test structured field persistence and guidance context

- [x] Add dedicated craving guidance branch
- [x] Add dedicated self-story guidance branch
- [x] Test craving and self-story guidance without shame or diagnosis

- [x] Add private structured-field readback to Story Detail
- [x] Add five-language labels for Story Detail readback
- [x] Test structured readback with empty and populated fields

- [x] Add edit mode for saved structured fields
- [x] Add save and cancel behavior for structured edits
- [x] Test structured-field edit persistence and empty values

- [x] Add dedicated fear guidance branch
- [x] Add dedicated anger guidance branch
- [x] Test fear and anger safety behavior without shame or diagnosis


## Current product direction change

- [x] Remove Jātaka concept from Learn navigation and content
- [x] Replace Jātaka with a mature Dhamma reflection practice library
- [x] Update translations and tests for the replacement learning experience
- [x] Verify no obsolete Jātaka references remain in visible app screens


## Advanced reflection exercises

- [x] Define mature reflection exercises for difficult decisions, boundaries, attachment, and repair
- [x] Add advanced exercises to the Practice experience
- [x] Localize advanced exercise labels and prompts
- [x] Add deterministic tests for advanced exercise content and safety framing
- [x] Verify advanced exercises remain private and avoid scoring or diagnosis


## Saveable advanced exercise responses

- [x] Persist advanced exercise responses locally
- [x] Add response editor with save, reopen, and clear controls
- [x] Keep responses separate from life stories and AI payloads
- [x] Localize response controls across five languages
- [x] Add deterministic storage and UI behavior tests


## Current release completion

- [x] Finish Room creation and protected rename flow
- [x] Review five-language labels used by the Room flow
- [x] Check mobile layouts for long-language wrapping and dropdown behavior
- [x] Verify saved responses remain local and separate from stories and AI input
- [ ] Test saved responses on a final Android device build
- [ ] Build the fresh Android APK through the Publish flow
- [ ] Generate the final release checkpoint after Android validation


## Central Me box and connected Room context

- [x] Add a central Me box for shared personal context
- [x] Connect all life Rooms to the central Me context
- [x] Preserve Room boundaries during contextual reflection
- [x] Add day wise deletion for individual Room entries
- [x] Use prior entries as context, not as present feeling
- [x] Add grief guidance for present sadness and related loss memories
- [x] Add careful impermanence, gratitude, and anumodanā guidance
- [x] Avoid asserting unknowable karma or replacing human support
- [x] Add deterministic tests for connected context and grief guidance


## Bare React Native migration evaluation

- [x] Audit Expo dependencies and native module requirements
- [x] Document bare React Native TypeScript migration architecture
- [x] Preserve current Expo project as rollback source
- [x] Prepare existing Dhammapath source package for attachment
- [x] Identify native encryption, biometrics, speech, and build risks
- [x] Decide whether migration should happen before personal APK testing


## Replit source package

- [x] Prepare a sanitized Replit ready source archive
- [x] Exclude API keys, tokens, environment files, caches, and dependencies
- [x] Add Replit setup instructions
- [x] Document safe NVIDIA key configuration
- [x] Verify archive contents before delivery


## Published artifact startup repair

- [x] Inspect published startup logs and runtime output
- [x] Identify the artifact entrypoint failure
- [x] Fix the published startup error
- [x] Validate local production startup
- [x] Recheck type, test, and lint status
- [ ] Save a corrected publish checkpoint


## Web first personal delivery

- [x] Set web first delivery as the immediate target
- [x] Keep web access private or restricted
- [x] Preserve local browser storage and master password
- [x] Harden Replit production startup
- [x] Validate mobile browser layout and reflection flows
- [x] Document web limitations versus native APK


## Web deployment cache repair

- [x] Prevent Metro from hashing transient CSS interop cache files during deployment
- [x] Rebuild the web artifact from a clean dependency state
- [x] Validate the Replit production start path again
- [x] Preserve the working live Replit preview
- [x] Save a corrected deployment checkpoint


## Central Me personal profile

- [x] Add personal identity and life context fields
- [x] Keep Me profile separate from Room entries
- [x] Persist Me profile locally and protect access
- [x] Include Me profile carefully in reflection context
- [x] Add five language labels and privacy notice
- [x] Add deterministic profile storage and guidance tests
- [x] Validate the updated live preview


## Mobile web presentation repair

- [x] Prevent bottom navigation labels from truncating on narrow phones
- [x] Improve initial web loading feedback
- [x] Preserve accessible tab names and touch targets
- [x] Validate the live Replit mobile layout again


## Personal diary and planning layer

- [x] Add private diary entries separate from life stories
- [x] Add calendar dates for diary and planning items
- [x] Add upcoming work and important moves
- [x] Add personal goals with progress states
- [x] Add habit development with daily completion
- [x] Connect planning context to the central Me box
- [x] Keep Room context and planning context distinct
- [x] Add five language labels and privacy notices
- [x] Add deterministic storage and planning tests
- [x] Document Vercel web deployment configuration


## Confirmed web first diary scope

- [x] Keep Vercel as the web deployment target
- [x] Keep diary entries separate from life stories
- [x] Keep calendar dates and upcoming work together
- [x] Keep important moves visible
- [x] Keep goals and habits actionable
- [x] Connect only selected planning context to Me guidance
- [x] Do not add AdviseMe persona features


## Progressive Web App delivery

- [x] Add installable web manifest
- [x] Add offline service worker for the web shell
- [x] Register the service worker only on web
- [x] Keep local stories and planning data unchanged
- [x] Document Android and iPhone home screen installation
- [x] Explain offline limitations for NVIDIA guidance
- [x] Validate manifest, service worker, and production export


## Wider Dhamma reference exploration

- [x] Audit current guidance keys and source references
- [x] Add wider Dhamma concept keys beyond emotion labels
- [x] Add Pali terms and plain meanings
- [x] Add source references to guidance insights
- [x] Add related teaching exploration links
- [x] Distinguish local fallback from cited online guidance
- [x] Keep references transparent and non-authoritative
- [x] Review five-language reference labels
- [x] Add deterministic tests for key matching and references


## Mentor system direction

- [x] Document the ocean mentor and empty cup student philosophy
- [x] Make listening precede advice
- [x] Add moment-of-change and circumstance understanding
- [x] Distinguish potential from present belief
- [x] Reduce generic motivation language
- [x] Add deeper human-context response framing
- [x] Preserve student agency and personal responsibility
- [x] Treat the system as a path tool, not a solution
- [x] Add mentor-system behavior tests


## Latest Vercel archive

- [x] Package the latest Vercel-ready source
- [x] Exclude dependencies, caches, logs, tokens, and environment files
- [x] Verify archive contents and build files
- [x] Deliver the latest Vercel ZIP


## Vercel opening failure

- [ ] Inspect the supplied Vercel URL
- [ ] Identify whether the failure is domain, build, route, or runtime related
- [ ] Compare Vercel settings with the latest archive
- [ ] Repair the deployment configuration if possible
- [ ] Verify the live URL after repair


## Weekly audit and calendar orchestration

- [x] Add weekly summary and bottleneck prompt to Calendar
- [x] Add master orchestration prompt to Calendar
- [x] Add optional calendar connector status
- [x] Add prompt copy controls
- [x] Keep prompt data private and local
- [x] Add five-language labels for the prompt panel
- [x] Validate Calendar page behavior


## Date-first calendar status

- [x] Add selectable calendar dates
- [x] Show done and not-done status dots
- [x] Toggle selected date completion state
- [x] Show selected date items
- [x] Preserve local completion state
- [x] Add translated calendar status labels
- [x] Test date and dot interactions


## Hospitality executive dashboard concept

- [ ] Map Habit Registry fields
- [ ] Map Office Task Registry fields
- [ ] Add Cert-Prep Registry separately from habits
- [ ] Implement monthly habit dot-grid
- [ ] Implement cert-prep compliance table
- [ ] Implement severity-based office task rollover
- [ ] Implement daily, weekly, and monthly roll-ups
- [ ] Implement registry-only update rules
- [ ] Preserve pending decisions at the top
- [ ] Explore alternate dashboard visual styles


## English-only executive Calendar scope

- [x] Keep Calendar labels in English
- [x] Keep executive task labels in English
- [x] Remove the five-language Calendar status requirement from scope
- [ ] Review all remaining product gaps and blockers


## Calendar connector and rollover

- [x] Enable Google Calendar connector in the Manus session
- [x] Verify the connector search path
- [x] Add app-open automatic weekly rollover
- [x] Archive completed historical planning items
- [x] Roll unfinished work into the current week
- [x] Escalate items after two rollovers
- [x] Show rollover summary in Calendar
- [x] Add rollover tests
- [ ] Import Google Calendar events into local planning items
- [ ] Add calendar event to task deduplication


## Internal People and diary workflow

- [x] Keep relationship tracking inside Dhammapath
- [x] Add private People and Contacts storage
- [x] Add relationship, next contact, notes, and last contacted fields
- [x] Match saved people against calendar text
- [x] Update Last contacted from matched event text
- [x] Capture calendar event text as a private diary item
- [x] Prevent duplicate diary capture for the same event
- [x] Keep external CRM out of the product scope
- [ ] Import live Google Calendar events into the app
- [ ] Add calendar event deduplication from live event IDs


## Live calendar bridge completion

- [ ] Add server-side calendar event bridge
- [ ] Fetch daily and weekly Google Calendar events
- [ ] Import event records into private planning
- [ ] Deduplicate imported events by provider event ID
- [ ] Match event names to internal People records
- [ ] Update Last contacted dates from imported events
- [ ] Add next-contact reminders
- [x] Generate a real weekly dashboard report
- [ ] Repair and verify the Vercel deployment
- [x] Run complete web-flow validation


## CRM-first direction

- [x] Make internal CRM the source of truth
- [x] Keep Google Calendar optional and passive
- [x] Finish People and Contacts editing
- [x] Add contact follow-up reminders
- [ ] Link contacts to Rooms and planning items
- [x] Add contact interaction history
- [ ] Add CRM task lifecycle controls
- [ ] Add CRM weekly and monthly reports
- [ ] Add CRM privacy and export controls


## Four-week CRM lifecycle view

- [x] Show four visible weekly bands
- [x] Keep unfinished tasks in future weeks
- [x] Show rollover count on task cards
- [x] Highlight meetings with a distinct color
- [x] Highlight reports with a distinct color
- [x] Highlight approvals and high-impact tasks
- [x] Highlight overdue and escalated tasks
- [x] Add a clear legend
- [x] Keep date dots and selected-day details
- [x] Test four-week responsive layout


## Manual task priority indicators

- [x] Add low, medium, and high task priority fields
- [ ] Add manual priority selection in task creation
- [x] Add manual priority editing on task cards
- [x] Highlight high-priority tasks in four weekly bands
- [x] Add priority legend and accessible labels
- [x] Preserve priority through rollover and archive
- [x] Test priority persistence and visual states


## Executive task creation priorities

- [x] Add executive task creation form
- [x] Require manual priority choice during task creation
- [x] Add red high-priority task state
- [x] Add amber medium-priority task state
- [x] Add green low-priority task state
- [x] Sort high-priority tasks first each day
- [x] Preserve priority through rollover
- [x] Validate ten-task daily visibility


## Priority-based weekly summary

- [x] Add current-week date boundary logic
- [x] Count completed high-priority tasks
- [x] List completed high-priority tasks
- [x] Count pending high-priority tasks
- [x] Alert pending high-priority tasks
- [x] Alert overdue and escalated high-priority tasks
- [x] Add summary legend and empty states
- [x] Add deterministic weekly summary tests
- [x] Validate mobile layout


## Weekly summary filters

- [x] Add priority filter controls
- [x] Add internal contact filter controls
- [x] Derive contact associations from task data
- [x] Update filtered counts and alert lists
- [x] Add clear-filter behavior
- [x] Add empty filtered states
- [x] Test priority and contact filtering
- [x] Validate mobile layout


## Operational control center expansion

- [x] Add recurring daily checklist registry
- [x] Track checklist completion by date and month
- [x] Add checklist item creation
- [x] Add checklist item deletion
- [x] Add examples for label check, FSIS, and FIFO
- [x] Keep weekly tasks forwardable
- [x] Add priority visibility toggle
- [x] Add team member registry with at least ten records
- [x] Add task ownership and deadline fields
- [x] Add project creation and deletion
- [x] Add project team members, owner, deadline, remarks, status, and review date
- [x] Add project-linked tasks
- [x] Add Excel workbook export
- [x] Validate local deletion and privacy behavior


## Executive task forwarding and reassignment

- [x] Add explicit forward action for executive tasks
- [x] Preserve forwarding history and rollover count
- [x] Add reassignment action using local team members
- [x] Show current assignee and forward history
- [x] Add deterministic forwarding and reassignment tests
- [x] Validate mobile task controls


## Task detail workflow history

- [x] Add task detail open action
- [x] Show task metadata in detail
- [x] Show creation and current state
- [x] Show every forward event
- [x] Show every reassignment event
- [x] Format dates and timestamps clearly
- [x] Add deterministic history formatting tests
- [x] Validate task detail on mobile


## Private single-person workspace refinement

- [x] Clarify Calendar as a personal oversight view
- [x] Clarify team names as responsibility records only
- [x] Remove collaboration-style wording
- [x] Keep week and day oversight prominent
- [x] Keep project planning aligned with personal control
- [x] Connect projects to weekly and daily tasks
- [x] Validate private workspace language


## Project editing

- [x] Add project edit mode
- [x] Edit product and project name
- [x] Edit connected people and primary responsibility
- [x] Edit deadline and review date
- [x] Edit remarks and status
- [x] Preserve linked executive tasks
- [x] Add project editing tests
- [x] Validate project editing on mobile


## Visible project team assignments

- [x] Show all saved responsibility names clearly
- [x] Show selected project members on each project card
- [x] Support multiple people per project
- [x] Preserve project member selections during editing
- [x] Add assignment visibility tests
- [x] Validate names and assignments on mobile


## Visible team member identity

- [x] Show member name and designation together
- [x] Keep name and designation editable during creation
- [x] Show designation in project assignments
- [x] Preserve multiple project assignments
- [x] Keep add and delete controls visible
- [x] Validate member identity presentation on mobile


## Staged project implementation workflow

- [ ] Add planned project stage
- [ ] Add active implementation stage
- [ ] Add waiting to deploy stage
- [ ] Add deployed stage
- [ ] Add completed and blocked stages
- [ ] Show project progress stage clearly
- [ ] Preserve linked task and responsibility data
- [ ] Add stage transition tests
- [ ] Validate staged project workflow on mobile


## Current and completed project separation

- [x] Separate current projects from completed projects
- [x] Add waiting-to-deploy status
- [x] Show heading person on project records
- [x] Add completed project section
- [x] Keep finished projects out of current work
- [x] Preserve project details and linked tasks
- [x] Add status separation tests
- [x] Validate project sections on mobile


## Monthly training calendar pins

- [x] Add private training record storage
- [x] Add training date field
- [x] Add training topic field
- [x] Add paste or text entry area
- [x] Show training pins on matching calendar dates
- [x] Show training topic in the calendar area
- [x] Add training deletion control
- [x] Preserve training data by month
- [x] Add deterministic training pin tests
- [x] Validate training calendar on mobile


## Final Vercel package and implementation report

- [x] Write complete implementation report Markdown
- [x] Include all completed features
- [x] Include all true pending items
- [x] Prepare one sanitized Vercel source ZIP
- [x] Exclude secrets and environment files (.project-config.json removed, was leaked in first zip, keys must be rotated)
- [x] Exclude dependencies and caches
- [x] Verify ZIP contents (confirmed no project-config/env files present)
- [x] Deliver only one ZIP and one MD file

## Backend wiring for Vercel (audit follow-up)

- [x] Split Express app creation from server listen() so it can run as a function
- [x] Add api/index.ts Vercel serverless entrypoint wrapping the same Express app
- [x] Update vercel.json rewrite to exclude /api/ from the SPA fallback
- [x] Fix ai.reflect: was on protectedProcedure, unreachable since no login flow exists in UI; moved to publicProcedure (real gate is local master password, not Manus OAuth)
- [x] Fix nvidia-key.test.ts to skip instead of fail when key is absent
- [ ] Set NVIDIA_API_KEY (new, rotated) as an env var on the Vercel project
- [ ] Deploy and confirm /api/trpc/ai.reflect responds live
- [ ] Optional: strip unused OAuth/DB/storage-proxy code paths, not needed for single-operator use
