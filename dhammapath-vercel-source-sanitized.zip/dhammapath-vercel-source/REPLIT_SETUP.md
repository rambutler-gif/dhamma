# Dhammapath on Replit

Dhammapath is an Expo SDK 54 mobile project with a Node backend. This package is ready for Replit editing and web preview. Replit can run the web experience and backend. Android APK generation still uses Expo EAS Build.

## Import

Upload this source archive to a new Replit project. Do not upload `node_modules`, `.expo`, local logs, environment files, or private credentials.

## Install

```bash
pnpm install
```

## Run the project

```bash
pnpm dev
```

The project starts the Node API and Expo web preview together. Replit should expose the web preview port used by the Expo process.

For a production web deployment, Replit should run:

```bash
pnpm build
pnpm start
```

`pnpm build` creates both the server bundle and the Expo web export. `pnpm start` serves the API and the exported web app from the same port.

For the API only:

```bash
pnpm dev:server
```

For the web client only:

```bash
pnpm dev:metro
```

## Checks

```bash
pnpm check
pnpm test
pnpm lint
```

## Replit Secrets

Add secrets through Replit Secrets. Never place them in source files, `eas.json`, `app.config.ts`, or the mobile client.

| Secret | Purpose |
|---|---|
| `NVIDIA_API_KEY` | Server side NVIDIA NIM reflection requests |
| `JWT_SECRET` | Local server cookie signing |
| `DATABASE_URL` | Only if database features are enabled |
| `BUILT_IN_FORGE_API_URL` | Existing platform service URL, only if required |
| `BUILT_IN_FORGE_API_KEY` | Existing platform service credential, only if required |

The NVIDIA route reads `NVIDIA_API_KEY` on the server. The key is sent only from the backend to NVIDIA NIM.

## Android APK

Replit does not replace Expo EAS for native Android packaging. From the Replit Shell, after signing into Expo:

```bash
npx eas-cli@latest login
auto=false npx eas-cli@latest build:configure
```

Create `eas.json` at the project root:

```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": {
        "buildType": "apk"
      }
    }
  }
}
```

Start the installable Android build:

```bash
npx eas-cli@latest build --platform android --profile preview --message "Dhammapath personal APK"
```

If EAS requests Android signing credentials, choose generation of a new keystore. Download the completed APK from the EAS build page.

## Personal privacy

Stories, Rooms, structured reflections, and advanced exercise responses use local storage in the mobile app. Replit hosting should not be treated as private storage unless access controls and deployment settings are configured separately. Do not put personal stories into source files or public project logs.

## Important limitation

The current project remains an Expo React Native app. Replit can host the web preview and edit the source. A bare React Native migration is not included in this archive. That migration would require separate native Android and iOS projects and additional device testing.
