# Dhammapath Mobile Interface Design

## Product identity

**App name:** Dhammapath

**Tagline:** The Path Within

**Purpose:** A private Theravada reflection companion for recording life stories, examining present experience, and considering one wise next action.

The app is not therapy. It is not diagnosis. It does not claim spiritual authority. It helps the user examine what is present.

## Design principles

The interface follows mainstream iOS patterns. It uses portrait orientation and supports one-handed use. Primary actions remain within comfortable thumb reach. The tone is quiet, respectful, and direct.

The app must never shame the user. It must not present emotional scores as personal progress. It must not encourage dependence on the app instead of trusted people or qualified support.

## Screen list

| Screen | Primary content and function |
|---|---|
| Welcome and Lock | First-use introduction, master password creation, unlock, lock state, and privacy promise. |
| Home | Today’s reflection prompt, current feeling entry point, recent story summary, and private-space status. |
| Rooms | User-created rooms such as Family, Work, Career, Business, Travel, and Projects. Users can create, rename, reorder, and delete rooms after password confirmation. |
| Room Detail | Stories stored in one room, room master script, reflection history, and add-story action. |
| New Story | Title, life story, who, what, when, where, why, how, feeling, and want fields. Saves locally. |
| Story Detail | Full saved story, linked room, saved reflection answers, emotion check-ins, and delete controls. |
| Guided Reflection | Step-by-step questions based on the selected room script. Shows fact, assumption, craving, fear, anger, and self-story lenses. |
| Reflection Result | One perspective to consider, right-view or unhelpful-seeing explanation, wiser substitute, one small action, and autonomy choices. |
| Emotion Check-in | User selects an emotion and intensity from 1 to 5, with an optional sentence. No diagnosis or progress score. |
| Reflection Calendar | Calendar dots for reflection days. Selected days show emotion, intensity, room, and private note. Includes weekly and monthly pattern summaries. |
| Learn | Pali search, English meaning, Tamil meaning, daily verse, Jātaka stories, Sutta Piṭaka map, and Vinaya Piṭaka map. |
| Pali Term Detail | Pali word, pronunciation help, plain English meaning, Tamil meaning, and Dhamma context. |
| Daily Verse | Pali verse, English meaning, Tamil meaning, and a short reflection prompt. Other supported languages are added through the localization layer. |
| Jātaka Reader | Short, easy-to-understand story with lesson, source note, and optional reflection question. |
| Piṭaka Mind Map | Scrollable and zoomable learning map for Sutta or Vinaya structure. |
| Practice | Small practices grouped by right speech, right action, right effort, and mindfulness. |
| Settings and Privacy | Language, lock controls, room management, data export, data deletion, and AI mode. |

## Key user flows

### First use

1. User opens Dhammapath.
2. User reads the private-space promise.
3. User creates a master password.
4. User enters Home.
5. User sees the first reflection prompt.

### Record a life story

1. User taps Share what is present.
2. User chooses an existing Room or creates one.
3. User writes the story.
4. User adds circumstances: who, what, when, where, why, and how.
5. User records feeling and want.
6. User saves locally.
7. User may reflect now or return later.

### Guided reflection

1. User opens a saved story.
2. User taps Reflect.
3. The selected Room master script shapes the questions.
4. User answers each question.
5. The system separates known facts from assumptions and self-story.
6. The system explains one possible right-view distinction in plain language.
7. The system offers one wiser substitute and one small action.
8. User chooses Practise or Not now.
9. User records an emotion check-in.
10. The app shows the impermanence reminder.

### Emotion calendar

1. User opens Reflection Calendar.
2. User selects a date.
3. The app shows that day’s emotion, intensity, room, and note.
4. User can open the linked story.
5. The app shows patterns as observations, not judgments.
6. The app displays: “Nothing is permanent. Notice how this feeling changes.”

### Crisis boundary

1. The system checks for immediate danger language before normal reflection.
2. If detected, normal questions stop.
3. The app shows urgent local support guidance.
4. The app encourages contact with emergency services, a trusted person, or qualified professional support.
5. The app does not ask reflective questions first.

## Response language

Use careful phrasing:

> This appears to be unhelpful seeing because the desired outcome is being treated as necessary.

> One way to see this is that wanting closeness is understandable, while another person remains free to choose.

> This is not a judgment of you.

> Nothing is permanent. Notice how this feeling changes.

Never say that the user has a diagnosis. Never claim certainty about another person’s mind. Never promise healing or cure.

## Color choices

| Token | Color | Purpose |
|---|---|---|
| Deep forest | `#102A25` | Reflection cards and primary dark surfaces. |
| Warm ivory | `#F7F3EA` | Main background and reading space. |
| Copper saffron | `#C8753D` | Primary action and active emphasis. |
| Watercolor blue | `#3E78A3` | Dhamma learning, logo accents, and links. |
| Soft sage | `#DCE7DF` | Calm supporting surfaces. |
| Charcoal ink | `#1C2623` | Primary text. |
| Quiet gray | `#6F7772` | Secondary text. |
| Boundary red | `#B94A48` | Safety notices only. |

## Data model vocabulary

A **Room** contains a name, description, master script, creation date, and stories. A **Story** contains life circumstances, narrative text, room ID, reflections, emotion check-ins, and timestamps. An **EmotionCheckIn** contains an emotion, intensity from 1 to 5, optional note, and date. A **Reflection** contains answers, view explanation, substitute advice, small action, and autonomy choice.

All private records remain local by default. The master password protects access. AI requests send only the minimum required reflection context and never expose the master password.
